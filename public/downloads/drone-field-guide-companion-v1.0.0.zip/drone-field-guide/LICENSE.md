# License

Copyright © 2026 Dustin Gamble. All rights reserved.

This companion is provided to readers of *Drone Field Guide* for their personal and professional use with an AI assistant of their choice. You may install it on your own accounts and devices and keep it as long as you like. You may not redistribute it, sell it, host it for others, or include it in a product or service, in whole or in part, without written permission. Quoting a rule or a law with attribution is fine and encouraged.

The values in it are engineering judgment: round numbers from practice, stated with their conditions, meant to be checked by measurement. They are provided without warranty of any kind. They are for small unmanned aircraft only and must not be used for aircraft that carry people. Nothing here substitutes for the review of a qualified engineer for anything that can cause injury or loss.
