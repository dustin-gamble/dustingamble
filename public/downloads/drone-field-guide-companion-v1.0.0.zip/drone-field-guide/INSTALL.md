# Installing the companion

The zip you downloaded unpacks to one folder, `drone-field-guide/`. Everything below uses that folder as it is. Do not rename the files inside it.

## Claude (recommended)

**claude.ai:** open Settings, find Capabilities (or Skills), and upload the zip as a custom skill. Claude will use it on its own whenever a conversation is about small unmanned aircraft; you can also say "use the drone field guide skill".

**Claude Code:** unzip into your skills folder so that the file `~/.claude/skills/drone-field-guide/SKILL.md` exists (or `.claude/skills/drone-field-guide/` inside a project). Start a new session. The skill loads when the topic comes up, or with `/drone-field-guide`.

**Claude Developer Platform (API):** upload the folder as a skill in the Console, or with the skills API, and attach it to your agent. The `SKILL.md` frontmatter is what the platform reads.

Claude can run `tools/dfg_calc.py` itself when it has a code tool; otherwise it reads the lookup tables.

## ChatGPT

Create a Project. Add every file in `reference/` and `tools/dfg_calc.py` as project files. Open `SYSTEM_PROMPT.md`, copy the block under the line, and paste it into the project's instructions. Ask your questions inside that project. (A custom GPT works the same way: files under Knowledge, the block under Instructions.)

## Gemini

Create a Gem. Paste the block from `SYSTEM_PROMPT.md` as its instructions and add the `reference/` files and `tools/dfg_calc.py` as its knowledge files.

## Anything else

Give the assistant the folder, or the files it can take, and the block from `SYSTEM_PROMPT.md` as its system prompt. The files are plain Markdown and one Python script; nothing depends on a particular platform.

## Using it well

Ask the way you would ask the book: with numbers. "Size a 4 kg hand-launched fixed wing for 90 minutes at 16 m/s" gets a better answer than "design me a drone". When it diagnoses, tell it what changed since the last good flight. When it gives a number, look at the assumptions it lists, then measure.

## Updates

The companion is updated more often than the book. The version you have is in `VERSION`; the current one is on the page you downloaded this from. New versions replace the whole folder.
