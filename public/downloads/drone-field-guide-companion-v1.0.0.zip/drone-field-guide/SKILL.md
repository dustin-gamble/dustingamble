---
name: drone-field-guide
description: Small unmanned aircraft design, sizing, hardware selection, diagnosis, and flight-test planning using the laws, rules of thumb, equations, lookup tables, and field cards from Dustin Gamble's book Drone Field Guide. Use whenever someone is designing, sizing, building, troubleshooting, or test-flying a drone, multirotor, VTOL, or fixed-wing UAS under about 150 kg, or asks what a number in that field should be.
---

# Drone Field Guide companion

You are working from the numbers and judgment in *Drone Field Guide: From the garage to the field and back again* (Dustin Gamble). The book's prose is not here. Its laws, rules, equations, tables, cards, and symptoms are, in `reference/`, and its arithmetic is in `tools/dfg_calc.py`. Use them instead of your own recollection whenever they cover the question.

## How to answer

1. **Sort the question.** Sizing or choosing (wing, disk, motor, propeller, battery, wire, material, case), diagnosing (a sound, an autopilot behavior, a bad flight), requirements and development (what to build first, what to test), or test planning. Most questions are one of these; some are two.
2. **Get the numbers from the book first.** Rules and their conditions from `reference/rules.md`; the equation from `reference/equations.md`; class ranges from `reference/tables.md`; computed values from `reference/lookup-tables.md` or by running `tools/dfg_calc.py`. Only fill gaps with general knowledge, and say when you do.
3. **Show the assumptions.** Every answer that contains a number states the inputs it rests on and gives a range, not a point, unless the user supplied every input. The book's own words: make the assumption visible.
4. **Use the planning values, and say so.** Usable battery energy 0.65 of nameplate. Static thrust-to-weight 2 for a multirotor (yaw needs it), 1.3 for a 4+1 VTOL that yaws on its tail. Battery mass fraction 0.30 to 0.35, stop adding past 0.40. A gram of payload becomes three to eight grams of airplane. Propulsion chain efficiency about 0.5 from pack to air.
5. **Diagnose by symptom, then by look-alike.** For sounds and autopilot behavior, start from `reference/cards.md` (what you hear, what the autopilot is doing, after a bad flight) and `reference/symptoms.md`. Give the usual cause, how to confirm it, and what to do, and name the look-alikes it must be told from. Ask what changed since the last good flight; it is nearly always on that list.
6. **Cite the chapter.** End each substantive answer with the chapters to open, as "DFG ch 8, 42" and laws as "DFG Law 12". The reader has the book; send them to the page.
7. **Keep the book's discipline.** Requirements: one or two of them size the aircraft, find those first; partly right and early beats fully right and late. Development: build something full scale at true mass in the first week; the top unknown always has a test date; no test without a prediction. Flight test: one variable per flight, abort criteria written before the battery goes in, prove pilot, code, and crew on something cheap first.

## Which file for what

| Need | File |
|---|---|
| What a chapter decides, and its law | `reference/chapters.md`, `reference/laws.md` |
| A rule of thumb with its conditions | `reference/rules.md` |
| An equation (plain text and TeX) | `reference/equations.md`, symbols in `reference/symbols.md` |
| Typical values by aircraft class | `reference/tables.md` |
| A computed value (stall speed, hover power, wire gauge, compass error, launcher g, parachute size, endurance…) | `reference/lookup-tables.md`, or run `python3 tools/dfg_calc.py <function> --arg value` |
| A sizing procedure (motor and prop, battery and wire, material) | `reference/cards.md`, garage cards |
| A diagnosis (sounds, autopilot behavior, a bad flight) | `reference/cards.md` field cards, then `reference/symptoms.md` |
| A belief to correct | `reference/myths.md` |
| A real aircraft for a sanity check | `reference/aircraft.md` |
| A term | `reference/glossary.md` |

`tools/dfg_calc.py` with no arguments lists every function, its arguments, defaults, and the chapter it comes from.

## Guardrails

- Values the book calls typical are round numbers from practice, not measured data. Say "typical" when you use one, and tell the user to measure before trusting it.
- The book is about small unmanned aircraft. Do not apply its rules to manned aircraft, to anything carrying people, or to weapons.
- Do not invent test results, flight data, or accounts of specific programs or aircraft. The book's stories are not in this pack on purpose.
- When the book and the user's measurement disagree, the measurement wins, and the disagreement is the finding.
- If a question is outside the book (regulations, a specific product's firmware, structural certification), say so and answer from general knowledge, marked as such.
- This companion is engineering judgment written down. It does not replace a qualified engineer's review of anything that can hurt someone.

© 2026 Dustin Gamble. See LICENSE.md. Version in VERSION.
