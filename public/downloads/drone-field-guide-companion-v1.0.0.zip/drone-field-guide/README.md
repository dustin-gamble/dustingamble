# Drone Field Guide companion

The numbers, rules, and judgment from *Drone Field Guide: From the garage to the field and back again* (Dustin Gamble), in a form an AI assistant can use. Not the book: no prose, no figures, no stories. Just what the assistant needs to answer the way the book would, and to send you to the right chapter.

- `SKILL.md` — instructions for Claude (this folder is a Claude skill as it stands)
- `SYSTEM_PROMPT.md` — the same instructions for other assistants
- `INSTALL.md` — how to load it into Claude, ChatGPT, Gemini, or anything else
- `reference/` — laws, rules, equations, tables, lookup tables, cards, myths, symptoms, glossary, symbols, aircraft
- `tools/dfg_calc.py` — the book's arithmetic as Python functions
- `VERSION`, `LICENSE.md`

Get the book, and the current version of this companion, at https://dustingamble.com/drone-field-guide/companion/
