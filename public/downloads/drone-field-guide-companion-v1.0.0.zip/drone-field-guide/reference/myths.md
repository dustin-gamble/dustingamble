# Things people believe, and the better rule

- **Belief:** “It only flies 50 minutes? Just add a bigger battery.”
  **Better rule:** Past a battery fraction of about 0.35, stop adding cells and start removing mass and drag. Below 0.25, a bigger pack pays well. From 0.25 to 0.40 it pays about half of what the watt-hours promise. Beyond that you are mostly buying stall speed. A gram taken out of the airframe counts twice: it is one less to carry, and it makes room for a gram of battery.

- **Belief:** “Make it out of carbon. Carbon fiber is always lighter.”
  **Better rule:** Use carbon where the load path is long and the load is real. Spars, booms, tubes, motor arms: size them by stiffness and carbon earns its price. For skins, fairings, hatches, and trays on a small aircraft, choose by minimum gauge, damage tolerance, and repair time. The lightest part is often the one made from the cheap material at the right thickness.

- **Belief:** “Eight motors. If one quits there are seven more. It has to be more reliable.”
  **Better rule:** Extra motors are redundancy only if the aircraft flies on what is left. That takes thrust-to-weight to spare with one out, a controller that reallocates, a tethered motor-out test to prove it, and strings that do not share a connector, a bus, or a failure mode. Without those, every added motor is one more way to lose the aircraft.

- **Belief:** “It hunts a little in pitch. Don’t worry, you can tune that out.”
  **Better rule:** Fix the hardware, then tune. Before touching a gain, wiggle every surface by hand, look in the log for outputs sitting at their limits, and put the aircraft on the CG stand. Gains that have to be set oddly high or oddly low to make it fly are a symptom, not a setting.

- **Belief:** “It flew fine in the simulator.”
  **Better rule:** Trust the simulator for logic. Trust it for dynamics after flight data has corrected it. Use it freely for modes, failsafes, mission scripts, and sign conventions. For gains and margins, put in measured delay, measured servo rates, and logged noise. Then fly, and make the model reproduce the log. A model corrected by three flights is a tool. Before that it is a hypothesis with good graphics.

- **Belief:** “Motors are cheap now. Bolt on four lift motors and never look for a runway again. VTOL is basically free.”
  **Better rule:** VTOL is launch and recovery equipment that you carry on every flight. Price it that way. Compare it with what it replaces: the launcher, the net or runway, the site limits, the crew training. VTOL often wins that comparison. It never wins it for free. As a first budget, expect about half the endurance of the same airframe without it, then earn some back with low disk loading and a short, practiced hover profile.

- **Belief:** “The datasheet says 30 amps, so it’s good for 30 amps.”
  **Better rule:** A 30 A label is a 20 A part until you have measured it. Choose a continuous rating 1.3 to 1.5 times your highest sustained current, more for still air inside a fuselage. Then instrument it. Fly the worst profile on a hot day with a temperature logger on the ESC and the motor. If both settle below their limits with room to spare, the rating is now yours, for that installation only.

- **Belief:** “Bolt some weight in it. A heavier airplane handles wind better.”
  **Better rule:** Wind is beaten by airspeed. Decide the speed, then pay for it on purpose. Set cruise speed from the wind you must work in, let that set the wing loading, and then design the launch and recovery to match. If that needs a smaller wing, build the smaller wing. Lead buys the same speed and nothing else.

- **Belief:** “It’s a little over. We’ll fix the weight later.”
  **Better rule:** Weigh everything from the first day. A gram is cheapest before it is designed in. Give every assembly a mass budget and a name next to it. Put each part on the scale as it arrives and update the total that day. Hold a growth margin from the start, because prototypes typically gain 5 to 15% between first sizing and first flight. The scale costs less than the second wing.
