# Field and garage cards

Decision tables and procedures from the quick-reference cards. Garage = choosing and sizing on the bench; field = what you see and hear on the flight line.

## Pick a material (garage)

Use when: You are about to make a part and are reaching for whatever is already on the bench. Thirty seconds here first.

### By part and by quantity

*First choices. “Build it” means this week, with shop tools. Heavier and cheaper is often the better aircraft.*

| Part | 1 to 5 aircraft | 10 to 100 | 1,000 and up |
|---|---|---|---|
| Wing | Hot-wire or CNC foam core, tube spar, glass or film skin. Or foam board. | Molded composite skins over foam or ribs, same tube spar. | Molded EPP or EPO foam with a bonded spar. Blow-molded or thermoformed skins. |
| Spar, booms | Pultruded or roll-wrapped carbon tube at every quantity. Buy it. It is straighter, cheaper, and better than anything laid up in the shop. |  |  |
| Fuselage pod | 3D print, foam board, or glass over a lost-foam plug. | Two-part female mold, glass or carbon. Thermoformed shells for hatches and fairings. | Injection-molded halves, or molded foam with a plastic skeleton. |
| Motor mount, firewall | Plywood, G10 plate, or printed nylon or PETG with metal inserts. Never PLA. | Waterjet or routed G10 or aluminum plate. | Stamped or die-cast aluminum, or glass-filled nylon molding. |
| Brackets, servo trays, clips | 3D print. | 3D print. It is still the cheapest at this quantity. | Injection mold. Combine parts while you are at it. |
| Skids, bumpers, tips | Plywood, TPU print, or a strip of sacrificial foam. | Same. Make them replaceable without tools. | Molded TPU or nylon. |
| Wing joints | Tube joiner plus nylon bolts sized to shear before the wing breaks. See Designing for repair. |  |  |



### The temperature check

*Where common shop materials go soft. Typical values; check the datasheet for the grade you bought.*

| Material | Starts to soften near | So |
|---|---|---|
| PLA print | 50 to 60 °C | Mockups and fixtures only. A car in the sun will warp it. |
| Room-temperature-cured epoxy laminate | 50 to 70 °C until post-cured | Post-cure it, or paint it white. Dark carbon in the sun gets hotter than you think. |
| PETG print | about 80 °C | Fine for most airframe parts away from the motor. |
| EPP and EPO foam | about 80 to 100 °C | Keep it off ESCs and exhaust. Dark colors dent in the sun. |
| Nylon, filled nylon | above 100 °C, grade dependent | Motor mounts and hot zones. Absorbs moisture and changes size. |
| Aluminum, G10, plywood | Not a problem here | First choice next to anything that makes heat. |


- **Three questions: how many, how hot, and what happens when it hits the ground?** Quantity picks the process. Temperature rules materials out. The crash case tells you which parts should be tough and cheap instead of stiff and light. Only then look at stiffness per weight. See Materials for the properties and Manufacturing by quantity for the cost crossover.


Chapters behind this card: 26, 27, 28, 76

## Size the motor and propeller (garage)

Use when: You have a mass estimate, a speed range, and a catalog open in another window. An hour with this page gets you a propeller, a motor, an ESC, and a test to run before anything flies.

### Seven steps, with one aircraft worked through

1. Thrust and power needed. Cruise thrust is weight ÷ L/D. Climb adds weight × climb rate as power. For a hand launch or a short takeoff, set a static thrust target of 0.5 to 0.8 × weight. For anything that hovers, thrust is 2 × weight at the worst moment.Cruise: 29.4 N ÷ 10 = 2.9 N → 53 W of thrust power. Climb: +88 W → 141 W. Static target: 0.6 × 29.4 = 18 N.
2. Diameter: the biggest propeller that fits. Ground clearance, boom spacing, folding length, and tip speed set the limit. Bigger and slower is more efficient and quieter, every time. Keep the tip under about Mach 0.6 to 0.7.12 in (0.305 m) clears the ground. Tip limit at Mach 0.6: about 12,800 RPM. Plenty of room.
3. Pitch from the top speed you need. A fixed-pitch propeller is efficient at 80 to 100% of its pitch speed and makes no thrust near 130%. Put cruise in the efficient band and check that maximum speed is still below the fade.12×6 at 9,000 RPM: pitch speed = 6 × 0.0254 × 9,000 ÷ 60 = 22.9 m/s. Cruise at 18 m/s is 79%. Thrust fades near 30 m/s.
4. RPM and shaft power from propeller data. T = C_T ρ n² D⁴ and P = C_P ρ n³ D⁵, with n in revolutions per second. Use measured coefficients: the UIUC propeller database, the maker’s tables, or your own stand. Typical static values for a pitch-to-diameter ratio of 0.5 are C_T ≈ 0.10 and C_P ≈ 0.045.At 9,000 RPM (n = 150): static thrust ≈ 24 N (T/W 0.8, above the 18 N target). Shaft power ≈ 490 W.
5. Motor: Kv, mass, and cooling. Loaded RPM is about 0.8 × Kv × volts. Electrical power is shaft power ÷ about 0.85. For mass, typical outrunners take 3 to 5 W per gram in bursts and about half that continuously. Then look at where the cooling air comes from.Kv ≈ 9,000 ÷ (0.8 × 14.8) ≈ 760. Electrical: 490 ÷ 0.85 ≈ 575 W, 190 W/kg of aircraft. Motor of about 145 g or more.
6. Current sets the ESC, the battery, and the wire. Current is electrical power ÷ volts. ESC at 1.3 to 1.5 × the measured maximum. Then go to Size the battery and wiring.575 ÷ 14.8 ≈ 39 A peak → 50 to 60 A ESC. Cruise: about 110 W electrical, 7.4 A.
7. Bench test before it goes in the airframe. Measure static thrust, current, and voltage at five throttle points. Run two minutes at maximum and put a finger or a thermocouple on the motor and the ESC. Compare against steps 4 to 6. If measured current is more than 10% over, change the propeller, not the ESC. See Bench test.


### If it hovers

*What changes for multirotors and VTOL lift systems*

| Step | Change |
|---|---|
| 1 | Thrust per rotor = 2 × weight ÷ number of rotors, at end-of-pack voltage, on the hottest and highest day. For a motor-out case, do the sum with one missing. |
| 2 | Diameter matters even more. Hover power falls with the square root of disk area. See Disk loading. |
| 3 | Low pitch, about 0.3 to 0.5 × diameter. You are buying static thrust and fast RPM response, not speed. |
| 5 | Low Kv on high voltage for big rotors. Check that hover sits at 40 to 60% throttle so the controller has room both ways. |


- **Propeller first, then motor, then battery.** The propeller decides how much air you move and how fast. The motor only has to turn it at the right RPM without cooking. The battery only has to feed the motor without sagging. Choosing in that order is how you avoid the 40 A motor on a 20 A propeller.


Chapters behind this card: 8, 18, 19, 20, 57

## Size the battery and wiring (garage)

Use when: You know cruise power and peak current, from Size the motor and propeller or from a bench test, and you need a pack, leads, and connectors.

### Six steps, same aircraft

*Quick gauge by continuous propulsion current. Copper, 10 A/mm² in free air, 5 A/mm² bundled; drop is per metre of run, lead and return, at the free-air gauge. Full table in the lookup tables.*

| Current | Min AWG, free air | Min AWG, bundled | Drop per m of run |
|---|---|---|---|
| 10 A | 16 | 14 | 263 mV |
| 20 A | 14 | 10 | 331 mV |
| 40 A | 10 | 8 | 262 mV |
| 60 A | 8 | 6 | 247 mV |
| 100 A | 6 | 4 | 259 mV |
| 150 A | 4 | 4 | 244 mV |


1. Energy the mission uses. Power × time for each phase. Include the climb, any hover, and the payload and avionics load.Cruise 110 W × 0.75 h = 83 Wh. Climb 320 W × 2 min = 11 Wh. Total 94 Wh.
2. Nameplate energy. Divide by 0.65.94 ÷ 0.65 = 145 Wh.
3. Cells and capacity. Series count comes from the motor voltage. Capacity is Wh ÷ (cells × 3.7 V). Then weigh it: if the pack is more than about a third of the aircraft, go back to the sizing loop.145 ÷ 14.8 = 9.8 Ah at 4S. At about 180 Wh/kg that is 0.8 kg, 27% of the aircraft.
4. Current check. C-rate is peak amps ÷ amp-hours. Stay well inside the cell’s honest continuous rating, which is usually lower than the label. High-energy cylindrical cells often cannot do what a LiPo can here.39 A ÷ 9.8 Ah = 4C peak, under 1C in cruise. Comfortable for LiPo, workable for good Li-ion cells.
5. Sag check. Voltage drop is current × pack resistance. Make sure the voltage under peak load stays above the autopilot’s failsafe and the ESC cutoff, late in the flight, on a cold day.39 A × 0.020 Ω = 0.8 V of sag. 4S at 3.5 V per cell resting → 13.2 V under load. Set failsafes below that, above 3.3 V per cell.
6. Wire and connectors. Two limits: heat and voltage drop. On short leads heat governs. On long leads drop governs. Copper is 0.0172 Ω·mm² per metre. Hold loss under 2% at peak current. For continuous current, about 10 A per mm² in free air and half that in a bundle.Drop: 2% of 14.8 V = 0.30 V over 0.4 m of lead and return → needs 0.9 mm². Heat: the 39 A peak is brief and cruise is 7 A, so 12 AWG (3.3 mm², 33 A continuous) is right. If 39 A were continuous, or the leads were buried in a bundle, go to 10 AWG. Heat wins.


### Connectors and protection

*Quick checks. Ratings vary by maker; see the tables chapter and the datasheet.*

| Item | Check |
|---|---|
| Main connector | Continuous rating at or above your peak current, not its burst rating. Anti-spark above about 6S. |
| Every crimp and solder joint | Pull test by hand. A warm connector after a flight is a failing connector. |
| Where the protection lives | Know which device stops over-discharge: the pack, a BMS, the ESC cutoff, or the autopilot failsafe. Write it down. Do not assume the pack has it. |
| Avionics supply | Its own regulator, fed ahead of the motor current path. Servos on a separate regulator from the autopilot. See Electrical integration. |
| Balance lead | Secured and strain-relieved. It is the thinnest wire on the aircraft carrying full pack voltage. |


- **Land with 20% left and never below 3.3 V per cell under load.** Energy is what you plan with. Voltage is what the aircraft actually feels. Set the failsafe on voltage under load, and check it against a real log from a cold day.


Chapters behind this card: 9, 21, 20, 33, 76

## What you hear (field)

Use when: Something sounds different from last flight. Decide in the next few seconds whether to keep flying, and after landing, where to look.

### Two facts that decode most of it

- The main tone is blade-pass frequency: blades × RPM ÷ 60. A two-blade propeller at 6,000 RPM hums at 200 Hz. RPM is 30 times the tone for two blades, 20 times for three.
- Two tones close together beat. Two propellers a little apart in RPM pulse at the difference: blades × ΔRPM ÷ 60. Two-blade propellers 30 RPM apart pulse once a second. The pulse is real, it is loud, and by itself it is harmless.

### Nine sounds

*What you hear, what it usually is, how to confirm, what to do*

| Sound | Usually | Confirm | Do |
|---|---|---|---|
| Slow pulsing, wah… wah…, rate drifts | Two or more propellers at slightly different RPM. Normal on twins and distributed propulsion. | Pulse rate changes as throttle or attitude changes. Disappears with one motor running. | Nothing. If it bothers the payload or the crew, that is what RPM synchronization is for. |
| Constant warble on a multirotor | The controller working the motors to hold attitude. More warble means more work: wind, a tired battery, a loose arm, an off-center CG. | Compare with your calm-day baseline at the same weight. | If it is new on a calm day, land and look for something loose or unbalanced. |
| Thump or throb once per revolution under the normal tone | One blade is different: chipped, out of track, a folding blade not fully open, dirt or ice, a bent shaft or adapter. | A new line in the spectrum at RPM ÷ 60, below blade-pass. The same line shows up in the IMU vibration log. | Land. Inspect and balance. See Vibration. |
| Harsh rasp, many harmonics, louder than the power suggests | Blades cutting through a wake: a pusher behind a wing or pylon, a propeller close to a boom, a duct with a stator too near the rotor. | Same propeller is much quieter on a test stand in clean air. | Normal for the layout, but it costs thrust and fatigues blades. More gap between the wake and the disk helps most. |
| Pitch rises with no throttle change, usually in a dive or a fast pass | The propeller is unloading. Airspeed is approaching pitch speed and thrust is fading. | RPM up, current down, airspeed up in the log. | Expected on a fixed-pitch propeller. On anything that steers with thrust it is a warning that control authority is thinning. See Propellers. |
| Screech, stutter, or a sudden drop in tone with lost thrust | ESC lost synchronization with the motor, or a connection opened under load. | RPM trace drops out while throttle command holds. Often on a fast throttle jump, a big propeller, or long motor leads. | Land. See Propulsion failure. Check timing and start-up settings, solder joints, and connectors. |
| Tick or click at a steady rhythm | Something is being hit once per revolution, or a crack is opening and closing: a blade tip touching a wire or boom, a loose spinner, a cracked blade root. | Rhythm follows RPM exactly. Look for a witness mark. | Land now. A cracked blade sheds. |
| Growl or rumble that follows RPM, present even with the propeller off | Motor bearing, a magnet touching the stator, or a gearbox. | Spin it by hand, power off. Feel for roughness or a tight spot. | Replace the bearing or the motor before the next flight, not after. |
| A new buzz that arrives at a certain airspeed, whatever the throttle | A surface fluttering, or a hatch, tape edge, or antenna singing in the airflow. | It follows airspeed, not RPM. Its frequency is not a multiple of the propeller tone. | Slow down at once, land, and do not repeat the pass until you have found it. See Flutter. |


- **Ask what it follows: RPM, airspeed, or nothing.** Follows RPM: propeller, motor, or mount. Follows airspeed: airframe. Follows neither and comes and goes: something loose, or the controller. That one question sorts most sounds before you land.


Chapters behind this card: 59, 18, 64, 66, 68

## What the autopilot is doing (field)

Use when: The aircraft is doing something you did not ask for and you are about to change a parameter. Read the row. Check the log evidence. Most of these are not tuning problems.

### Behavior, cause, evidence, first move

*Works for the common open autopilots and most others. Frequencies are rough.*

| What you see | Usually | In the log | First move |
|---|---|---|---|
| Fast, fine shake. Multirotor buzzes and motors come down hot. Fixed wing buzzes in roll or pitch, worse when fast. | Rate-loop gain too high, or the derivative term amplifying vibration. On a fixed wing, gains not scaled down as airspeed rises. | Measured rate oscillating around the rate setpoint at several hertz or more. Outputs chattering. | Land. Fix vibration and filtering first. Then cut D, then P, by a quarter. Fixed wing: confirm airspeed scaling is on and the airspeed reading is good. |
| Slow wallow. Overshoots, takes a second or two to settle, feels drunk. | Inner loop too soft for the loop outside it, too much delay, or slop in a linkage. A heavy payload on a soft mount does it too. | Attitude lags its setpoint, then overshoots. Rate loop looks lazy, not noisy. | Wiggle every surface and arm by hand for play. Then tune from the inside out. See Flight controllers. |
| S-turns along the track. Fixed wing weaves either side of the line. | Navigation loop asking for more than the roll loop can deliver. | Cross-track error swings both ways with a period of several seconds. | Lengthen the navigation period or damping before touching roll gains. |
| Toilet bowl. Multirotor circles the hold point and the circle grows. | Heading is wrong, so every position correction is pushed sideways. Compass near a power lead, bad calibration, wrong orientation setting. | Compass heading and GPS course disagree. Magnetic field strength moves with throttle or current. | Switch to a mode that does not use position, and land. Move the compass, twist the power leads, recalibrate away from steel. See EMI and navigation. |
| Porpoise. Fixed wing climbs and slows, dives and speeds up, over and over, every five to twenty seconds. | Energy control out of tune, a leaking or lagging airspeed line, slow throttle response, or CG too far aft. | Altitude and airspeed errors swing in opposition. Pitch and throttle chase them. | Check pitot plumbing and CG first. They are faster to check than a tune, and more often the cause. See CG problems. |
| Asked for, not delivered. Leans and will not come back, loses heading in a climb, mushes on in a fast pass. | Saturation. A motor at full, a servo on its stop, or thrust that has faded with speed. The controller is right and the aircraft cannot do it. | One or more outputs pinned at a limit while the error stays. On a multirotor, yaw goes first. | Do not tune. Find the margin: less weight, more thrust, more surface, or a smaller envelope. See Control-system problems and Transition failures. |
| Wobble in a vertical descent. Multirotor or VTOL rocks as it comes down. | Descending through its own wake. | Attitude errors grow with descent rate, not with wind. | Descend slower, or with some forward speed. |
| Climbs or sinks on its own in altitude hold. | Vibration corrupting the accelerometers, or the barometer seeing prop wash, sunlight, or cabin pressure. | High vibration or clipping counts. Barometer and GPS altitude drifting apart. | Fix the mount and balance. Shield the barometer with open-cell foam. See Vibration. |
| Sudden twitch or jump in an otherwise smooth flight. | A GPS glitch, an estimator reset, or a sensor switching over. | A spike in estimator innovations. Satellite count or accuracy changes at the same instant. | Look at the sky view and the antenna location. Check what else switched on at that moment. |
| It changed mode by itself and came home or landed. | A failsafe doing its job: voltage sag under load, link loss, geofence, estimator health. | The message log names the reason and the time. | Read the message before anything else. Then go to Battery and power failures or Communications. |


- **What does it follow?** Airspeed: aerodynamics, flutter, or gains that need scaling. Throttle or RPM: vibration, power, or interference. The command: the control loop. Nothing, it comes and goes: sensors or the estimator. Answer that before changing anything.

- Airspeed: aerodynamics, flutter, or gains that need scaling. Throttle or RPM: vibration, power, or interference. The command: the control loop. Nothing, it comes and goes: sensors or the estimator. Answer that before changing anything.

Chapters behind this card: 30, 70, 69, 68, 72

## After a bad flight (field)

Use when: It crashed, landed hard, flew away, or did something nobody commanded. Read the six steps out loud. Then do them in order.

### Six steps, in order

1. Make it safe. People first. Approach from the side, away from propellers. Disarm, then disconnect the battery if you can do it without forcing anything. A crushed, punctured, or swollen pack goes on bare ground or in a metal can, outside, away from the vehicle, and gets watched for an hour. See Battery and power failures.
2. Photograph before anything moves. The whole scene, then the aircraft from four sides, then close-ups: control surface positions, propeller blades, every separation, the ground marks leading in. Photograph the transmitter switches and the ground station screen as they are.
3. Save the logs. Aircraft log, ground station log, any video. Some loggers overwrite or truncate on the next power-up, so pull the card before powering up again. Note the clock time of the event.
4. Separate notes. Each person writes what they saw and heard before anyone discusses it: what changed first, what it sounded like, which way it went. Two minutes. Memories merge the moment people start talking.
5. Conditions and configuration. Wind, temperature, site. Battery ID and charge state. Parameter file version. Most important: what changed since the last good flight. That list is usually short, and the cause is usually on it.
6. Now ask why. Start with the two sorting questions below, then go to the chapter. Hold the first theory loosely. The first explanation is wrong often enough to plan for it.


### Two sorting questions

*These send you to the right page*

| Question | Answer | Go to |
|---|---|---|
| What failed first in the log? | Voltage dropped, then everything else | Battery and power failures |
| Thrust or RPM dropped with voltage healthy | Propulsion failure |  |
| Attitude error grew while outputs were pinned | Control-system problems, Transition failures |  |
| Position or heading estimate went wrong first | EMI and navigation problems |  |
| What did the oscillation or noise follow? | Airspeed | Flutter, CG problems |
| Throttle or RPM | Vibration, What you hear |  |
| The command, or nothing at all | What the autopilot is doing |  |


- **Separate what broke in the air from what broke on the ground.** Parts found back along the flight path came off in flight. Clean, bright fractures with no dirt in them happened at impact. A failure that started earlier usually shows rubbing, discoloration, or an old crack with a dull face. See Structural failure.


Chapters behind this card: 61, 77, 65, 67, 73
