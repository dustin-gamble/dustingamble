# Symbols

*Symbols used in the equations. Subscripted forms are listed after the bare letter.*

| Symbol | Meaning | SI unit | Common other unit | First used in |
|---|---|---|---|---|
| a | Lift-curve slope of the finite wing (13). Also speed of sound, 340 m/s at sea level (12), and linear acceleration or deceleration (36, 39). | per rad; m/s; m/s² | per degree; ft/s; g | 12 Speed and maneuvering |
| a_0 | Section lift-curve slope, about 2π per radian. | per rad | per degree | 13 Lift |
| A | Total rotor disk area, all rotors counted (1, 8). Also conductor cross-section (21, 34), availability (30), and power reduction in a range check in dB (58). | m² | ft²; mm² for wire; dB | 01 A field guide to drone configurations |
| A_cap | Area of one spar cap. | m² | mm² | 15 Airfoils |
| A_e | Exit area of a ducted fan or nozzle. | m² | cm², in² | 24 Turbines and electric ducted fans |
| AR | Aspect ratio, b²/S. | none |  | 02 Read the airframe |
| b | Wingspan (2). Also an uncorrected acceleration error in the navigation drift estimate (32). | m; m/s² | ft, in | 02 Read the airframe |
| B | Magnetic field from a current-carrying lead. B_wire is one conductor, B_pair a supply and return pair. | T | µT, gauss | 32 Navigation |
| BSFC | Brake specific fuel consumption. | kg/J | g/kWh, lb/(hp·h) | 23 Piston and rotary engines |
| c | Local chord, or any reference length in a Reynolds number (5). Also the battery mass that feeds the auxiliary load in the sizing loop (48). | m; kg | in, mm | 05 Units, scaling, and quick estimates |
| c̄ | Mean aerodynamic chord of the wing. | m | in, mm | 02 Read the airframe |
| c_c | Mean chord of a control surface aft of its hinge. | m | mm, in | 17 Tails and control surfaces |
| c(N) | Cost per unit at quantity N. T_1, R_1 and T_2, R_2 are the tooling and recurring costs of the two processes being compared. | currency |  | 29 Manufacturing by quantity |
| c_p | Specific heat of air at constant pressure, 1,005 J/(kg·K). | J/(kg·K) |  | 35 Payload integration |
| c_rework | Average cost to rework one item built on a shortcut. | hours or days |  | 52 Technical debt |
| C_cell | Capacity of one cell. | A·s | Ah, mAh | 22 Batteries |
| C_D | Drag coefficient of the aircraft on wing area (14). For a parachute, on nominal canopy area (41). | none |  | 14 Drag |
| C_D0 | Zero-lift drag coefficient. | none |  | 12 Speed and maneuvering |
| C_h | Hinge moment coefficient of a control surface. | none | per degree in ch. 76 | 17 Tails and control surfaces |
| C_k | Parachute opening-load factor, opening shock and finite-mass relief combined. | none |  | 41 Parachute recovery |
| C_L | Lift coefficient. | none |  | 11 Stability and center of gravity |
| C_L,max | Maximum lift coefficient of the whole aircraft, trimmed. | none |  | 07 Wing loading |
| C_Lα | Aircraft lift-curve slope in the gust equation. Same quantity as a in ch. 13. | per rad | per degree | 26 Structural loads |
| C_loss | The stake in a bounded bet, what is lost if it fails. | days or currency |  | 56 Take the Gamble |
| C_m | Pitching moment coefficient about the CG. | none |  | 11 Stability and center of gravity |
| C_P | Propeller power coefficient, P / (ρ n³ D⁵). Static value near 0.045 at pitch-to-diameter 0.5. | none |  | 19 Propellers |
| C_repay, C_right | Cost to repay a shortcut later, and the cost of doing the job properly the first time. | hours or days |  | 52 Technical debt |
| C_T | Propeller thrust coefficient, T / (ρ n² D⁴). Static value near 0.10 at pitch-to-diameter 0.5. | none |  | 19 Propellers |
| d | Stopping distance or stroke (26, 42). Also fastener diameter (28), link range (33), distance flown before a failsafe acts (60), and spacing of a wire pair (69). | m | mm, ft, km | 26 Structural loads |
| D | Propeller or rotor diameter (3). Also drag force (14). Read by context. | m; N | in; lbf | 03 Listen to the aircraft |
| D_i | Induced drag. | N | lbf | 16 Wings |
| DL | Disk loading, T/A. In N/m² in Equation 7.1. On a mass basis in kg/m² in the 40√DL hover rule (8, 43). | N/m² | kg/m², lb/ft² | 08 Disk loading |
| e | Oswald or span efficiency factor, 0.7 to 0.85 for a complete small aircraft (12). Also nameplate pack specific energy in the sizing loop (48). | none; J/kg | Wh/kg | 12 Speed and maneuvering |
| e_b | Usable battery specific energy at pack level, nameplate times usable fraction k. | J/kg | Wh/kg (1 Wh/kg = 3,600 J/kg) | 04 Mission drives configuration |
| e_f | Fuel heating value, about 43 MJ/kg for gasoline. | J/kg | Wh/kg | 10 Energy and endurance |
| e_usable | Usable battery energy per kilogram of aircraft. | J/kg | Wh/kg | 43 VTOL as a launch and recovery system |
| E | Young’s modulus (15, 27). Also pack energy (22) and kinetic energy to absorb at capture (42). | N/m²; J | GPa, Msi; Wh | 15 Airfoils |
| EI | Bending stiffness of a spar or tube. | N·m² |  | 15 Airfoils |
| E_throw | Energy a thrower puts into a hand launch, about 100 J. | J | ft·lbf | 38 Hand launch |
| E_usable | Pack energy available to the mission after reserve, rate, temperature, and age. | J | Wh | 10 Energy and endurance |
| f | Parasite drag area, C_D0S (14). Also frequency (33, 68, 70). | m²; Hz | cm², in²; MHz | 14 Drag |
| f_b | Battery mass fraction, m_b/m. Same quantity as f_energy for an electric aircraft. | none | % | 10 Energy and endurance |
| f_BP | Blade-passage frequency, blades × RPM / 60. | Hz |  | 03 Listen to the aircraft |
| f_empty | Empty mass fraction: everything that is not payload or energy. | none | % | 06 Weight and mass properties |
| f_energy | Battery or fuel mass fraction of gross mass. | none | % | 06 Weight and mass properties |
| f_hover | Fraction of usable battery energy spent in hover. | none | % | 43 VTOL as a launch and recovery system |
| f_margin | Growth margin held as a fraction of gross mass. | none | % | 48 The first sizing |
| f_n | Natural frequency of a soft mount, (1/2π)√(k/m). | Hz |  | 31 Flight controllers |
| f_payload | Payload mass fraction. | none | % | 06 Weight and mass properties |
| f_prop | Propulsion mass fraction, less battery. | none | % | 48 The first sizing |
| f_struct | Structure mass fraction. | none | % | 48 The first sizing |
| FM | Rotor figure of merit, ideal hover power over actual shaft power. 0.5 to 0.7 for small fixed-pitch propellers. | none |  | 01 A field guide to drone configurations |
| g | Acceleration of gravity, 9.81 m/s² (9.80665 in the lookup tables). | m/s² | 32.2 ft/s² | 04 Mission drives configuration |
| G | Mass growth factor: gross mass added per unit of fixed mass added, performance held. | none |  | 06 Weight and mass properties |
| G_tx, G_rx | Transmit and receive antenna gains. | dBi |  | 33 Communications |
| h | Distance between spar cap centers (15). Also altitude in the standard atmosphere (74). | m | mm; ft | 15 Airfoils |
| H | Control surface hinge moment. | N·m | kg·cm, oz·in | 17 Tails and control surfaces |
| I | Electric current (20). Also mass moment of inertia, Σmr² (6). | A; kg·m² |  | 06 Weight and mass properties |
| I_0 | Motor no-load current. | A |  | 20 Electric motors |
| I_batt | Current a hybrid buffer battery must supply during a power peak. | A |  | 25 Hybrid propulsion and fuel cells |
| I_max | Rated continuous pack current, C rate × capacity. | A |  | 22 Batteries |
| J | Propeller advance ratio, V / (nD). | none |  | 19 Propellers |
| k | Usable fraction of nameplate pack energy, about 0.80 for a new warm pack and 0.65 over pack life (48, lookup tables). Also mass per unit of delivered energy, with k_batt and k_fuel for the two systems compared (25), and mount stiffness (31, 68). | none; kg/J; N/m | kg/kWh; N/mm | 25 Hybrid propulsion and fuel cells |
| K | Induced drag factor, 1 / (π AR e) (12). Also the measured-over-predicted correlation factor (51). | none |  | 12 Speed and maneuvering |
| K_g | Gust alleviation factor, 0.4 to 0.7 for small aircraft. | none |  | 26 Structural loads |
| K_t | Motor torque constant, 9.55 / K_v. | N·m/A | oz·in/A | 20 Electric motors |
| K_v | Motor speed constant. | rad/(s·V) | RPM/V | 20 Electric motors |
| l_H, l_V | Tail arms, wing quarter chord to horizontal and vertical tail quarter chord. | m | in, mm | 02 Read the airframe |
| L | Lift (13). Also conductor length, out and back (21, 34), bond overlap length (28), and a scale length in the scaling laws (5). | N; m | lbf; mm | 05 Units, scaling, and quick estimates |
| L/D | Lift-to-drag ratio. In cruise, with everything hanging out, 8 to 15 for small aircraft. | none |  | 01 A field guide to drone configurations |
| L_max | Most lift the wing can make at a given airspeed. | N | lbf | 71 Launch failures |
| L_path, L_other | Free-space path loss, and the sum of cable, connector, polarization, and pointing losses. | dB |  | 33 Communications |
| L_w | Wiring inductance, roughly 1 µH per metre for a separated lead. | H | µH | 34 Electrical integration |
| m | Aircraft mass, gross or takeoff (4). Also the mass of one item in an inertia sum (6) and the suspended mass on a mount (31). | kg | lb, g | 04 Mission drives configuration |
| ṁ | Air mass flow through a jet or fan. ṁ_air is cooling airflow (35) and ṁ_fuel is fuel flow (23). | kg/s | g/s, g/h | 23 Piston and rotary engines |
| m_0, m_1 | Gross mass at the start (6, 10) and mass at the end of a fuel-burning flight (10). | kg | lb | 06 Weight and mass properties |
| m_b, m_batt | Battery mass. | kg | lb, g | 04 Mission drives configuration |
| m_fixed | Mass that does not scale with the aircraft: avionics and fixed equipment (48), or the conversion hardware of a hybrid system (25). | kg | lb | 25 Hybrid propulsion and fuel cells |
| m_fuel | Usable fuel mass. | kg | g, lb | 23 Piston and rotary engines |
| m_payload | Payload mass. | kg | lb, g | 06 Weight and mass properties |
| m_sys | Mass of a complete energy system: converter plus stored energy. | kg | lb | 25 Hybrid propulsion and fuel cells |
| M_panel, M_tension | Material indices for a minimum-mass panel, E^1/3/ρ, and a member in direct stress, E/ρ. | mixed | GPa and g/cm³ as used | 27 Materials |
| M_root | Wing root bending moment. | N·m | in·lbf | 65 Structural failure |
| M_tip | Helical tip Mach number of a propeller. Quiet below 0.5. Hold below 0.7. | none |  | 12 Speed and maneuvering |
| n | Load factor, lift over weight (12). Also propeller speed in revolutions per second (19, written n_rps in ch. 12) and the number of things built on a shortcut (52). | none; 1/s | g; RPM = 60 n | 12 Speed and maneuvering |
| n_avg, n_open, n_x | Average capture deceleration (42), parachute opening load (41), and fore-and-aft launch load factor (39), all in g. | none | g | 39 Catapults and rails |
| n_max | Load factor the wing can generate at speed V, (V/V_s)². | none | g | 26 Structural loads |
| Δn | Load factor increment from a gust. | none | g | 26 Structural loads |
| N | Number of propeller blades (3). Also production quantity (29), learning cycles per year (54), and number of test repeats (61). N* is the crossover quantity between two processes. | none |  | 03 Listen to the aircraft |
| p | Static air pressure in the standard atmosphere. | Pa | hPa, inHg | 74 Units, atmosphere, and quick equations |
| p_loss | Estimated probability that a bounded bet loses its stake. | none | % | 56 Take the Gamble |
| P | Power, shaft power unless labeled (19). Also load on a joint or fastener (28) and number of cells in parallel (22). | W; N | hp; lbf | 19 Propellers |
| P_0 | Engine power at sea level. | W | kW, hp | 23 Piston and rotary engines |
| P_aux, P_hotel | Payload and avionics electrical load. Two names for the same thing. | W |  | 10 Energy and endurance |
| P_available, P_required | Thrust power available, and power required for level flight, drag × speed. P_req in ch. 12. | W | hp | 09 Power loading and thrust-to-weight |
| P_avg, P_peak, P_gen | Mission-average electrical load, peak load, and continuous generator output of a hybrid system. | W | kW | 25 Hybrid propulsion and fuel cells |
| P_compute, P_fly | Continuous power of onboard computing, and power to fly without it. | W |  | 36 Autonomy |
| P_cruise | Battery power to cruise, W V / [η (L/D)]. | W |  | 01 A field guide to drone configurations |
| P_cu, P_heat, P_loss | Resistive heating in motor windings, in a pack, and in wiring, I²R in each case. | W |  | 20 Electric motors |
| P_elec, P_electrical | Electrical power drawn from the battery. | W |  | 08 Disk loading |
| P_hover, P_ideal | Hover power. P_ideal is momentum theory with no losses, P_hover in ch. 1 is shaft power, and P_hover/m in ch. 43 is electrical power per kilogram. | W | W/kg, W/lb | 01 A field guide to drone configurations |
| P_jet | Power in the jet of a ducted fan or turbine, ½ T V_j static. | W | kW | 24 Turbines and electric ducted fans |
| P_rx, P_tx | Received and transmitted radio power. | dBm | mW, W | 33 Communications |
| P_shaft | Engine shaft power. | W | kW, hp | 23 Piston and rotary engines |
| q | Dynamic pressure, ½ρV². q_s is its value in a propeller slipstream (18). | N/m² (Pa) | lb/ft² | 14 Drag |
| Q | Motor shaft torque. Q_servo is required servo torque (76). | N·m | kg·cm, oz·in | 20 Electric motors |
| r | Distance of a mass from the rotation axis (6). Also distance from a conductor to a sensor (32, 69). r_arm and r_horn are servo arm and control horn lengths (76). | m | mm, cm | 06 Weight and mass properties |
| R | Range (4). Also turn radius (12), electrical resistance (20, 21), recurring cost per unit (29), and reliability of one mechanism in a series chain (40). | m; Ω; currency; none | km, mi, nmi; mΩ | 04 Mission drives configuration |
| R_cell, R_pack, R_total, R_wire | Resistance of one cell, of the pack (R_cell · S / P), of the whole supply path, and of a wire run. R_m in ch. 74 is motor winding resistance, plain R in ch. 20. | Ω | mΩ | 21 ESCs and electrical power |
| R_full, R_check | Estimated full-power radio range, and the distance walked in a reduced-power range check. | m | km, ft | 58 Ground test |
| R_launch | Reliability of a whole launch sequence, the product of its steps. | none | % | 40 Tube launch |
| R_sense | Range at which a sensor must reliably detect an obstacle. | m | ft | 36 Autonomy |
| Re | Reynolds number, ρVc/μ. About 68,500 × V × c at sea level in SI units. | none |  | 05 Units, scaling, and quick estimates |
| RPM | Shaft speed in revolutions per minute, 60 n. | rad/s | RPM | 03 Listen to the aircraft |
| s | Powered stroke of a launcher. s_g and s_L are takeoff and landing ground roll (37). | m | ft | 37 Runways and conventional landing |
| S | Wing reference area (2). Also number of cells in series (22). | m²; none | ft², dm², in² | 02 Read the airframe |
| S_0 | Nominal parachute canopy area. | m² | ft² | 41 Parachute recovery |
| S_c | Area of a control surface aft of its hinge. | m² | cm², in² | 17 Tails and control surfaces |
| S_H, S_V | Horizontal and vertical tail areas. For a V-tail, the projected areas. | m² | dm², in² | 02 Read the airframe |
| SM | Static margin, (x_np − x_cg) / c̄. | none | % MAC | 11 Stability and center of gravity |
| t | Time, endurance (10). Also laminate thickness (28). t_0 is the still-air or baseline time (36, 44). | s; m | h, min; mm | 10 Energy and endurance |
| t* | Crossover endurance at which a hybrid or fuel system beats a battery. | s | h | 25 Hybrid propulsion and fuel cells |
| t_apex | Time from tube exit to the top of the launch arc. | s |  | 40 Tube launch |
| t_detect, t_respond, t_lat | Failsafe detection time, time for the response to take effect (60), and total sensing-to-thrust latency (36). | s | ms | 36 Autonomy |
| t_hover | Hover time. | s | min, h in Equation 42.1 | 04 Mission drives configuration |
| t_station, t_endurance, t_reserve | Time on station, total endurance, and reserve time. | s | min, h | 45 Start with the mission |
| T | Thrust (8). Also tooling cost (29), air temperature (57, 74), and mount transmissibility (68). T_max is thrust at the motor RPM limit (44) and T_rotor is vertical rotor thrust in transition (72). | N; currency; K; none | lbf, kgf, g; °C | 08 Disk loading |
| T/W | Thrust-to-weight ratio, static unless stated. | none |  | 09 Power loading and thrust-to-weight |
| T_amb, ΔT_ss | Ambient temperature and steady-state temperature rise in a thermal run. ΔT in ch. 35 is allowed cooling-air temperature rise. | K | °C, °F | 35 Payload integration |
| T_between, T_repair | Flying time between damage events, and time to return to service. | s | h | 30 Designing for repair |
| T_loop | Time from having an idea to knowing, from hardware, whether it was right. | s | weeks | 54 Schedule learning |
| U | Gust velocity. | m/s | ft/s | 26 Structural loads |
| v | Closing velocity at impact or against an obstacle. | m/s | ft/s, kt | 26 Structural loads |
| V | True airspeed (1). Also voltage applied to a motor (20). | m/s; V | kt, mph, ft/s | 01 A field guide to drone configurations |
| ΔV | Voltage drop in wiring, I R steady or L_w dI/dt transient. | V | mV | 21 ESCs and electrical power |
| V_0 | Flight speed in the jet propulsion equations (24). Also release speed in a hand launch (38). | m/s | kt, mph | 24 Turbines and electric ducted fans |
| V_bus | Electrical bus voltage of a hybrid system. | V |  | 25 Hybrid propulsion and fuel cells |
| V_c | Closing speed relative to a net, rope, or other capture device. | m/s | kt | 42 Nets, arrestment, and capture |
| V_climb | Vertical speed in a steady climb. | m/s | ft/min | 09 Power loading and thrust-to-weight |
| V_d, V_deploy | Steady parachute descent rate, and airspeed at line stretch. | m/s | ft/s | 41 Parachute recovery |
| V_exit | Speed at the end of a launcher rail or tube. | m/s | kt, mph | 39 Catapults and rails |
| V_H, V_V | Horizontal and vertical tail volume coefficients. | none |  | 02 Read the airframe |
| V_j | Fully expanded jet or wake velocity. | m/s | ft/s | 24 Turbines and electric ducted fans |
| V_learn | What the answer to a bet is worth, in work saved or redirected. | days or currency |  | 56 Take the Gamble |
| V_LO, V_TD | Liftoff speed, 1.1 to 1.2 V_s, and touchdown speed, about 1.15 V_s. | m/s | kt, mph | 37 Runways and conventional landing |
| V_nom, V_oc, V_load | Nominal cell voltage, open-circuit pack voltage at the present state of charge, and pack voltage under load. | V |  | 22 Batteries |
| V_out, V_back | Ground speeds on the outbound and return legs, wind included. | m/s | kt | 45 Start with the mission |
| V_s | Stall speed at 1 g. V_s,turn = V_s√n in a level turn (12). | m/s | kt, mph | 05 Units, scaling, and quick estimates |
| V_tip | Static propeller tip speed, πD · RPM / 60. | m/s | ft/s | 03 Listen to the aircraft |
| V_wind | Headwind component at launch. | m/s | kt, mph | 38 Hand launch |
| w | Wind speed along track (44). Also bond width (28) and usable net width (42). | m/s; m | kt, mph; mm | 28 Joining |
| W | Weight, m g. | N | lbf | 01 A field guide to drone configurations |
| W/A | Disk loading on a weight basis. Same quantity as DL. | N/m² | kg/m², lb/ft² | 01 A field guide to drone configurations |
| W/S | Wing loading. | N/m² | kg/m², g/dm², oz/ft², lb/ft² | 07 Wing loading |
| x_cg, x_np, x_p | Stations of the CG, the neutral point, and a payload, measured aft from one datum. Δx_cg is CG shift from a mass change, and Δm is that mass (35). | m | mm, in, % MAC | 11 Stability and center of gravity |
| δx, Δx | Position drift from an uncorrected acceleration error (32), and apparent error between two misaligned records, (dx/dt) · Δt (61). | m; signal units |  | 32 Navigation |
| ȳ | Spanwise center of lift on one wing panel, about 0.42 of the semi-span for near-elliptic loading. | m | mm, in | 65 Structural failure |
| δ | Control surface deflection. | rad | degrees | 76 Materials, electrical, and hardware tables |
| η | Efficiency. Bare η is the whole chain from battery to thrust power, 0.4 to 0.6 and typically 0.5 (1). In ch. 19 it is propeller efficiency alone. | none | % | 01 A field guide to drone configurations |
| η_drive | Motor and ESC efficiency together, 0.80 to 0.90 near the design point. | none | % | 04 Mission drives configuration |
| η_p | Installed propeller efficiency (10). In ch. 24, ideal propulsive efficiency of a jet. | none | % | 10 Energy and endurance |
| η_th | Engine thermal efficiency, 0.15 to 0.25 for small engines. | none | % | 10 Energy and endurance |
| θ | Attitude or tilt error (32). Also launch tube elevation above horizontal (40). | rad | degrees | 32 Navigation |
| μ | Dynamic viscosity of air, 1.79 × 10⁻⁵ Pa·s at 15 °C (5). Also rolling friction coefficient of a surface, with μ_eff for all retarding effects at landing (37). | Pa·s; none |  | 05 Units, scaling, and quick estimates |
| μ_0 | Permeability of free space, 4π × 10⁻⁷ T·m/A. | T·m/A |  | 32 Navigation |
| ρ | Air density, 1.225 kg/m³ at sea level standard (1). Also material density in the material indices (27). | kg/m³ | slug/ft³; g/cm³ | 01 A field guide to drone configurations |
| ρ_Cu | Resistivity of copper, 1.72 × 10⁻⁸ Ω·m at 20 °C. | Ω·m | 0.0172 Ω·mm²/m | 21 ESCs and electrical power |
| σ | Density ratio, ρ/ρ₀ (23). Also one-sigma path error at a net (42) and run-to-run scatter, with σ_mean = σ/√N (61). | none; m; as measured |  | 23 Piston and rotary engines |
| σ_br | Bearing stress under a fastener, P / (d t). | N/m² | MPa, psi | 28 Joining |
| τ | Thermal time constant (57). Also total pure delay in a control loop (70). | s | min; ms | 57 Bench test |
| τ_avg | Average shear stress in a bonded lap, P / (w L). | N/m² | MPa, psi | 28 Joining |
| φ | Bank angle (12). Also phase lag from a delay, 360° · f · τ (70). | rad | degrees | 12 Speed and maneuvering |
| ω_inner, ω_outer | Closed-loop bandwidths of an inner control loop and the loop wrapped around it. | rad/s | Hz | 31 Flight controllers |
