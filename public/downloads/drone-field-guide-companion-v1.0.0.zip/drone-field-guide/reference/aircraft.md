# Real aircraft

42 small unmanned aircraft with published figures (manufacturer datasheets and public sources, retrieved 2026-09-20). Approximate; use for sanity checks and trend lines, not as design data.

| name | category | launch | recovery | propulsion | mtow_kg | payload_kg | span_m | rotor_diameter_m | rotor_count | endurance_min | cruise_ms | max_speed_ms | range_km | battery_wh |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| AeroVironment RQ-11B Raven (Raven B) | fixed-wing | hand | autonomous deep-stall landing | electric | 2.2 |  | 1.4 |  |  | 75 | 8.9 | 22.5 | 10 |  |
| AeroVironment Puma 3 AE | fixed-wing | hand | autonomous deep-stall landing (land or water); optional VTOL kit | electric | 7.1 | 1.8 | 2.8 |  |  | 180 | 13.1 | 21.1 | 20 |  |
| AeroVironment (Arcturus) JUMP 20 | vtol-fixed-wing | vtol | vertical landing | hybrid | 97.5 | 13.6 | 5.7 |  |  | 780 |  |  | 185 |  |
| Insitu ScanEagle | fixed-wing | catapult | SkyHook rope capture (FLARES VTOL kit optional) | piston | 28 | 8 | 3.1 |  |  | 1080 |  | 41.2 |  |  |
| Insitu Integrator (RQ-21A Blackjack family) | fixed-wing | catapult | SkyHook rope capture (FLARES VTOL kit optional) | piston | 79 | 23 | 4.9 |  |  | 1650 |  | 46 |  |  |
| AAI RQ-7B Shadow 200 | fixed-wing | catapult | arresting cable and tailhook; wheeled landing possible | piston | 170 |  | 4.27 |  |  | 420 | 30.8 | 53.9 |  |  |
| Textron Aerosonde Mk 4.7 Fixed Wing | fixed-wing | catapult | net recovery | piston | 42.2 | 14.5 | 4.4 |  |  | 1098 |  | 33.4 | 140 |  |
| Textron Aerosonde Mk 4.7 VTOL (HQ) | vtol-fixed-wing | vtol | vertical landing (hybrid quadrotor) | hybrid | 53.5 | 10.4 | 4.4 |  | 4 | 540 |  | 33.4 | 140 |  |
| Textron Aerosonde Mk 4.8 VTOL (HQ) | vtol-fixed-wing | vtol | vertical landing (hybrid quadrotor) | hybrid | 97.5 | 20.4 | 5.19 |  | 4 | 894 |  |  |  |  |
| Lockheed Martin Stalker XE | fixed-wing | catapult | belly landing (VTOL kit optional) | fuel-cell |  |  | 3.7 |  |  | 480 | 15.6 | 20.0 | 370 |  |
| Lockheed Martin Stalker VXE30 (Redwire Stalker Block 30) | vtol-fixed-wing | vtol | autonomous vertical landing | fuel-cell | 22 |  | 4.9 |  |  | 480 | 15.4 | 25.7 | 160 |  |
| Lockheed Martin Stalker VXE (2022 endurance record configuration) | vtol-fixed-wing | vtol | vertical landing | fuel-cell |  |  |  |  |  | 2357.1 |  |  |  |  |
| AgEagle (senseFly) eBee X | fixed-wing | hand | automatic linear belly landing | electric | 1.6 |  | 1.16 |  |  | 90 |  | 30 | 55 |  |
| Wingtra WingtraOne GEN II | vtol-fixed-wing | vtol | vertical landing (tail-sitter) | electric | 4.8 | 0.8 |  |  |  | 59 | 16 |  |  |  |
| DeltaQuad Evo | vtol-fixed-wing | vtol | vertical landing (quadplane) | electric | 10 | 3 | 2.69 |  |  | 272 | 16.54 |  | 270 |  |
| Wingcopter 198 | vtol-fixed-wing | vtol | vertical landing (tilt-rotor) | electric | 25 | 4.7 | 1.98 |  |  |  | 25 |  | 94 |  |
| Shield AI V-BAT | vtol-fixed-wing | vtol | vertical tail-sitter landing, ducted fan | piston | 75 | 18.1 | 3.8 |  | 1 | 720 |  |  | 180 |  |
| Edge Autonomy Penguin Mk2X (Penguin C lineage) | fixed-wing | catapult | parachute and airbag | piston | 32 |  | 3.3 |  |  | 1200 | 20.6 | 30.9 | 180 |  |
| Edge Autonomy Penguin Mk2.5 VTOL | vtol-fixed-wing | vtol | autonomous vertical landing | hybrid | 41 |  | 4.12 |  |  | 720 | 23.1 | 33.4 | 180 |  |
| Edge Autonomy Penguin Mk3 VTOL | vtol-fixed-wing | vtol | autonomous vertical landing on integrated gear | hybrid | 49 | 8 | 5.0 |  |  | 840 | 23.1 | 30.9 | 180 |  |
| Elbit Systems Skylark I-LEX | fixed-wing | hand | airborne airbag point recovery | electric | 7.5 | 1.2 |  |  |  | 180 |  |  | 40 |  |
| AeroVironment Wasp III (BATMAV) | fixed-wing | hand | horizontal belly landing, land or water | electric | 0.43 |  | 0.72 |  |  | 45 |  | 18.1 | 5 |  |
| AeroVironment RQ-12A Wasp AE | fixed-wing | hand | deep-stall / belly landing, land or water | electric | 1.3 |  | 1.02 |  |  | 50 |  | 23.1 | 5 |  |
| Lockheed Martin Desert Hawk (original FPASS) | fixed-wing | other | belly landing | electric | 3.2 |  | 1.32 |  |  | 60 |  | 25.6 |  |  |
| AeroVironment Blackwing | fixed-wing | tube | expendable / not stated | electric | 1.81 |  | 0.686 |  |  |  |  |  |  |  |
| ETH Zurich AtlantikSolar AS-2 | fixed-wing | hand | belly landing | solar-electric | 6.93 | 0.9 | 5.69 |  |  | 4860 | 8.6 |  | 2338 | 733 |
| Aerosonde Mk 1 'Laima' (1998 Atlantic crossing) | fixed-wing | other | belly landing (no undercarriage) | piston | 13 |  | 2.9 |  |  | 1605 | 20.0 |  | 3270 |  |
| Zipline Platform 1 'Zip' | fixed-wing | catapult | tail hook catches arresting line | electric | 20 | 1.8 |  |  |  |  | 28.1 |  | 300 |  |
| Tekever AR5 | fixed-wing | runway | unprepared airstrip | piston |  | 50 | 7.3 |  |  | 1200 | 27.8 |  |  |  |
| DJI Mini 4 Pro | multirotor | vtol | vertical landing | electric | 0.249 |  |  |  | 4 | 34 |  | 16 | 18 | 18.96 |
| Parrot ANAFI USA | multirotor | vtol | vertical landing | electric | 0.644 |  |  |  | 4 | 32 |  | 14.7 |  | 39.3 |
| DJI Mavic 3 Enterprise (Mavic 3E) | multirotor | vtol | vertical landing | electric | 1.05 |  |  |  | 4 | 45 |  | 21 | 32 | 77 |
| Teal 2 | multirotor | vtol | vertical landing | electric | 1.25 |  |  |  | 4 | 30 |  | 10 | 5 |  |
| Skydio X10 | multirotor | vtol | vertical landing | electric | 2.49 |  |  |  | 4 | 40 |  | 20 |  |  |
| Lockheed Martin Indago 4 | multirotor | vtol | vertical landing | electric |  | 2.27 |  |  | 4 | 70 |  |  | 10 |  |
| Freefly Astro (Astro Max spec sheet) | multirotor | vtol | vertical landing | electric | 8.7 | 3.0 |  | 0.559 | 4 | 39 |  |  |  |  |
| DJI Matrice 350 RTK | multirotor | vtol | vertical landing | electric | 9.2 | 2.73 |  |  | 4 | 55 |  | 23 |  | 526.4 |
| Freefly Alta X | multirotor | vtol | vertical landing | electric | 34.86 | 15.06 |  | 0.84 | 4 |  |  |  |  |  |
| Yamaha R-MAX | helicopter | vtol | vertical landing on skids | piston | 94 | 28 |  | 3.115 | 1 | 60 |  |  |  |  |
| Schiebel CAMCOPTER S-100 | helicopter | vtol | automatic vertical landing, incl. ship decks | piston | 200 | 50 |  | 3.4 | 1 | 600 | 28.3 | 61.7 | 200 |  |
| UAV Factory Penguin B | fixed-wing | runway | runway landing on wheeled gear | piston | 21.5 | 10 | 3.3 |  |  | 1200 | 22 | 36 |  |  |
| UAV Factory Penguin C | fixed-wing | catapult | parachute and airbag | piston | 22.5 |  | 3.3 |  |  | 1200 | 22 | 32 | 100 |  |
