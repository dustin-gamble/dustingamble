# Equations

Every numbered equation, in plain text and TeX. SI units unless the label says otherwise. Symbols are in symbols.md.

## Chapter 1 · A field guide to drone configurations
- **1.1 · Power to cruise on a wing**
  plain: `P_cruise = W V / [ η (L/D) ]`
  tex: `P_{\mathrm{cruise}} = \frac{W V}{\eta (L/D)}`
- **1.2 · Power to hover on a disk (shaft power)**
  plain: `P_hover ≈ (W / FM) √[ (W/A) / 2ρ ]`
  tex: `P_{\mathrm{hover}} \approx \left(\frac{W}{\mathrm{FM}}\right) \sqrt{ (W/A) / 2\rho }`

## Chapter 2 · Read the airframe
- **2.1 · Aspect ratio**
  plain: `AR = b² / S`
  tex: `\mathrm{AR} = \frac{b^{2}}{S}`
- **2.2 · Horizontal tail volume coefficient**
  plain: `V_H = S_H l_H / (S c̄)`
  tex: `V_{H} = \frac{S_{H} l_{H}}{S c̄}`

## Chapter 3 · Mission drives configuration
- **3.1 · Electric range: the battery form of the Breguet range equation**
  plain: `R = (e_b / g) · η · (L/D) · (m_b / m)`
  tex: `R = \left(\frac{e_{b}}{g}\right) \cdot \eta \cdot (L/D) \cdot \left(\frac{m_{b}}{m}\right)`
- **3.2 · Electric hover endurance**
  plain: `t_hover = (e_b / g) · (m_b / m) · FM η_drive · √[ 2ρ / (W/A) ]`
  tex: `t_{\mathrm{hover}} = \left(\frac{e_{b}}{g}\right) \cdot \left(\frac{m_{b}}{m}\right) \cdot \mathrm{FM} \eta _{\mathrm{drive}} \cdot \sqrt{ 2\rho / (W/A) }`

## Chapter 4 · Units, scaling, and quick estimates
- **4.1 · Reynolds number, sea level standard air**
  plain: `Re = ρ V c / μ ≈ 68,500 · V · c`
  tex: `\mathrm{Re} = \frac{\rho V c}{\mu} \approx 68{,}500 \cdot V \cdot c`
- **4.2 · Geometric scaling at constant density of construction**
  plain: `S ∝ L² m ∝ L³ W/S ∝ L V_s ∝ √L`
  tex: `S \propto L^{2} \qquad m \propto L^{3} \qquad W/S \propto L \qquad V_{s} \propto \sqrt{L}`

## Chapter 5 · Weight and mass properties
- **5.1 · Gross mass from payload, and what one added kilogram costs**
  plain: `m_0 = m_payload / (1 − f_empty − f_energy) G = 1 / f_payload`
  tex: `m_{0} = \frac{m_{\mathrm{payload}}}{(1 - f_{\mathrm{empty}} - f_{\mathrm{energy}}) \qquad G} = \frac{1}{f_{\mathrm{payload}}}`
- **5.2 · Moment of inertia about an axis through the CG**
  plain: `I = Σ m r² angular acceleration = moment / I`
  tex: `I = \Sigma m r^{2} \qquad \text{ angular acceleration } = \text{ moment } \frac{}{I}`

## Chapter 6 · Wing loading
- **6.1 · Wing loading**
  plain: `W / S = m g / S`
  tex: `\frac{W}{S} = \frac{m g}{S}`
- **6.2 · Stall speed from wing loading**
  plain: `V_s = √[ 2(W/S) / (ρ C_L,max) ]`
  tex: `V_{s} = \sqrt{ 2(W/S) / (\rho C_{L,\max }) }`

## Chapter 7 · Disk loading
- **7.1 · Disk loading and ideal hover power**
  plain: `DL = T / A P_ideal = T^1.5 / √(2ρA) = T · √(DL / 2ρ)`
  tex: `\mathrm{DL} = \frac{T}{A \qquad P_{\mathrm{ideal}}} = \frac{T^{1.5}}{\sqrt{2\rho A}} = T \cdot \sqrt{\mathrm{DL} / 2\rho }`
- **7.2 · From ideal power to what the battery sees**
  plain: `P_electrical = P_ideal / (FM · η_drive)`
  tex: `P_{\mathrm{electrical}} = \frac{P_{\mathrm{ideal}}}{\mathrm{FM} \cdot \eta _{\mathrm{drive}}}`

## Chapter 8 · Power loading and thrust-to-weight
- **8.1 · Thrust-to-weight for a steady climb at shallow angles**
  plain: `T / W = 1 / (L/D) + V_climb / V`
  tex: `\frac{T}{W} = \frac{1}{L/D} + \frac{V_{\mathrm{climb}}}{V}`
- **8.2 · Climb rate from excess power**
  plain: `V_climb = (P_available − P_required) / W`
  tex: `V_{\mathrm{climb}} = \frac{P_{\mathrm{available}} - P_{\mathrm{required}}}{W}`

## Chapter 9 · Energy and endurance
- **9.1 · Electric endurance from the power budget**
  plain: `t = E_usable / P_elec P_elec = W·V / [ (L/D) · η_p · η_drive ] + P_hotel`
  tex: `t = \frac{E_{\mathrm{usable}}}{P_{\mathrm{elec}} \qquad P_{\mathrm{elec}}} = \frac{W\cdot V}{(L/D) \cdot \eta _{p} \cdot \eta _{\mathrm{drive}}} + P_{\mathrm{hotel}}`
- **9.2 · Electric range, the battery form of the Breguet equation**
  plain: `R = (e_b / g) · f_b · η_p η_drive · (L/D) R [km] ≈ 0.37 · e_b [Wh/kg] · f_b · η · (L/D)`
  tex: `R = \left(\frac{e_{b}}{g}\right) \cdot f_{b} \cdot \eta _{p} \eta _{\mathrm{drive}} \cdot (L/D) \qquad R [\mathrm{km}] \approx 0.37 \cdot e_{b} [\mathrm{Wh}/\mathrm{kg}] \cdot f_{b} \cdot \eta \cdot (L/D)`
- **9.3 · Fuel-based endurance at constant speed and L/D**
  plain: `t = (e_f · η_th · η_p / g) · (L/D) · (1/V) · ln(m_0 / m_1)`
  tex: `t = \left(\frac{e_{f} \cdot \eta _{\mathrm{th}} \cdot \eta _{p}}{g}\right) \cdot (L/D) \cdot (1/V) \cdot \ln \left(\frac{m_{0}}{m_{1}}\right)`

## Chapter 10 · Stability and center of gravity
- **10.1 · Static margin and the slope of the pitching moment curve**
  plain: `SM = (x_np − x_cg) / c̄ dC_m / dC_L = −SM`
  tex: `\mathrm{SM} = (x_{\mathrm{np}} - x_{\mathrm{cg}}) / c̄ \qquad \mathrm{dC}_{m} / \mathrm{dC}_{L} = - \mathrm{SM}`
- **10.2 · Horizontal and vertical tail volume coefficients**
  plain: `V_H = S_H · l_H / (S · c̄) V_V = S_V · l_V / (S · b)`
  tex: `V_{H} = \frac{S_{H} \cdot l_{H}}{(S \cdot c̄) \qquad V_{V}} = \frac{S_{V} \cdot l_{V}}{S \cdot b}`

## Chapter 11 · Speed and maneuvering
- **11.1 · Power required for level flight, parasite plus induced**
  plain: `P_req = ½ρV³ S C_D0 + K W² / (½ρV S) K = 1 / (π · AR · e)`
  tex: `P_{\mathrm{req}} = \tfrac{1}{2}\rho V^{3} S C_{D0} + \frac{K W^{2}}{(\tfrac{1}{2}\rho V S) \qquad K} = \frac{1}{\pi \cdot \mathrm{AR} \cdot e}`
- **11.2 · Turn radius, load factor, and stall speed in a level turn**
  plain: `R = V² / (g · tan φ) n = 1 / cos φ V_s,turn = V_s · √n`
  tex: `R = \frac{V^{2}}{(g \cdot} \tan \phi) \qquad n = \frac{1}{} \cos \phi \qquad V_{s,\text{ turn }} = V_{s} \cdot \sqrt{n}`
- **11.3 · Helical tip Mach number**
  plain: `M_tip = √[ (π · n_rps · D)² + V² ] / a`
  tex: `M_{\mathrm{tip}} = \frac{\sqrt{ (\pi \cdot n_{\mathrm{rps}} \cdot D)^{2} + V^{2} }}{a}`

## Chapter 12 · Lift
- **12.1 · Lift**
  plain: `L = ½ ρ V² S C_L`
  tex: `L = \tfrac{1}{2} \rho V^{2} S C_{L}`
- **12.2 · Lift-curve slope of a finite wing**
  plain: `a = a_0 / [ 1 + a_0 / (π e AR) ]`
  tex: `a = \frac{a_{0}}{\left[1 + \frac{a_{0}}{\pi e \mathrm{AR}}\right]}`
- **12.3 · Chord Reynolds number, sea level, V in m/s, c in m**
  plain: `Re = ρ V c / μ ≈ 68,500 · V · c`
  tex: `\mathrm{Re} = \frac{\rho V c}{\mu} \approx 68{,}500 \cdot V \cdot c`

## Chapter 13 · Drag
- **13.1 · Parabolic drag polar**
  plain: `C_D = C_D0 + C_L² / (π e AR)`
  tex: `C_{D} = C_{D0} + \frac{C_{L}^{2}}{\pi e \mathrm{AR}}`
- **13.2 · Drag in level flight**
  plain: `D = q f + W² / (q π e b²)`
  tex: `D = q f + \frac{W^{2}}{q \pi e b^{2}}`

## Chapter 14 · Airfoils
- **14.1 · Bending stiffness of a two-cap spar**
  plain: `EI ≈ E A_cap h² / 2`
  tex: `\mathrm{EI} \approx \frac{E A_{\mathrm{cap}} h^{2}}{2}`

## Chapter 15 · Wings
- **15.1 · Induced drag in level flight**
  plain: `D_i = W² / (q π e b²)`
  tex: `D_{i} = \frac{W^{2}}{q \pi e b^{2}}`

## Chapter 16 · Tails and control surfaces
- **16.1 · Horizontal and vertical tail volume coefficients**
  plain: `V_H = S_H l_H / (S c̄) V_V = S_V l_V / (S b)`
  tex: `V_{H} = \frac{S_{H} l_{H}}{(S c̄) \qquad V_{V}} = \frac{S_{V} l_{V}}{S b}`
- **16.2 · Control surface hinge moment**
  plain: `H = C_h · q · S_c · c_c`
  tex: `H = C_{h} \cdot q \cdot S_{c} \cdot c_{c}`

## Chapter 17 · Configuration aerodynamics
- **17.1 · Dynamic pressure in a fully developed slipstream**
  plain: `q_s / q = 1 + T / (q · A) q = ½ρV²`
  tex: `\frac{q_{s}}{q} = 1 + \frac{T}{(q \cdot A) \qquad q} = \tfrac{1}{2}\rho V^{2}`
- **17.2 · Who carries the weight during a VTOL transition**
  plain: `Wing share = (C_L / C_L,max) · (V / V_s)² Rotor share = 1 − wing share`
  tex: `\text{ Wing share } = \left(\frac{C_{L}}{C_{L,} \max }\right) \cdot \left(\frac{V}{V_{s}}\right)^{2} \qquad \text{ Rotor share } = 1 - \text{ wing share }`

## Chapter 18 · Propellers
- **18.1 · Advance ratio, thrust, and shaft power**
  plain: `J = V / (n D) T = C_T ρ n² D⁴ P = C_P ρ n³ D⁵`
  tex: `J = \frac{V}{(n D) \qquad T} = C_{T} \rho n^{2} D^{4} \qquad P = C_{P} \rho n^{3} D^{5}`
- **18.2 · Propeller efficiency**
  plain: `η = T V / P = J · C_T / C_P`
  tex: `\eta = \frac{T V}{P} = \frac{J \cdot C_{T}}{C_{P}}`

## Chapter 19 · Electric motors
- **19.1 · Speed constant and torque constant are the same number**
  plain: `RPM ≈ K_v (V − I R) K_t = 60 / (2π K_v) ≈ 9.55 / K_v`
  tex: `\mathrm{RPM} \approx K_{v} (V - I R) \qquad K_{t} = \frac{60}{2\pi K_{v}} \approx \frac{9.55}{K_{v}}`
- **19.2 · Current from torque, and where the losses go**
  plain: `I ≈ Q / K_t + I_0 P_heat ≈ I² R + I_0 (V − I R)`
  tex: `I \approx \frac{Q}{K_{t}} + I_{0} \qquad P_{\mathrm{heat}} \approx I^{2} R + I_{0} (V - I R)`

## Chapter 20 · ESCs and electrical power
- **20.1 · Voltage drop and heating in wiring**
  plain: `ΔV = I R P_loss = I² R R_wire = ρ_Cu L / A`
  tex: `\Delta V = I R \qquad P_{\mathrm{loss}} = I^{2} R \qquad R_{\mathrm{wire}} = \frac{\rho _{\mathrm{Cu}} L}{A}`

## Chapter 21 · Batteries
- **21.1 · Pack energy and rated current**
  plain: `E = S · V_nom · P · C_cell I_max = (C rate) · P · C_cell`
  tex: `E = S \cdot V_{\mathrm{nom}} \cdot P \cdot C_{\mathrm{cell}} \qquad I_{\mathrm{max}} = (C \text{ rate }) \cdot P \cdot C_{\mathrm{cell}}`
- **21.2 · Voltage sag and heating**
  plain: `V_load = V_oc − I · R_pack R_pack ≈ R_cell · S / P P_heat = I² R_pack`
  tex: `V_{\mathrm{load}} = V_{\mathrm{oc}} - I \cdot R_{\mathrm{pack}} \qquad R_{\mathrm{pack}} \approx \frac{R_{\mathrm{cell}} \cdot S}{P \qquad P_{\mathrm{heat}}} = I^{2} R_{\mathrm{pack}}`

## Chapter 22 · Piston and rotary engines
- **22.1 · Fuel flow and endurance at constant power**
  plain: `ṁ_fuel = BSFC · P_shaft t ≈ m_fuel / (BSFC · P_shaft)`
  tex: `ṁ_{\mathrm{fuel}} = \mathrm{BSFC} \cdot P_{\mathrm{shaft}} \qquad t \approx \frac{m_{\mathrm{fuel}}}{\mathrm{BSFC} \cdot P_{\mathrm{shaft}}}`
- **22.2 · Gagg and Ferrar altitude correction, naturally aspirated**
  plain: `P / P_0 ≈ 1.132 σ − 0.132`
  tex: `\frac{P}{P_{0}} \approx 1.132 \sigma - 0.132`

## Chapter 23 · Turbines and electric ducted fans
- **23.1 · Thrust and ideal propulsive efficiency**
  plain: `T = ṁ (V_j − V_0) η_p = 2 / (1 + V_j / V_0)`
  tex: `T = ṁ (V_{j} - V_{0}) \qquad \eta _{p} = \frac{2}{\left(1 + \frac{V_{j}}{V_{0}}\right)}`
- **23.2 · Static thrust and jet power for a ducted fan**
  plain: `T = ρ A_e V_j² P_jet = ½ T V_j T / P_jet = 2 / V_j`
  tex: `T = \rho A_{e} V_{j}^{2} \qquad P_{\mathrm{jet}} = \frac{\tfrac{1}{2} T V_{j} \qquad T}{P_{\mathrm{jet}}} = \frac{2}{V_{j}}`

## Chapter 24 · Hybrid propulsion and fuel cells
- **24.1 · System mass and the crossover endurance against a battery**
  plain: `m_sys = m_fixed + k · P_avg · t t* = (m_fixed / P_avg) / (k_batt − k_fuel)`
  tex: `m_{\mathrm{sys}} = m_{\mathrm{fixed}} + k \cdot P_{\mathrm{avg}} \cdot t \qquad t* = \frac{\left(\frac{m_{\mathrm{fixed}}}{P_{\mathrm{avg}}}\right)}{k_{\mathrm{batt}} - k_{\mathrm{fuel}}}`
- **24.2 · Generator power and battery peak current**
  plain: `P_gen ≥ (1 + margin) · P_avg I_batt = (P_peak − P_gen) / V_bus`
  tex: `P_{\mathrm{gen}} \geq (1 + \text{ margin }) \cdot P_{\mathrm{avg}} \qquad I_{\mathrm{batt}} = \frac{P_{\mathrm{peak}} - P_{\mathrm{gen}}}{V_{\mathrm{bus}}}`

## Chapter 25 · Structural loads
- **25.1 · Load factor the wing can generate at speed V, with 1g stall speed V_s**
  plain: `n_max = (V / V_s)²`
  tex: `n_{\mathrm{max}} = \left(\frac{V}{V_{s}}\right)^{2}`
- **25.2 · Gust load factor increment**
  plain: `Δn = K_g ρ U V C_Lα / [ 2 (W/S) ]`
  tex: `\Delta n = \frac{K_{g} \rho U V C_{L\alpha }}{2 (W/S)}`
- **25.3 · Average deceleration in g, from closing velocity v (m/s) and stopping distance d (m)**
  plain: `n ≈ v² / (2 g d)`
  tex: `n \approx \frac{v^{2}}{2 g d}`

## Chapter 26 · Materials
- **26.1 · Material index for a tie, a spar cap, or a tube wall in direct stress**
  plain: `M_tension = E / ρ`
  tex: `M_{\mathrm{tension}} = \frac{E}{\rho}`
- **26.2 · Material index for a panel of minimum mass at a given bending stiffness**
  plain: `M_panel = E^1/3 / ρ`
  tex: `M_{\mathrm{panel}} = \frac{E^{1/3}}{\rho}`

## Chapter 27 · Joining
- **27.1 · Average bond shear stress: load P (N), bond width w and overlap length L (mm), result in MPa**
  plain: `τ_avg = P / (w L)`
  tex: `\tau _{\mathrm{avg}} = \frac{P}{w L}`
- **27.2 · Bearing stress: load per fastener P (N), fastener diameter d and laminate thickness t (mm), result in MPa**
  plain: `σ_br = P / (d t)`
  tex: `\sigma _{\mathrm{br}} = \frac{P}{d t}`

## Chapter 28 · Manufacturing by quantity
- **28.1 · Cost per unit: tooling T, quantity N, recurring cost per unit R**
  plain: `c(N) = T / N + R`
  tex: `c(N) = \frac{T}{N} + R`
- **28.2 · Crossover quantity between a low-tooling process 1 and a high-tooling process 2**
  plain: `N* = (T_2 − T_1) / (R_1 − R_2)`
  tex: `N* = \frac{T_{2} - T_{1}}{R_{1} - R_{2}}`

## Chapter 29 · Designing for repair
- **29.1 · Availability: flying time between damage events, and time to return to service, in the same units**
  plain: `A = T_between / (T_between + T_repair)`
  tex: `\text{A } = \frac{T_{\mathrm{between}}}{T_{\mathrm{between}} + T_{\mathrm{repair}}}`

## Chapter 30 · Flight controllers
- **30.1 · Bandwidth separation between nested loops**
  plain: `ω_outer ≲ ω_inner / 3 to 5`
  tex: `\frac{\omega _{\mathrm{outer}} ≲ \omega _{\mathrm{inner}}}{3 \text{ to } 5}`
- **30.2 · Natural frequency of a soft-mounted controller**
  plain: `f_n = (1 / 2π) √(k / m) isolation only above √2 · f_n`
  tex: `f_{n} = \left(\frac{1}{2\pi}\right) \sqrt{k / m} \qquad \text{ isolation only above } \sqrt{2} \cdot f_{n}`

## Chapter 31 · Navigation
- **31.1 · Position drift from an uncorrected acceleration error**
  plain: `δx ≈ ½ · b · t² with b ≈ g · θ for a tilt error θ`
  tex: `\delta x \approx \tfrac{1}{2} \cdot b \cdot t^{2} \qquad \text{ with } b \approx g \cdot \theta \text{ for } a \text{ tilt error } \theta`
- **31.2 · Magnetic field at distance r from a single straight conductor**
  plain: `B = μ_0 I / (2π r) ≈ 0.2 · I / r [µT, A, m]`
  tex: `B = \frac{\mu _{0} I}{2\pi r} \approx \frac{0.2 \cdot I}{r \qquad \;[\text{µT, A, m}]}`

## Chapter 32 · Communications
- **32.1 · Link budget. Powers in dBm, gains in dBi, losses in dB.**
  plain: `P_rx = P_tx + G_tx + G_rx − L_path − L_other`
  tex: `P_{\mathrm{rx}} = P_{\mathrm{tx}} + G_{\mathrm{tx}} + G_{\mathrm{rx}} - L_{\mathrm{path}} - L_{\mathrm{other}}`
- **32.2 · Free-space path loss**
  plain: `L_path = 20 log_10(d_km) + 20 log_10(f_MHz) + 32.44 dB`
  tex: `L_{\mathrm{path}} = 20 \log _{10}(d_{\mathrm{km}}) + 20 \log _{10}(f_{\mathrm{MHz}}) + 32.44 \mathrm{dB}`

## Chapter 33 · Electrical integration
- **33.1 · Steady voltage drop in a lead. L is the round-trip length.**
  plain: `ΔV = I · R R = ρ_Cu L / A ρ_Cu ≈ 0.0172 Ω·mm²/m`
  tex: `\Delta V = I \cdot R \qquad R = \frac{\rho _{\mathrm{Cu}} L}{A \qquad \rho _{\mathrm{Cu}}} \approx 0.0172 \Omega \cdot \mathrm{mm}^{2}/m`
- **33.2 · Transient drop across wiring inductance**
  plain: `ΔV = L_w · dI/dt`
  tex: `\Delta V = L_{w} \cdot \mathrm{dI}/\text{ dt }`

## Chapter 34 · Payload integration
- **34.1 · CG shift from a payload mass change**
  plain: `Δx_cg = Δm · (x_p − x_cg) / (m + Δm)`
  tex: `\Delta x_{\mathrm{cg}} = \frac{\Delta m \cdot (x_{p} - x_{\mathrm{cg}})}{m + \Delta m}`
- **34.2 · Cooling airflow for a dissipated power P**
  plain: `ṁ_air = P / (c_p · ΔT)`
  tex: `ṁ_{\mathrm{air}} = \frac{P}{c_{p} \cdot \Delta T}`

## Chapter 35 · Autonomy
- **35.1 · Sensing range needed to stop short of an obstacle**
  plain: `R_sense ≥ v · t_lat + v² / (2a)`
  tex: `R_{\mathrm{sense}} \geq v \cdot t_{\mathrm{lat}} + \frac{v^{2}}{2a}`
- **35.2 · Endurance with a continuous compute load, battery unchanged**
  plain: `t / t_0 = P_fly / (P_fly + P_compute)`
  tex: `\frac{t}{t_{0}} = \frac{P_{\mathrm{fly}}}{P_{\mathrm{fly}} + P_{\mathrm{compute}}}`

## Chapter 36 · Runways and conventional landing
- **36.1 · Takeoff ground roll, first estimate**
  plain: `s_g ≈ V_LO² / [ 2g (T/W − μ) ]`
  tex: `s_{g} \approx \frac{V_{\mathrm{LO}}^{2}}{2g (T/W - \mu)}`
- **36.2 · Landing roll, no reverse thrust**
  plain: `s_L ≈ V_TD² / (2g μ_eff)`
  tex: `s_{L} \approx \frac{V_{\mathrm{TD}}^{2}}{2g \mu _{\mathrm{eff}}}`

## Chapter 37 · Hand launch
- **37.1 · Release speed from throw energy**
  plain: `V_0 ≈ √(2E_throw / m)`
  tex: `V_{0} \approx \sqrt{2E_{\mathrm{throw}} / m}`
- **37.2 · Release margin**
  plain: `V_0 + V_wind ≥ 1.2 V_s, with V_s = √[ 2(W/S) / (ρ C_L,max) ]`
  tex: `V_{0} + V_{\mathrm{wind}} \geq 1.2 V_{s}, \text{ with } V_{s} = \sqrt{ 2(W/S) / (\rho C_{L,\max }) }`

## Chapter 38 · Catapults and rails
- **38.1 · Average launch acceleration**
  plain: `a = V_exit² / (2s) n_x = a / g`
  tex: `a = \frac{V_{\mathrm{exit}}^{2}}{(2s) \qquad n_{x}} = \frac{a}{g}`

## Chapter 39 · Tube launch
- **39.1 · Time available before the arc turns down**
  plain: `t_apex = V_exit sin θ / g`
  tex: `t_{\mathrm{apex}} = V_{\mathrm{exit}} \sin \theta / g`
- **39.2 · Series reliability**
  plain: `R_launch = R_1 × R_2 × … × R_n`
  tex: `R_{\mathrm{launch}} = R_{1} \times R_{2} \times \ldots \times R_{n}`

## Chapter 40 · Parachute recovery
- **40.1 · Steady descent rate**
  plain: `V_d = √[ 2W / (ρ C_D S_0) ]`
  tex: `V_{d} = \sqrt{ 2W / (\rho C_{D} S_{0}) }`
- **40.2 · Opening load in g**
  plain: `n_open ≈ C_k (V_deploy / V_d)²`
  tex: `n_{\mathrm{open}} \approx C_{k} \left(\frac{V_{\mathrm{deploy}}}{V_{d}}\right)^{2}`

## Chapter 41 · Nets, arrestment, and capture
- **41.1 · Capture energy and average deceleration**
  plain: `E = ½ m V_c² n_avg = V_c² / (2 g d)`
  tex: `E = \tfrac{1}{2} m V_{c}^{2} \qquad n_{\mathrm{avg}} = \frac{V_{c}^{2}}{2 g d}`
- **41.2 · Path error allowed by a net of width w**
  plain: `σ ≤ (w − b) / 6`
  tex: `\sigma \leq \frac{w - b}{6}`

## Chapter 42 · VTOL as a launch and recovery system
- **42.1 · Fraction of the battery spent in hover**
  plain: `f_hover = (P_hover / m) · t_hover / e_usable P_hover / m ≈ 40 √DL`
  tex: `f_{\mathrm{hover}} = \left(\frac{P_{\mathrm{hover}}}{m}\right) \cdot t_{\mathrm{hover}} / e_{\mathrm{usable}} \qquad P_{\mathrm{hover}} / m \approx 40 \sqrt{\mathrm{DL}}`

## Chapter 43 · Operating environment
- **43.1 · Out-and-back time in a wind along track, and crab angle in a pure crosswind**
  plain: `t / t_0 = 1 / [ 1 − (w/V)² ] crab angle = sin^−1(w/V)`
  tex: `\frac{t}{t_{0}} = \frac{1}{[1 - (w/V)^{2}] \qquad} \text{ crab angle } = \sin ^{-1}(w/V)`
- **43.2 · What thin air does to true stall speed, hover power, and maximum thrust**
  plain: `V_s ∝ 1/√σ P_hover ∝ 1/√σ T_max ∝ σ`
  tex: `V_{s} \propto 1/\sqrt{\sigma} \qquad P_{\mathrm{hover}} \propto 1/\sqrt{\sigma} \qquad T_{\mathrm{max}} \propto \sigma`

## Chapter 44 · It has to get there first
- **44.1 · Wing pieces from span b and the usable case length L, rounded up. Each piece above one is a joint.**
  plain: `n_pieces = ⌈ b / L_usable ⌉`
  tex: `n_{\mathrm{pieces}} = \frac{\lceil b}{L_{\mathrm{usable}} \rceil}`
- **44.2 · Length available on the floor diagonal for a flat piece of width w, L ≥ W**
  plain: `L_diag ≈ √(L² + W²) − w L / W`
  tex: `L_{\mathrm{diag}} \approx \sqrt{L^{2} + W^{2}} - \frac{w L}{W}`

## Chapter 45 · Start with the mission
- **45.1 · Time on station from the operating concept**
  plain: `t_station = t_endurance − t_reserve − R/V_out − R/V_back`
  tex: `t_{\mathrm{station}} = t_{\mathrm{endurance}} - t_{\mathrm{reserve}} - R/V_{\mathrm{out}} - R/V_{\mathrm{back}}`

## Chapter 48 · The first sizing
- **48.1 · Battery mass for a cruise-dominated electric mission**
  plain: `m_batt = [ m g V / ((L/D) η) + P_aux ] · t / (k e)`
  tex: `m_{\mathrm{batt}} = \frac{\left[\frac{m g V}{(L/D) \eta} + P_{\mathrm{aux}}\right] \cdot t}{k e}`
- **48.2 · Gross mass from fixed masses and mass fractions**
  plain: `m = (m_payload + m_fixed + m_batt) / (1 − f_struct − f_prop − f_margin)`
  tex: `m = \frac{m_{\mathrm{payload}} + m_{\mathrm{fixed}} + m_{\mathrm{batt}}}{1 - f_{\mathrm{struct}} - f_{\mathrm{prop}} - f_{\mathrm{margin}}}`
- **48.3 · Closed form of the loop. It closes only if the denominator is positive.**
  plain: `m = (m_payload + m_fixed + c) / (1 − f_struct − f_prop − f_margin − f_energy)`
  tex: `m = \frac{m_{\mathrm{payload}} + m_{\mathrm{fixed}} + c}{1 - f_{\mathrm{struct}} - f_{\mathrm{prop}} - f_{\mathrm{margin}} - f_{\mathrm{energy}}}`

## Chapter 50 · Retire the biggest risk first
- **50.1 · Test ordering. Score each term 1 to 5; time in weeks.**
  plain: `priority ∝ (uncertainty × consequence) / time to an answer`
  tex: `\text{ priority } \propto (\text{ uncertainty } \times \text{ consequence } \frac{)}{} \text{ time to an answer }`

## Chapter 51 · Simulation and hardware
- **51.1 · Correlation factor, kept per quantity and per regime**
  plain: `K = measured / predicted`
  tex: `K = \text{ measured } \frac{}{} \text{ predicted }`

## Chapter 52 · Technical debt
- **52.1 · Cost to repay a shortcut after n things depend on it**
  plain: `C_repay = C_right + n · c_rework`
  tex: `C_{\mathrm{repay}} = C_{\mathrm{right}} + n \cdot c_{\mathrm{rework}}`

## Chapter 53 · The house of cards
- **53.1 · Growth factor: grams of gross mass per gram of added fixed mass, performance held**
  plain: `G = 1 / (1 − f_struct − f_prop − f_energy − f_margin)`
  tex: `G = \frac{1}{1 - f_{\mathrm{struct}} - f_{\mathrm{prop}} - f_{\mathrm{energy}} - f_{\mathrm{margin}}}`

## Chapter 54 · Schedule learning
- **54.1 · Learning cycles per year, with loop time in weeks**
  plain: `N = 52 / T_loop`
  tex: `N = \frac{52}{T_{\mathrm{loop}}}`

## Chapter 56 · Take the Gamble
- **56.1 · A bookkeeping test for a bounded bet**
  plain: `Take the bet when V_learn > p_loss · C_loss and C_loss is affordable outright`
  tex: `\text{ Take the bet when } \qquad V_{\mathrm{learn}} > p_{\mathrm{loss}} \cdot C_{\mathrm{loss}} \qquad \text{ and } \qquad C_{\mathrm{loss}} \text{ is affordable outright }`

## Chapter 57 · Bench test
- **57.1 · First-order warm-up: ambient T_amb, steady-state rise ΔT_ss, time constant τ**
  plain: `T(t) = T_amb + ΔT_ss (1 − e^−t/τ)`
  tex: `T(t) = T_{\mathrm{amb}} + \Delta T_{\mathrm{ss}} (1 - e^{-t/\tau })`

## Chapter 58 · Ground test
- **58.1 · Free-space range at full power from a reduced-power check: R_check is the distance walked (m), A is the power reduction (dB)**
  plain: `R_full ≈ R_check · 10^A/20`
  tex: `R_{\mathrm{full}} \approx R_{\mathrm{check}} \cdot 10^{A/20}`

## Chapter 59 · Flight test
- **59.1 · Dynamic pressure q (N/m²) from air density ρ (kg/m³) and airspeed V (m/s)**
  plain: `q = ½ ρ V²`
  tex: `q = \tfrac{1}{2} \rho V^{2}`
- **59.2 · Blade-passage frequency f (Hz) from blade count N and shaft speed**
  plain: `f_BP = N · RPM / 60`
  tex: `f_{\mathrm{BP}} = \frac{N \cdot \mathrm{RPM}}{60}`
- **59.3 · Flyby speed V (m/s) from the tone approaching and receding, a = speed of sound, about 340 m/s**
  plain: `V ≈ a (f_in − f_out) / (f_in + f_out)`
  tex: `V \approx \frac{a (f_{\mathrm{in}} - f_{\mathrm{out}})}{f_{\mathrm{in}} + f_{\mathrm{out}}}`

## Chapter 60 · Test the failure
- **60.1 · Distance flown before the response takes effect: airspeed V (m/s), detection and response times (s)**
  plain: `d = V (t_detect + t_respond)`
  tex: `d = V (t_{\mathrm{detect}} + t_{\mathrm{respond}})`

## Chapter 61 · Data into decisions
- **61.1 · Uncertainty of the mean of N repeats, each with run-to-run scatter σ (same units as the measurement)**
  plain: `σ_mean = σ / √N`
  tex: `\sigma _{\mathrm{mean}} = \sigma / \sqrt{N}`
- **61.2 · Apparent error Δx in a signal changing at rate dx/dt when two records are misaligned by Δt (s)**
  plain: `Δx ≈ (dx/dt) · Δt`
  tex: `\Delta x \approx (\text{ dx }/\text{ dt }) \cdot \Delta t`

## Chapter 62 · CG problems
- **62.1 · Pitch stiffness from static margin**
  plain: `dC_m / dC_L = −(x_np − x_cg) / c̄ = −SM`
  tex: `\frac{\mathrm{dC}_{m}}{\mathrm{dC}_{L}} = - \frac{x_{\mathrm{np}} - x_{\mathrm{cg}}}{c̄} = - \mathrm{SM}`

## Chapter 63 · Stalls and spins
- **63.1 · Stall speed in a level, coordinated turn**
  plain: `V_s,turn = V_s √n, n = 1 / cos φ`
  tex: `V_{s,\text{ turn }} = V_{s} \sqrt{n,} \qquad n = \frac{1}{} \cos \phi`

## Chapter 65 · Structural failure
- **65.1 · Root bending moment, near-elliptic lift, no inertia relief**
  plain: `M_root ≈ (nW / 2) · ȳ, ȳ ≈ 0.42 (b / 2)`
  tex: `M_{\mathrm{root}} \approx \left(\frac{\mathrm{nW}}{2}\right) \cdot ȳ, \qquad ȳ \approx 0.42 \left(\frac{b}{2}\right)`

## Chapter 66 · Propulsion failure
- **66.1 · Winding heat from current**
  plain: `P_cu = I² R`
  tex: `P_{\mathrm{cu}} = I^{2} R`

## Chapter 67 · Battery and power failures
- **67.1 · Voltage under load**
  plain: `V = V_oc − I · R_total`
  tex: `V = V_{\mathrm{oc}} - I \cdot R_{\mathrm{total}}`

## Chapter 68 · Vibration
- **68.1 · Transmissibility of a lightly damped mount**
  plain: `T ≈ 1 / | (f / f_n)² − 1 |`
  tex: `T \approx \frac{1}{| \left(\frac{f}{f_{n}}\right)^{2}} - 1 |`

## Chapter 69 · EMI and navigation problems
- **69.1 · Field from one wire, and from a supply and return pair**
  plain: `B_wire = μ_0I / (2πr) B_pair ≈ μ_0I d / (2πr²)`
  tex: `B_{\mathrm{wire}} = \frac{\mu _{0}I}{(2\pi r) \qquad B_{\mathrm{pair}}} \approx \frac{\mu _{0}I d}{2\pi r^{2}}`

## Chapter 70 · Control-system problems
- **70.1 · Phase lost to a pure delay**
  plain: `φ = 360° · f · τ`
  tex: `\phi = 360^{\circ} \cdot f \cdot \tau`

## Chapter 71 · Launch failures
- **71.1 · Share of weight the wing can carry below stall speed**
  plain: `L_max / W = (V / V_s)²`
  tex: `\frac{L_{\mathrm{max}}}{W} = \left(\frac{V}{V_{s}}\right)^{2}`

## Chapter 72 · Transition failures
- **72.1 · Rotor share of weight below stall speed, and propeller advance ratio**
  plain: `T_rotor / W ≥ 1 − (V / V_s)² J = V / (nD)`
  tex: `\frac{T_{\mathrm{rotor}}}{W} \geq 1 - \left(\frac{V}{V_{s}}\right)^{2} \qquad J = \frac{V}{\mathrm{nD}}`

## Chapter 74 · Units, atmosphere, and quick equations
- **74.1 · ISA troposphere: T in K, p in Pa, ρ in kg/m³**
  plain: `T = 288.15 − 0.0065 h p = 101,325 (T / 288.15)^5.256 ρ = p / (287.05 T)`
  tex: `T = 288.15 - 0.0065 h \qquad p = 101{,}325 \left(\frac{T}{288.15}\right)^{5.256} \qquad \rho = \frac{p}{287.05 T}`
- **74.2 · Sea level, 15 °C, μ = 1.789 × 10⁻⁵ Pa·s**
  plain: `Re = ρ V c / μ ≈ 68,500 · V [m/s] · c [m]`
  tex: `\mathrm{Re} = \frac{\rho V c}{\mu} \approx 68{,}500 \cdot V [m/s] \cdot c [m]`

## Chapter 76 · Materials, electrical, and hardware tables
- **76.1 · Hinge moment and servo torque, plain unbalanced surface**
  plain: `H = q · S_c · c_c · C_h C_h ≈ 0.012 per degree × δ Q_servo = H · (r_arm / r_horn)`
  tex: `H = q \cdot S_{c} \cdot c_{c} \cdot C_{h} \qquad C_{h} \approx 0.012 \text{ per degree } \times \delta \qquad Q_{\mathrm{servo}} = H \cdot \left(\frac{r_{\mathrm{arm}}}{r_{\mathrm{horn}}}\right)`
