# Watch for this: early symptoms and what they usually mean

How things go wrong quietly, by chapter. Use with cards.md when diagnosing.

## Chapter 1 · A field guide to drone configurations
- **The aircraft that does everything** — Hybrids get chosen because nobody wanted to choose. The early symptom is a line in the mass budget, such as lift motors, tilt actuators, or fold mechanisms, that does nothing during the phase where the aircraft spends most of its time, and that keeps growing.

## Chapter 2 · Read the airframe
- **Scale errors square** — A 10 percent error in your reference dimension becomes a 21 percent error in wing area and about a 10 percent error in stall speed. The early symptom is an estimate that disagrees with how the aircraft is actually launched: a “hand-launched” aircraft that works out to a 17 m/s stall.

## Chapter 3 · Mission drives configuration
- **The requirement with too many “ands”** — Hover and long range and tube launch and cheap. Each “and” from a different corner of the trade space adds mass that the others must carry.

## Chapter 4 · Units, scaling, and quick estimates
- **The wrong answer has a familiar size** — Unit errors leave fingerprints. Off by about 10 is usually g, a mass used as a force.

## Chapter 5 · Weight and mass properties
- **Nobody decided to make it heavier** — Mass creeps in by grams: a bigger connector, a doubler after a hard landing, a second coat of paint, a longer cable. No single change is worth a meeting.

## Chapter 6 · Wing loading
- **The stall speed you calculated is not the one you have** — Two things drift the same direction. Mass grows, and the real C_L,max comes in below the airfoil chart.

## Chapter 7 · Disk loading
- **The rotors shrank to fit the box** — Disk area is what gets traded away when the vehicle has to fit a case, a tube, or a doorway, and the mass keeps growing while it happens. The early symptoms are hover throttle above about 60%, hot motors after a short hover, a harsher sound, and more dust and debris thrown around at takeoff.

## Chapter 8 · Power loading and thrust-to-weight
- **It was tested on a fresh pack on a cool morning** — Margins measured at the start of a flight do not exist at the end of one. The early symptoms show up late in the flight and on hot days: a weak climb after a missed recovery, a multirotor that wanders in yaw or sinks in a gust, a speed controller that pulls power back in a long climb.

## Chapter 9 · Energy and endurance
- **The flight ends 25% early and nothing is broken** — The usual cause is an optimistic budget, not a fault. The label watt-hours were used instead of usable ones.

## Chapter 10 · Stability and center of gravity
- **The CG walks aft one change at a time** — Tail repairs, a bigger tail servo, a longer antenna, a heavier motor on a pusher, glue and paint. Each is small and each is behind the CG.

## Chapter 11 · Speed and maneuvering
- **The stall speed moved and the setpoints did not** — An aircraft is set up to loiter at 1.3 times its stall speed. Over a few months it gains 20% in mass from payload and battery changes.

## Chapter 12 · Lift
- **The stall speed in the autopilot came from a calculation.** — The early symptom is a launch that sags more than predicted, or an approach that gets mushy at an airspeed the spreadsheet called safe. Check three things.

## Chapter 13 · Drag
- **Drag creep between the estimate and the airplane.** — The early symptom is cruise current higher than predicted on the first trimmed level leg. Do not blame the battery yet.

## Chapter 14 · Airfoils
- **The airfoil as built is not the airfoil as drawn.** — The early symptom is two airframes from the same drawing that stall at different speeds, or one that always drops the same wing. Cut a leading-edge template from the CAD profile and hold it against the wing at three span stations on each side.

## Chapter 15 · Wings
- **The aircraft always drops the same wing.** — The early symptom is ailerons that go soft before the stall, or a consistent roll-off on hand launch and in slow turns. Put an incidence meter on the root and the tip of each panel.

## Chapter 16 · Tails and control surfaces
- **Blowback, slop, and shared throw.** — Blowback shows up as pitch or roll response that gets lazy at high speed, a servo that is hot after landing, or dips in the servo supply voltage in the log. Check the torque margin and the power supply to the servos.

## Chapter 17 · Configuration aerodynamics
- **The stall speed that depends on the throttle** — On a blown wing, and on any tractor whose tail sits in propwash, low-speed behavior is measured with power on. Then the motor stops, or the autopilot cuts throttle on approach, and the aircraft is flying on a different wing with a weaker tail.

## Chapter 18 · Propellers
- **Full throttle, falling current, no acceleration** — A propeller running out of J does not announce it. The early symptoms are in the log: throttle at or near 100% in fast flight while current drops and RPM climbs toward the no-load value.

## Chapter 19 · Electric motors
- **It passed the thirty-second thrust test** — Thermal problems take minutes to show. A motor has a thermal time constant of a few minutes, so a short bench run at full throttle proves little.

## Chapter 20 · ESCs and electrical power
- **The warm connector** — Resistance in the power path grows quietly. Contacts wear and arc, solder joints crack under vibration, and a crimp loosens.

## Chapter 21 · Batteries
- **Voltage that recovers on the ground** — A pack that reads healthy at rest and collapses under load has high internal resistance, from age, cold, a weak cell group, or a bad weld. The early symptoms are in the log: deeper sag than the same flight showed a month ago, a low-battery warning that appears in climbs and clears in cruise, one cell group that finishes lower than the rest, and a pack that comes down warmer than it used to.

## Chapter 22 · Piston and rotary engines
- **The engine that ran fine on the stand** — A test-stand engine has free air, a short fuel line, and a rigid mount. Inside a cowl it has none of those.

## Chapter 23 · Turbines and electric ducted fans
- **The bench thrust never shows up in the airplane** — The fan made its rated thrust on the stand and the aircraft is slow off the launcher. Look at the intake first.

## Chapter 24 · Hybrid propulsion and fuel cells
- **The buffer that slowly drains** — The system works on the bench and on a cool morning. At maximum weight on a hot afternoon, the engine is down on power, the load is up, and the average demand sits just above generator output.

## Chapter 25 · Structural loads
- **The airframe that passes the wing test and breaks at the boom** — The wing gets the analysis and the sandbag test because it is the obvious structure. The failures show up elsewhere: hairline cracks in paint at the boom root, whitening in printed mounts, a motor mount that needs retightening every few flights, a hatch that no longer closes flush.

## Chapter 26 · Materials
- **Properties from the datasheet, part from your shop** — Datasheet values come from well-made coupons. A hand layup with extra resin, a print with poor layer fusion, or damp nylon can give half the stiffness and less of the strength.

## Chapter 27 · Joining
- **The bond that looked perfect and let go clean** — When a bonded joint fails, read the surfaces. Adhesive left on both faces means the glue itself broke, and the joint was simply overloaded or too small.

## Chapter 28 · Manufacturing by quantity
- **The prototype process that quietly became the production process** — Nobody decides to hand-build forty aircraft. The order grows ten at a time and the shop keeps doing what worked.

## Chapter 29 · Designing for repair
- **The repaired aircraft that flies a little worse each month** — Repairs add mass, mostly aft, and nobody reweighs. The aircraft gets heavier and its CG walks back a few millimeters at a time.

## Chapter 30 · Flight controllers
- **The aircraft that climbs when you add throttle** — The quiet symptom of vibration is not shaking. It is a height estimate that drifts with throttle, a horizon that tilts after a hard maneuver, or motors that run hot because the rate loop is amplifying noise.

## Chapter 31 · Navigation
- **Heading that moves with the throttle** — A multirotor that holds position well at hover and then starts to circle wider and wider under load has a magnetometer reading motor current. The early sign is in the log: total measured field strength should be constant in flight.

## Chapter 32 · Communications
- **Dropouts that come around once per orbit** — If signal strength dips at the same heading on every circuit, or every time the aircraft banks one way, the radio is fine and the airframe is in the way. Plot logged signal strength against heading and roll angle.

## Chapter 33 · Electrical integration
- **The reset that only happens in the air** — Early signs are small: a receiver that rebinds now and then, a log with a gap in it, a boot counter that is one higher than it should be, a GNSS unit that reacquires in flight. All of them mean a rail dipped.

## Chapter 34 · Payload integration
- **The payload that works in flight and cooks on the ramp** — Cooling designed around cruise airflow does nothing during preflight, a GNSS wait, or a hold for airspace. The early sign is a payload that drops frames, reboots, or throttles only on hot days and only before takeoff.

## Chapter 35 · Autonomy
- **Latency that creeps up on a hot day** — Perception pipelines are tested on the bench, cool, with a fresh battery. In the field the processor heats up, throttles its clock, and the loop that ran in 50 ms now takes 200 ms.

## Chapter 36 · Runways and conventional landing
- **The gear that was sized on the good runway** — The early symptom is a nose-over or a bent nose strut the first time the aircraft leaves its home field. Check wheel diameter against the real grass height, check prop clearance with the nose strut fully compressed and one tire flat, and check that the gear attachment fails before the fuselage bulkhead does.

## Chapter 37 · Hand launch
- **The launch that only works for one person** — The early symptom is a program where the same engineer always throws. Log release speed, pitch, and roll from the autopilot on every launch and look at the spread across people, not the average.

## Chapter 38 · Catapults and rails
- **The calibration that aged** — The early symptom is an aircraft that sags off the end of the rail on a day when it used to climb. Rubber loses output in the cold and with age and sun.

## Chapter 39 · Tube launch
- **The IMU that flat-topped in the tube** — Many small autopilot accelerometers saturate at 16 g. A 26 g launch clips the signal, the estimator integrates a wrong velocity and attitude, and the aircraft exits the tube confidently wrong.

## Chapter 40 · Parachute recovery
- **The canopy that opens a little later each time** — Packing is the main failure source, and it degrades quietly. The early symptom is more height lost between command and full inflation, visible in the altitude log or on video.

## Chapter 41 · Nets, arrestment, and capture
- **The hit point that walks off center** — Scatter around the middle of the net is noise. A mean hit point that sits low, high, or to one side is a bias, and it grows until one approach catches a pole or the ground.

## Chapter 42 · VTOL as a launch and recovery system
- **The landing hover happens on the worst battery of the flight** — Peak power demand arrives at the lowest state of charge, often with a cold-soaked pack, so voltage sag is at its worst exactly when the lift motors need headroom. The early symptom is the minimum pack voltage during landing drifting down from flight to flight while hover seconds per flight drift up.

## Chapter 43 · Operating environment
- **The aircraft that was tested in one season** — A development program flown at one field in mild weather produces an aircraft tuned to that day. The first hot, high, or cold deployment then finds several thin margins at once.

## Chapter 44 · It has to get there first
- **The wing that grew after the case was bought** — The span goes up 10% during sizing, which is normal, and nobody re-measures the case, which is also normal. The early symptom is a wing panel that fits only with the foam removed, then only on the diagonal, then only with the tip bent.

## Chapter 45 · Start with the mission
- **The solution hiding inside the requirement.** — "Shall be a quadcopter." "Shall use a 6S battery." "Shall have a 3 m wing." These are design decisions wearing a requirement's clothes, and they close off architectures before anyone has compared them. The early symptom is a requirement that names a part or a configuration instead of an effect.

## Chapter 46 · Requirements without ground truth
- **Two ways to get this wrong** — Obeying blindly. The objective value quietly becomes the threshold.

## Chapter 47 · Concept generation
- **The favorite gets all the hours.** — The early symptom is uneven fidelity. One concept has a CAD model with fasteners.

## Chapter 48 · The first sizing
- **It closed, on the best day of every input.** — A loop will close on almost anything if L/D is 14, efficiency is 0.6, the pack is 220 Wh/kg, and structure is 25%. Each value is defensible alone.

## Chapter 49 · Build something immediately
- **The mockup that answers no question.** — A mockup can turn into a model-making project. The early symptoms are filler, paint, and a stand.

## Chapter 50 · Retire the biggest risk first
- **Steady progress on everything except the thing that matters.** — The early symptom is a status report full of percent-complete numbers for drawings and parts, while the top unknown is described with the words "planned" or "after integration". The second symptom is a test plan in which every test is expected to pass.

## Chapter 51 · Simulation and hardware
- **The model tuned to match one flight.** — After a test disagrees with the simulation, it is tempting to adjust coefficients until the curves overlay. They will.

## Chapter 52 · Technical debt
- **The shortcut that silently became the architecture.** — Nobody decides to make a prototype hack permanent. It happens by default.

## Chapter 53 · The house of cards
- **The margin that was quietly spent.** — Nobody announces that the design has no margin left. It goes a line at a time.

## Chapter 54 · Schedule learning
- **A schedule that stays green while nothing is learned.** — The early symptom is a status that reports documents, orders, and percent complete, and cannot say what the team knows now that it did not know a month ago. A second symptom: the first integrated test sits near the end of the plan, where a bad result can no longer change anything.

## Chapter 55 · Prototype generations
- **The prototype that became the product by default.** — A development aircraft flies well at a demonstration. Someone asks for ten more.

## Chapter 56 · Take the Gamble
- **Two ways to get this wrong** — The bet nobody wrote down. A test is run with no stated expectation.

## Chapter 57 · Bench test
- **Static numbers used for flight predictions** — Bench thrust and bench efficiency slide into the cruise performance spreadsheet because they are the only measured numbers available. The symptom shows up later as flight current that does not match prediction and an endurance shortfall nobody can explain.

## Chapter 58 · Ground test
- **The ground test that was run on a different aircraft** — The run-up was done with the hatch off for access, the payload unplugged, and a bench supply on the power leads. Everything passed.

## Chapter 59 · Flight test
- **The flight that is going well** — The points on the card are done, the battery has plenty left, and someone suggests one more pass, a little faster. That point has no prediction, no limit, and no one assigned to watch it.

## Chapter 60 · Test the failure
- **A failsafe tested once, on last month’s configuration** — Firmware updates, parameter resets, a new receiver, and a moved home point can each change failsafe behavior without any visible sign. Nothing looks wrong until the day it is needed.

## Chapter 61 · Data into decisions
- **A bias mistaken for a finding** — Monday’s baseline is compared with Thursday’s modification, and the modification looks 6% better. Thursday was also cooler, the battery was newer, and the pitot had been reseated.

## Chapter 62 · CG problems
- **The CG creeps aft across builds** — Tail repairs, paint, a heavier servo, a longer antenna. The tail arm is long, so grams count.

## Chapter 63 · Stalls and spins
- **The roll loop that picks up a wing with aileron** — Down aileron on a wing that is near the stall raises its local angle of attack and finishes the job. A roll controller does this without hesitating.

## Chapter 64 · Flutter
- **Wear moves the boundary toward you** — The aircraft that was fine for fifty flights can flutter on the fifty-first at the same speed. Horn holes elongate, servo gears wear, hinges loosen, and a repair adds mass behind the hinge.

## Chapter 65 · Structural failure
- **Deflection that grows at the same load** — Structure rarely fails without notice. Tip deflection that creeps up between inspections, a new creak under hand load, a dull sound in a coin tap, white stress marks in plastic, fretting dust around a fastener.

## Chapter 66 · Propulsion failure
- **The fault that goes away when you unplug and replug** — You did not fix it. You wiped the contact and bought a few flights.

## Chapter 67 · Battery and power failures
- **Connectors age faster than packs** — At 60 A, a connector that has gone from 0.5 mΩ to 3 mΩ dissipates 60² × 0.003 = 10.8 W in a part the size of a thumbnail. Look for darkened plating, softened housings, and a loose fit.

## Chapter 68 · Vibration
- **A clean log on a shaking airframe** — Heavy filtering makes the gyro trace look fine while the frame still shakes. The early signs are outside the log: warm motors, loose fasteners, a rising clip count.

## Chapter 69 · EMI and navigation problems
- **Clean on the bench, dirty in the air** — Bench checks happen at idle with the hatch open and the video link off. Flight has ten times the current and every transmitter at full power.

## Chapter 70 · Control-system problems
- **Saturation dressed as a tuning problem** — The early symptom is a flight that is fine in the middle of the envelope and loose at one edge. Each gain increase helps less than the last.

## Chapter 71 · Launch failures
- **The launch that worked all spring** — Payload creeps up, the bungee ages, and summer air thins. No single change breaks the launch.

## Chapter 72 · Transition failures
- **The corridor narrows as the aircraft gains weight** — More weight raises stall speed and cuts hover margin at the same time. The early symptoms are transitions that take longer and an altitude dip that grows with each payload change.

## Chapter 73 · Human errors
- **The workaround that became the procedure** — A step gets skipped once with no consequence, then always. The early symptom is a preflight that finishes faster than the list can be read aloud.

## Chapter 75 · Sizing charts and practical ranges
- **A typical range is not a requirement** — These bands describe where aircraft have ended up, not where yours must. The quiet failure is tuning a design to sit mid-band on every row.
