# The laws

One line per chapter, the short version of the book. Cite as "DFG Law n".

1. Nobody decides to make it heavier. It just gets heavier. *(ch 5)*
2. The stall speed you calculated is not the one you have. *(ch 6)*
3. A bigger rotor hovers on less power. Every time. *(ch 7)*
4. Test it on a tired pack on a hot afternoon. *(ch 8)*
5. More battery is the first fix everyone reaches for, and the first one to stop working. *(ch 9)*
6. The CG walks aft one change at a time. *(ch 10)*
7. The shape you drew is half the drag. The rest you bolted on. *(ch 13)*
8. The airfoil as built is not the airfoil as drawn. *(ch 14)*
9. Propeller first, then motor, then battery. *(ch 18)*
10. A thirty-second thrust test proves thirty seconds. *(ch 19)*
11. A warm connector is a failing connector. *(ch 20)*
12. Know where the protection lives: in the pack, in the speed controller, or nowhere. *(ch 21)*
13. Size the spar for flight. Size everything else for the ground. *(ch 25)*
14. Carbon fiber is one answer among several. *(ch 26)*
15. The second unit tells the truth about the first. *(ch 28)*
16. Decide what breaks first, and make it cheap. *(ch 29)*
17. Tune the inner loop first, and never tune a mechanical problem. *(ch 30)*
18. Distance between a sensor and a power lead is a shield that weighs nothing. *(ch 31)*
19. Size the wiring for the stall current, not the average. *(ch 33)*
20. The payload is the reason the aircraft exists. *(ch 34)*
21. The mission begins before takeoff and ends after recovery. *(ch 36)*
22. A launch that only works for one person is not a launch method. *(ch 37)*
23. VTOL is landing gear you carry for the whole flight. *(ch 42)*
24. One is none. Two is one. *(ch 44)*
25. One or two requirements size the aircraft. Find them first. *(ch 46)*
26. The airplane does not read the requirements. *(ch 46)*
27. Partly right and early beats fully right and late. *(ch 46)*
28. Bring three alternatives that differ in kind. Otherwise you have one idea. *(ch 47)*
29. Build something in the first week. Full scale and true mass when you can. *(ch 49)*
30. The top unknown always has a test date. *(ch 50)*
31. No test without a prediction. No model without a measurement. *(ch 51)*
32. If it is not written down, it is not technical debt. It is a defect. *(ch 52)*
33. Every gram brings friends. *(ch 53)*
34. A schedule can stay green while nothing is learned. *(ch 54)*
35. Every prototype exists to find out one thing. Say what it is before you build it. *(ch 55)*
36. Make small bets, and state them in advance. *(ch 56)*
37. A test is worth running when its result can change a decision. *(ch 57)*
38. You expand the airframe’s envelope in steps. Do the same for the crew. *(ch 58)*
39. Abort criteria are written before the battery goes in. *(ch 59)*
40. Once control authority is gone, the airframe decides. *(ch 60)*
41. “What was new?” finds more causes than any log. *(ch 61)*
42. “It should be fine” is a guess. Go check. *(ch 62)*
43. Flutter is not found by flying a little faster each time. *(ch 64)*
44. A new sound is a finding. *(ch 68)*
45. An actuator on its stop looks like bad tuning. It is not. *(ch 70)*
46. There is no pilot error. There is a design that let it happen. *(ch 73)*
