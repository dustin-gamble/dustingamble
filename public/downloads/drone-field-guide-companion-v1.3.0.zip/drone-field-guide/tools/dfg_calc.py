#!/usr/bin/env python3
"""Drone Field Guide companion: the book's sizing and diagnosis arithmetic as plain functions.
Every function uses the equation the book uses, with the book's typical values as defaults.
SI units unless the name says otherwise. Nothing here is a substitute for measuring.

    python3 dfg_calc.py stall_speed --mass 4 --wing_area 0.5
    python3 dfg_calc.py                      # lists every function and its arguments
    >>> import dfg_calc as c; c.hover_power(10, disk_area=0.5)
"""
import math, sys, inspect

G = 9.81
RHO0 = 1.225

# ---------------------------------------------------------------- atmosphere
def isa_density(h_m=0.0, dT_c=0.0):
    """Air density (kg/m³) at geometric height h_m with a temperature offset dT_c from standard. [ch 43, 74]"""
    T = 288.15 - 0.0065 * h_m
    p = 101325 * (T / 288.15) ** 5.2559
    return p / (287.05 * (T + dT_c))

def density_ratio(h_m=0.0, dT_c=0.0):
    """σ = ρ/ρ0. Stall speed and hover power scale with 1/√σ, maximum thrust with σ. [ch 43]"""
    return isa_density(h_m, dT_c) / RHO0

# ---------------------------------------------------------------- weights and wings
def stall_speed(mass_kg, wing_area_m2, cl_max=1.2, rho=RHO0):
    """V_s = √(2 W / (ρ S CL,max)) in m/s. Small aircraft CL,max is usually 1.0 to 1.3 as built. [ch 6]"""
    return math.sqrt(2 * mass_kg * G / (rho * wing_area_m2 * cl_max))

def wing_area_for_stall(mass_kg, v_stall_ms, cl_max=1.2, rho=RHO0):
    """Wing area (m²) that gives a stall speed. [ch 6]"""
    return 2 * mass_kg * G / (rho * v_stall_ms ** 2 * cl_max)

def wing_loading(mass_kg, wing_area_m2):
    """W/S in N/m² and kg/m². [ch 6]"""
    return dict(N_per_m2=mass_kg * G / wing_area_m2, kg_per_m2=mass_kg / wing_area_m2)

def growth(payload_change_kg, payload_fraction=0.2):
    """Resized aircraft mass change for a payload change, at constant performance: Δm ≈ Δpayload / f_payload. [ch 5]"""
    return payload_change_kg / payload_fraction

def gross_from_fractions(payload_kg, f_empty=0.5, f_energy=0.3):
    """Gross mass from payload and the empty and energy fractions: m0 = payload / (1 − f_empty − f_energy). [ch 5]"""
    return payload_kg / (1 - f_empty - f_energy)

# ---------------------------------------------------------------- hover and power
def hover_power(mass_kg, disk_area_m2, fm=0.65, eta_drive=0.85, rho=RHO0):
    """Momentum-theory hover: ideal, shaft (÷FM), and electrical (÷η_drive) power in W, plus induced velocity. [ch 7]"""
    W = mass_kg * G
    vi = math.sqrt(W / (2 * rho * disk_area_m2))
    ideal = W * vi
    return dict(disk_loading_N_m2=W / disk_area_m2, induced_velocity_ms=vi, ideal_W=ideal, shaft_W=ideal / fm, electrical_W=ideal / fm / eta_drive)

def disk_area(diameter_m, count=1):
    """Total disk area for count rotors of one diameter. [ch 7]"""
    return count * math.pi * diameter_m ** 2 / 4

def cruise_power(mass_kg, v_ms, l_over_d=10.0, eta_prop=0.65, eta_drive=0.85, hotel_w=0.0):
    """Electrical cruise power: W V / (L/D) ÷ (η_prop η_drive) + hotel load. [ch 8, 9]"""
    thrust_power = mass_kg * G * v_ms / l_over_d
    return dict(thrust_power_W=thrust_power, electrical_W=thrust_power / (eta_prop * eta_drive) + hotel_w)

def climb_power(mass_kg, v_ms, climb_ms, l_over_d=10.0, eta_prop=0.6, eta_drive=0.8):
    """Thrust-to-weight and electrical power for a steady climb: T/W = 1/(L/D) + V_climb/V. [ch 8]"""
    tw = 1 / l_over_d + climb_ms / v_ms
    thrust_power = tw * mass_kg * G * v_ms
    return dict(thrust_to_weight=tw, thrust_N=tw * mass_kg * G, electrical_W=thrust_power / (eta_prop * eta_drive), W_per_kg=thrust_power / (eta_prop * eta_drive) / mass_kg)

def thrust_to_weight_rule(kind='multirotor'):
    """The book's static T/W rule. multirotor: 2 (yaw needs one rotor set near zero, the other at full). vtol_4plus1: 1.3 calm, 1.5 with crosswind. fixed_wing: 0.3–0.5 catapult/runway, 0.5–0.8 hand launch. [ch 8]"""
    return {'multirotor': 2.0, 'vtol_4plus1': 1.3, 'vtol_4plus1_crosswind': 1.5, 'fixed_wing_launcher': 0.4, 'hand_launch': 0.65}[kind]

# ---------------------------------------------------------------- energy
def usable_energy_wh(nameplate_wh, fraction=0.65):
    """Planning usable energy: 0.65 of nameplate. A new pack on a warm day gives 0.80–0.85. [ch 9]"""
    return nameplate_wh * fraction

def endurance_h(usable_wh, electrical_w):
    """t = E / P. [ch 9]"""
    return usable_wh / electrical_w

def electric_range_km(e_b_wh_per_kg=180.0, battery_fraction=0.3, eta=0.5, l_over_d=10.0, usable=0.65):
    """Battery Breguet range: R = (e_b/g) f_b η (L/D), still air, no hotel load, constant mass. η = η_ESC η_motor η_prop ≈ 0.5. [ch 3, 9]"""
    return e_b_wh_per_kg * usable * 3600 / G * battery_fraction * eta * l_over_d / 1000

def hover_time_min(mass_kg, disk_area_m2, battery_wh, fm=0.65, eta_drive=0.85, usable=0.65, rho=RHO0):
    """Hover endurance from the hover power and the usable energy. [ch 3, 42]"""
    p = hover_power(mass_kg, disk_area_m2, fm, eta_drive, rho)['electrical_W']
    return battery_wh * usable / p * 60

def battery_size(mission_wh, cells=4, usable=0.65, wh_per_kg=180.0):
    """Nameplate Wh, Ah at cells × 3.7 V, and pack mass for a mission energy. [battery card]"""
    nameplate = mission_wh / usable
    return dict(nameplate_Wh=nameplate, Ah=nameplate / (cells * 3.7), mass_kg=nameplate / wh_per_kg)

def pack_voltage(cells, per_cell=3.7):
    """Pack voltage at 4.2 full, 3.8 storage, 3.7 nominal, 3.5 land soon, 3.3 floor under load, 3.0 damage. [ch 21]"""
    return cells * per_cell

# ---------------------------------------------------------------- propellers and motors
def tip_speed(diameter_m, rpm, v_forward_ms=0.0, a=340.0):
    """Static and helical tip speed and tip Mach. Keep helical tip Mach under about 0.7; lower if noise matters. [ch 18]"""
    vt = math.pi * diameter_m * rpm / 60
    vh = math.hypot(vt, v_forward_ms)
    return dict(static_ms=vt, helical_ms=vh, mach=vh / a)

def pitch_speed(pitch_in, rpm):
    """Geometric pitch speed, pitch × RPM: the no-slip advance. Thrust actually reaches zero somewhat above it, at a point set by the propeller's thrust curve against advance ratio. [ch 18]"""
    return pitch_in * 0.0254 * rpm / 60

def kv_rpm(kv, cells, per_cell=3.7, loaded_fraction=0.8):
    """No-load and loaded RPM from Kv and cell count; loaded RPM is typically about 80% of no-load at full throttle. [ch 19]"""
    v = cells * per_cell
    return dict(no_load=kv * v, loaded=kv * v * loaded_fraction)

def static_thrust(diameter_m, rpm, ct=0.1, rho=RHO0):
    """T = C_T ρ n² D⁴ with n in rev/s; C_T of 0.09–0.12 is typical for small propellers statically. [ch 18]"""
    n = rpm / 60
    return ct * rho * n ** 2 * diameter_m ** 4

def blade_pass_hz(rpm, blades=2):
    """The tone you hear: blades × RPM / 60. RPM = 30 × tone for two blades, 20 × for three. [ch 59]"""
    return blades * rpm / 60

def rpm_from_tone(hz, blades=2):
    """RPM from the blade-passage tone. [ch 59]"""
    return hz * 60 / blades

def flyby_speed(f_in_hz, f_out_hz, a=340.0):
    """Aircraft speed from the tone approaching and receding: V ≈ a (f_in − f_out)/(f_in + f_out). [ch 59]"""
    return a * (f_in_hz - f_out_hz) / (f_in_hz + f_out_hz)

# ---------------------------------------------------------------- electrical
def awg_area_mm2(awg):
    """Copper cross-section for an AWG gauge."""
    d = 0.127 * 92 ** ((36 - awg) / 39)
    return math.pi * d * d / 4

def wire_drop(current_a, length_m, awg, round_trip=True):
    """Voltage drop in copper: ΔV = I R, R = 17.2 mΩ·mm²/m ÷ area. length_m is the run; round trip doubles it. Hold under 2% of pack voltage. [ch 33]"""
    r = 17.2e-3 / awg_area_mm2(awg) * length_m * (2 if round_trip else 1)
    return dict(ohms=r, drop_V=current_a * r, loss_W=current_a ** 2 * r)

def wire_gauge(current_a, bundled=False):
    """Smallest even AWG for a continuous current: 10 A/mm² in free air, 5 A/mm² bundled. Peak current of a few seconds can run one gauge smaller. [ch 33, tables]"""
    need = current_a / (5 if bundled else 10)
    for n in list(range(30, 3, -2)) + [2, 1, 0]:
        if awg_area_mm2(n) >= need: return n
    return None   # beyond 1/0 AWG (0): off the table, size it explicitly

def compass_error_deg(current_a, distance_cm, twisted_pair_spacing_mm=None, earth_h_uT=20.0):
    """Heading error when the lead's field lies across the Earth's horizontal field: B = 0.2 I / r µT (single lead) or 0.2 I s / r² (pair), error = atan(B / 20 µT). Not a bound: a field stronger than the Earth's and opposed to it reverses the heading. [ch 31]"""
    r = distance_cm / 100
    b = 0.2 * current_a * (twisted_pair_spacing_mm / 1000) / r ** 2 if twisted_pair_spacing_mm else 0.2 * current_a / r
    return math.degrees(math.atan(b / earth_h_uT))

# ---------------------------------------------------------------- launch and recovery
def launcher_g(exit_speed_ms, rail_length_m):
    """Average launch acceleration a = V²/(2 s), in g. [ch 38]"""
    return exit_speed_ms ** 2 / (2 * rail_length_m) / G

def hand_launch_release(mass_kg, throw_energy_j=100.0, cap_ms=11.0):
    """Release speed from a throw: √(2E/m), capped by arm speed. Needs 1.2 V_s at release, or thrust to make up the gap. [ch 37]"""
    return min(cap_ms, math.sqrt(2 * throw_energy_j / mass_kg))

def parachute_diameter(mass_kg, descent_ms=5.0, cd=0.75, rho=RHO0):
    """Canopy diameter for a descent rate: S0 = 2W/(ρ C_D V²), D = √(4 S0/π). S0 is nominal canopy area and C_D = 0.75 is the book's default on that area. Landing energy ½ m V² in J. [ch 40]"""
    s0 = 2 * mass_kg * G / (rho * cd * descent_ms ** 2)
    return dict(area_m2=s0, diameter_m=math.sqrt(4 * s0 / math.pi), landing_energy_J=0.5 * mass_kg * descent_ms ** 2)

def ground_roll(mass_kg, wing_area_m2, thrust_to_weight, mu=0.05, cl_max=1.2, rho=RHO0):
    """Takeoff ground roll s ≈ V_LO² / (2 g (T/W − μ)), V_LO = 1.2 V_s. [ch 36]"""
    vlo = 1.2 * stall_speed(mass_kg, wing_area_m2, cl_max, rho)
    return vlo ** 2 / (2 * G * (thrust_to_weight - mu))

# ---------------------------------------------------------------- flight and test
def turn(v_ms, bank_deg):
    """Load factor, turn radius, and stall speed rise in a level turn. [ch 11]"""
    n = 1 / math.cos(math.radians(bank_deg))
    return dict(load_factor=n, radius_m=v_ms ** 2 / (G * math.tan(math.radians(bank_deg))), stall_speed_factor=math.sqrt(n))

def dynamic_pressure(v_ms, rho=RHO0):
    """q = ½ ρ V². A 10% speed step is a 21% load step; step airspeed by about 10% when expanding the envelope. [ch 59]"""
    return 0.5 * rho * v_ms ** 2

def speed_steps(v_from_ms, v_to_ms, step=0.10):
    """Envelope-expansion test points at a fixed fractional speed step. [ch 59]"""
    pts, v = [], v_from_ms
    while v * (1 + step) < v_to_ms * 1.0001:
        v *= 1 + step; pts.append(round(v, 1))
    if not pts or pts[-1] < v_to_ms: pts.append(round(v_to_ms, 1))
    return pts

def reynolds(chord_m, v_ms, rho=RHO0, mu=1.79e-5):
    """Chord Reynolds number ≈ 68,500 V c at sea level. Small aircraft live at 50,000–500,000 where airfoil data is scarce. [ch 4, 14]"""
    return rho * v_ms * chord_m / mu

# ---------------------------------------------------------------- radio
def fspl_db(distance_km, freq_mhz):
    """Free-space path loss: 20 log d(km) + 20 log f(MHz) + 32.44. [ch 32]"""
    return 20 * math.log10(distance_km) + 20 * math.log10(freq_mhz) + 32.44

def link_margin_db(p_tx_dbm, g_tx_dbi, g_rx_dbi, distance_km, freq_mhz, sensitivity_dbm, other_losses_db=3.0):
    """Link budget margin. Add 10–20 dB for banking, shadowing, and polarisation before trusting a number. [ch 32]"""
    return p_tx_dbm + g_tx_dbi + g_rx_dbi - fspl_db(distance_km, freq_mhz) - other_losses_db - sensitivity_dbm

def radio_horizon_km(h1_m, h2_m=2.0):
    """Radio line of sight ≈ 4.12 (√h1 + √h2) km. [ch 32]"""
    return 4.12 * (math.sqrt(h1_m) + math.sqrt(h2_m))

# ---------------------------------------------------------------- transport
def wing_pieces(span_m, usable_case_length_m):
    """Pieces = ceil(span / usable length). Every piece above one is a joint. [ch 44]"""
    return math.ceil(span_m / usable_case_length_m)

def diagonal_fit_cm(case_L_cm, case_W_cm, piece_width_cm):
    """Longest flat piece of width w on the floor diagonal of an L × W case: √(L²+W²) − w L/W, or the straight length if that is longer. [ch 44]"""
    L, W = max(case_L_cm, case_W_cm), min(case_L_cm, case_W_cm)
    d = math.hypot(L, W) - piece_width_cm * L / W
    return max(d, L)

# ---------------------------------------------------------------- CLI
def _main(argv):
    fns = {n: f for n, f in globals().items() if inspect.isfunction(f) and not n.startswith('_') and n != 'main'}
    if len(argv) < 2 or argv[1] not in fns:
        print(__doc__)
        for n, f in fns.items():
            sig = ', '.join(f'{p.name}' + (f'={p.default}' if p.default is not inspect._empty else '') for p in inspect.signature(f).parameters.values())
            print(f'  {n}({sig})\n      {(f.__doc__ or "").strip()}')
        return
    f = fns[argv[1]]; kwargs = {}
    it = iter(argv[2:])
    for a in it:
        k = a.lstrip('-'); v = next(it)
        try: kwargs[k] = float(v) if v.replace('.', '', 1).replace('-', '', 1).isdigit() else (v.lower() == 'true' if v.lower() in ('true', 'false') else v)
        except StopIteration: break
    print(f(**kwargs))

if __name__ == '__main__':
    _main(sys.argv)
