# Symbols

*Symbols used in the equations. Subscripted forms are listed after the bare letter.*

| Symbol | Meaning | SI unit | Common other unit | First used in |
|---|---|---|---|---|
| a | Lift-curve slope of the finite wing (12). Also speed of sound, 340 m/s at sea level (11), and linear acceleration or deceleration (35, 38). | per rad; m/s; m/s² | per degree; ft/s; g | 11 |
| A | Total rotor disk area, all rotors counted (1, 7). Also conductor cross-section (20, 33), availability (29), and power reduction in a range check in dB (58). | m² | ft²; mm² for wire; dB | 1 |
| AR | Aspect ratio, b²/S. | none |  | 2 |
| b | Wingspan (2). Also an uncorrected acceleration error in the navigation drift estimate (31). | m; m/s² | ft, in | 2 |
| c | Local chord, or any reference length in a Reynolds number (4). Also the battery mass that feeds the auxiliary load in the sizing loop (48). | m; kg | in, mm | 4 |
| c̄ | Mean aerodynamic chord of the wing. | m | in, mm | 2 |
| c_c | Mean chord of a control surface aft of its hinge. | m | mm, in | 16 |
| C_D | Drag coefficient of the aircraft on wing area (13). For a parachute, on nominal canopy area (40). | none |  | 13 |
| C_D0 | Zero-lift drag coefficient. | none |  | 11 |
| C_h | Hinge moment coefficient of a control surface. | none | per degree in ch. 76 | 16 |
| C_L | Lift coefficient. | none |  | 10 |
| C_L,max | Maximum lift coefficient of the whole aircraft, trimmed. | none |  | 6 |
| C_m | Pitching moment coefficient about the CG. | none |  | 10 |
| C_P | Propeller power coefficient, P / (ρ n³ D⁵). Static value near 0.045 at pitch-to-diameter 0.5. | none |  | 18 |
| C_T | Propeller thrust coefficient, T / (ρ n² D⁴). Static value near 0.10 at pitch-to-diameter 0.5. | none |  | 18 |
| d | Stopping distance or stroke (25, 41). Also fastener diameter (27), link range (32), distance flown before a failsafe acts (60), and spacing of a wire pair (69). | m | mm, ft, km | 25 |
| D | Propeller or rotor diameter (59). Also drag force (13). Read by context. | m; N | in; lbf | 59 |
| DL | Disk loading, T/A. In N/m² in Equation 7.1. On a mass basis in kg/m² in the 40√DL hover rule (7, 42). | N/m² | kg/m², lb/ft² | 7 |
| e | Oswald or span efficiency factor, 0.7 to 0.85 for a complete small aircraft (11). Also nameplate pack specific energy in the sizing loop (48). | none; J/kg | Wh/kg | 11 |
| e_b | Usable battery specific energy at pack level, nameplate times usable fraction k. | J/kg | Wh/kg (1 Wh/kg = 3,600 J/kg) | 3 |
| E | Young’s modulus (14, 26). Also pack energy (21) and kinetic energy to absorb at capture (41). | N/m²; J | GPa, Msi; Wh | 14 |
| f | Parasite drag area, C_D0S (13). Also frequency (32, 68, 70). | m²; Hz | cm², in²; MHz | 13 |
| f_BP | Blade-passage frequency, blades × RPM / 60. | Hz |  | 59 |
| f_energy | Battery or fuel mass fraction of gross mass. | none | % | 5 |
| f_margin | Growth margin held as a fraction of gross mass. | none | % | 48 |
| f_n | Natural frequency of a soft mount, (1/2π)√(k/m). | Hz |  | 30 |
| f_prop | Propulsion mass fraction, less battery. | none | % | 48 |
| f_struct | Structure mass fraction. | none | % | 48 |
| FM | Rotor figure of merit, ideal hover power over actual shaft power. 0.5 to 0.7 for small fixed-pitch propellers. | none |  | 1 |
| g | Acceleration of gravity, 9.81 m/s² (9.80665 in the lookup tables). | m/s² | 32.2 ft/s² | 3 |
| G | Mass growth factor: gross mass added per unit of fixed mass added, performance held. | none |  | 5 |
| h | Distance between spar cap centers (14). Also altitude in the standard atmosphere (74). | m | mm; ft | 14 |
| H | Control surface hinge moment. | N·m | kg·cm, oz·in | 16 |
| I | Electric current (19). Also mass moment of inertia, Σmr² (5). | A; kg·m² |  | 5 |
| I_0 | Motor no-load current. | A |  | 19 |
| I_max | Rated continuous pack current, C rate × capacity. | A |  | 21 |
| J | Propeller advance ratio, V / (nD). | none |  | 18 |
| k | Usable fraction of nameplate pack energy, about 0.80 for a new warm pack and 0.65 over pack life (48, lookup tables). Also mass per unit of delivered energy, with k_batt and k_fuel for the two systems compared (24), and mount stiffness (30, 68). | none; kg/J; N/m | kg/kWh; N/mm | 24 |
| K | Induced drag factor, 1 / (π AR e) (11). Also the measured-over-predicted correlation factor (51). | none |  | 11 |
| K_t | Motor torque constant, 9.55 / K_v. | N·m/A | oz·in/A | 19 |
| K_v | Motor speed constant. | rad/(s·V) | RPM/V | 19 |
| l_H, l_V | Tail arms, wing quarter chord to horizontal and vertical tail quarter chord. | m | in, mm | 2 |
| L | Lift (12). Also conductor length, out and back (20, 33), bond overlap length (27), and a scale length in the scaling laws (4). | N; m | lbf; mm | 4 |
| L/D | Lift-to-drag ratio. In cruise, with everything hanging out, 8 to 15 for small aircraft. | none |  | 1 |
| m | Aircraft mass, gross or takeoff (3). Also the mass of one item in an inertia sum (5) and the suspended mass on a mount (30). | kg | lb, g | 3 |
| ṁ | Air mass flow through a jet or fan. ṁ_air is cooling airflow (34) and ṁ_fuel is fuel flow (22). | kg/s | g/s, g/h | 22 |
| m_0, m_1 | Gross mass at the start (5, 9) and mass at the end of a fuel-burning flight (9). | kg | lb | 5 |
| m_b, m_batt | Battery mass. | kg | lb, g | 3 |
| m_fixed | Mass that does not scale with the aircraft: avionics and fixed equipment (48), or the conversion hardware of a hybrid system (24). | kg | lb | 24 |
| m_payload | Payload mass. | kg | lb, g | 5 |
| n | Load factor, lift over weight (11). Also propeller speed in revolutions per second (19, written n_rps in ch. 12) and the number of things built on a shortcut (52). | none; 1/s | g; RPM = 60 n | 11 |
| n_avg, n_open, n_x | Average capture deceleration (41), parachute opening load (40), and fore-and-aft launch load factor (38), all in g. | none | g | 38 |
| n_max | Load factor the wing can generate at speed V, (V/V_s)². | none | g | 25 |
| N | Number of propeller blades (59). Also production quantity (28), learning cycles per year (54), and number of test repeats (61). N* is the crossover quantity between two processes. | none |  | 59 |
| p | Static air pressure in the standard atmosphere. | Pa | hPa, inHg | 74 |
| P | Power, shaft power unless labeled (18). Also load on a joint or fastener (27) and number of cells in parallel (21). | W; N | hp; lbf | 18 |
| P_aux, P_hotel | Payload and avionics electrical load. Two names for the same thing. | W |  | 9 |
| P_available, P_required | Thrust power available, and power required for level flight, drag × speed. P_req in ch. 12. | W | hp | 8 |
| P_cruise | Battery power to cruise, W V / [η (L/D)]. | W |  | 1 |
| P_cu, P_heat, P_loss | Resistive heating in motor windings, in a pack, and in wiring, I²R in each case. | W |  | 19 |
| P_elec, P_electrical | Electrical power drawn from the battery. | W |  | 7 |
| P_hover, P_ideal | Hover power. P_ideal is momentum theory with no losses, P_hover in ch. 1 is shaft power, and P_hover/m in ch. 43 is electrical power per kilogram. | W | W/kg, W/lb | 1 |
| q | Dynamic pressure, ½ρV². q_s is its value in a propeller slipstream (17). | N/m² (Pa) | lb/ft² | 13 |
| Q | Motor shaft torque. Q_servo is required servo torque (76). | N·m | kg·cm, oz·in | 19 |
| r | Distance of a mass from the rotation axis (5). Also distance from a conductor to a sensor (31, 69). r_arm and r_horn are servo arm and control horn lengths (76). | m | mm, cm | 5 |
| R | Range (3). Also turn radius (11), electrical resistance (19, 20), recurring cost per unit (28), and reliability of one mechanism in a series chain (39). | m; Ω; currency; none | km, mi, nmi; mΩ | 3 |
| R_cell, R_pack, R_total, R_wire | Resistance of one cell, of the pack (R_cell · S / P), of the whole supply path, and of a wire run. R_m in ch. 74 is motor winding resistance, plain R in ch. 20. | Ω | mΩ | 20 |
| Re | Reynolds number, ρVc/μ. About 68,500 × V × c at sea level in SI units. | none |  | 4 |
| RPM | Shaft speed in revolutions per minute, 60 n. | rad/s | RPM | 59 |
| s | Powered stroke of a launcher. s_g and s_L are takeoff and landing ground roll (36). | m | ft | 36 |
| S | Wing reference area (2). Also number of cells in series (21). | m²; none | ft², dm², in² | 2 |
| S_0 | Nominal parachute canopy area. | m² | ft² | 40 |
| S_c | Area of a control surface aft of its hinge. | m² | cm², in² | 16 |
| S_H, S_V | Horizontal and vertical tail areas. For a V-tail, the projected areas. | m² | dm², in² | 2 |
| SM | Static margin, (x_np − x_cg) / c̄. | none | % MAC | 10 |
| t | Time, endurance (9). Also laminate thickness (27). t_0 is the still-air or baseline time (35, 43). | s; m | h, min; mm | 9 |
| t_detect, t_respond, t_lat | Failsafe detection time, time for the response to take effect (60), and total sensing-to-thrust latency (35). | s | ms | 35 |
| t_hover | Hover time. | s | min, h in Equation 42.1 | 3 |
| T | Thrust (7). Also tooling cost (28), air temperature (57, 74), and mount transmissibility (68). T_max is thrust at the motor RPM limit (43) and T_rotor is vertical rotor thrust in transition (72). | N; currency; K; none | lbf, kgf, g; °C | 7 |
| T/W | Thrust-to-weight ratio, static unless stated. | none |  | 8 |
| T_amb, ΔT_ss | Ambient temperature and steady-state temperature rise in a thermal run. ΔT in ch. 35 is allowed cooling-air temperature rise. | K | °C, °F | 34 |
| v | Closing velocity at impact or against an obstacle. | m/s | ft/s, kt | 25 |
| V | True airspeed (1). Also voltage applied to a motor (19). | m/s; V | kt, mph, ft/s | 1 |
| ΔV | Voltage drop in wiring, I R steady or L_w dI/dt transient. | V | mV | 20 |
| V_0 | Flight speed in the jet propulsion equations (23). Also release speed in a hand launch (37). | m/s | kt, mph | 23 |
| V_d, V_deploy | Steady parachute descent rate, and airspeed at line stretch. | m/s | ft/s | 40 |
| V_exit | Speed at the end of a launcher rail or tube. | m/s | kt, mph | 38 |
| V_H, V_V | Horizontal and vertical tail volume coefficients. | none |  | 2 |
| V_nom, V_oc, V_load | Nominal cell voltage, open-circuit pack voltage at the present state of charge, and pack voltage under load. | V |  | 21 |
| V_s | Stall speed at 1 g. V_s,turn = V_s√n in a level turn (11). | m/s | kt, mph | 4 |
| w | Wind speed along track (43). Also bond width (27) and usable net width (41). | m/s; m | kt, mph; mm | 27 |
| W | Weight, m g. | N | lbf | 1 |
| W/A | Disk loading on a weight basis. Same quantity as DL. | N/m² | kg/m², lb/ft² | 1 |
| W/S | Wing loading. | N/m² | kg/m², g/dm², oz/ft², lb/ft² | 6 |
| x_cg, x_np, x_p | Stations of the CG, the neutral point, and a payload, measured aft from one datum. Δx_cg is CG shift from a mass change, and Δm is that mass (34). | m | mm, in, % MAC | 10 |
| δx, Δx | Position drift from an uncorrected acceleration error (31), and apparent error between two misaligned records, (dx/dt) · Δt (61). | m; signal units |  | 31 |
| η | Efficiency. Bare η is the whole chain from battery to thrust power, 0.4 to 0.6 and typically 0.5 (1). In ch. 19 it is propeller efficiency alone. | none | % | 1 |
| η_drive | Motor and ESC efficiency together, 0.80 to 0.90 near the design point. | none | % | 3 |
| η_p | Installed propeller efficiency (9). In ch. 24, ideal propulsive efficiency of a jet. | none | % | 9 |
| θ | Attitude or tilt error (31). Also launch tube elevation above horizontal (39). | rad | degrees | 31 |
| μ | Dynamic viscosity of air, 1.79 × 10⁻⁵ Pa·s at 15 °C (4). Also rolling friction coefficient of a surface, with μ_eff for all retarding effects at landing (36). | Pa·s; none |  | 4 |
| μ_0 | Permeability of free space, 4π × 10⁻⁷ T·m/A. | T·m/A |  | 31 |
| ρ | Air density, 1.225 kg/m³ at sea level standard (1). Also material density in the material indices (26). | kg/m³ | slug/ft³; g/cm³ | 1 |
| ρ_Cu | Resistivity of copper, 1.72 × 10⁻⁸ Ω·m at 20 °C. | Ω·m | 0.0172 Ω·mm²/m | 20 |
| σ | Density ratio, ρ/ρ₀ (22). Also one-sigma path error at a net (41) and run-to-run scatter, with σ_mean = σ/√N (61). | none; m; as measured |  | 22 |
| τ | Thermal time constant (57). Also total pure delay in a control loop (70). | s | min; ms | 57 |
| φ | Bank angle (11). Also phase lag from a delay, 360° · f · τ (70). | rad | degrees | 11 |
