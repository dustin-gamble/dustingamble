# Rules of thumb

Each rule with the conditions it holds under. A rule without its conditions is a guess.

## Chapter 1 · A field guide to drone configurations
- **Hovering costs three to ten times the power of cruising.** *(conditions: Small electric aircraft, open rotors, wing L/D of 8 to 15)*
  Same mass, same battery. Low disk loading and a draggy airframe put you near three. Small lift props on a clean airplane put you near ten. Big disks: the designer expected to hover. Small disks on a wing: hover is the launch and recovery system.
- **The main tone is blades × RPM ÷ 60. For two blades, RPM is 30 times the tone in hertz.**
  Three blades, 20 times. Four blades, 15 times. Any spectrum-analyzer app on a phone finds the tone; count the blades if you can see them, because three blades at 4,000 RPM and two at 6,000 make the same 200 Hz.Typical signatures by class are on the What you hear card. For your own aircraft, see Flight test.

## Chapter 2 · Read the airframe
- **Horizontal tail volume 0.4 to 0.7. Vertical 0.02 to 0.05.** *(conditions: Conventional aft-tail aircraft)*
  Most pleasant small aircraft land here. If a tail measures well below 0.35, look for a flight controller doing the stabilizing, a very narrow CG range, or a scaling error in your photo.

## Chapter 3 · Mission drives configuration
- **One minute of hover costs four to five minutes of cruise.** *(conditions: Small electric hybrid VTOL, typical)*
  On a lift + cruise aircraft with small lift props, hover draws roughly five times cruise power. Budget hover in seconds: thirty up, sixty down is typical. Ten minutes of station-keeping is a different aircraft.

## Chapter 4 · Units, scaling, and quick estimates
- **Re ≈ 70,000 × speed × chord** *(conditions: Sea level, standard day)*
  Speed in m/s and chord in m. In shop units, Re ≈ 780 × mph × inches. Below about 100,000, treat published airfoil data with suspicion and expect lower maximum lift and higher drag than the chart says.

## Chapter 5 · Weight and mass properties
- **A gram of payload becomes three to eight grams of airplane.** *(conditions: Performance held constant)*
  Resize to carry 100 g of payload at the same stall speed, climb, and endurance and the aircraft settles 300 to 800 g heavier. The multiplier is one over the payload fraction (Equation 5.1): small UAS carry 0.12 to 0.25, so four to eight; a big payload fraction gets down to about three. It runs both ways: a gram saved is worth the same multiple if you resize.

## Chapter 6 · Wing loading
- **V_s ≈ 3.65 × √(kg/m²), in m/s** *(conditions: Sea level, no flaps, C_L,max ≈ 1.2)*
  In shop units, V_s in mph ≈ 4.5 × √(oz/ft²). For a hand launch, stay under about 6 to 8 kg/m² (20 to 26 oz/ft²), which keeps stall near or below 10 m/s (22 mph). Add 10% to the speed for a hot day at a high field.

## Chapter 7 · Disk loading
- **Hover power ≈ 40 W/kg × √(disk loading in kg/m²)** *(conditions: Sea level, small electric, FM·η ≈ 0.5)*
  In US units it is the same number: about 40 W per pound × √(lb/ft²). A multirotor at 10 kg/m² (2 lb/ft²) hovers on roughly 125 W/kg.

## Chapter 8 · Power loading and thrust-to-weight
- **T/W of 2 for a multirotor. 1.3 for a 4+1 VTOL that does not yaw on its rotors.** *(conditions: Multirotors and hovering VTOL)*
  Both at the worst moment: maximum weight, end-of-pack voltage, hottest and highest site. Thrust is not linear with throttle, so check it with thrust-stand data and not with hover throttle alone. For fixed-wing, installed electrical power per kilogram is about g × (V / (L/D) + V_climb) divided by the overall efficiency in climb, which is typically 0.45 to 0.55.

## Chapter 9 · Energy and endurance
- **Range in km ≈ 0.37 × Wh/kg × battery fraction × efficiency × L/D** *(conditions: Electric fixed wing, still air, hotel load ignored)*
  With 200 Wh/kg usable, a battery fraction of 0.30, 0.55 from battery to thrust, and L/D of 12, that is about 145 km (90 mi). Divide by cruise speed for endurance.

## Chapter 10 · Stability and center of gravity
- **Neutral point ≈ 25% MAC + half the tail volume. Put the CG 10% ahead of it.** *(conditions: Conventional tail, first layout)*
  With V_H = 0.5 the neutral point lands near 50% MAC and the first-flight CG near 40%. The one half bundles tail lift slope, downwash, and tail dynamic pressure; 0.4 to 0.6. A large fuselage or a tractor propeller ahead of the CG pulls the neutral point forward by a few percent. The old saying holds: a nose-heavy aircraft flies poorly, a tail-heavy one flies once.

## Chapter 11 · Speed and maneuvering
- **At 45° of bank: 1.4 g, stall speed up 19%, radius ≈ V²/10 in meters** *(conditions: Level turn, any aircraft)*
  V is in m/s. At 20 m/s (45 mph) that is a 40 m radius. At 60° it is 2 g and stall speed up 41%. If the aircraft loiters at 1.3 times stall speed, a 45° bank leaves a 9% margin and a 60° bank leaves none. Most small aircraft should hold an autopilot bank limit of 30 to 45°.

## Chapter 12 · Lift
- **Bank on an aircraft C_L,max of 1.1 to 1.2 until you have measured it.** *(conditions: Unflapped wing, Re 150,000 to 500,000)*
  Use 1.0 if any part of the wing is below Re 100,000 at stall speed, or if the wing is built by hand without molds. Simple flaps or drooped ailerons add 0.2 to 0.4. Whatever you assume, write it next to the stall speed it produced.

## Chapter 13 · Drag
- **Blunt hardware costs its frontal area, one for one.** *(conditions: Small UAS, below about 40 m/s)*
  A bare tube, bracket, or antenna has a drag area about equal to its frontal area. On a 5 kg class aircraft (150 to 400 cm², or 25 to 60 in², total), every 10 cm² (1.5 in²) of bluff hardware costs roughly 3 to 7 percent of parasite drag. Count it like grams.

## Chapter 14 · Airfoils
- **Nine to twelve percent thick, and no thicker than the spar needs.** *(conditions: Wing sections, Re 150,000 to 500,000)*
  Go thinner, 6 to 9 percent, below Re 100,000. Use 12 to 15 percent only above about Re 300,000 or at the root of a tapered wing where chord is long and the bending moment is highest. Check the tip at stall speed, the lowest Reynolds number on the wing.

## Chapter 15 · Wings
- **Default wing: AR 8 to 12, taper 0.5 to 0.7, two degrees of washout.** *(conditions: Small fixed-wing UAS, 1 to 25 kg)*
  Go lower in aspect ratio for packaging, ruggedness, or high speed. Go higher only when endurance is the requirement, the spar is carbon, and you have checked the tip Reynolds number and the torsional stiffness.

## Chapter 16 · Tails and control surfaces
- **Servo stall torque of at least 2.5 times the full-deflection hinge moment at maximum speed.** *(conditions: Plain surfaces, direct pushrod linkage)*
  Compute the hinge moment with C_h = 0.3 at the fastest speed the aircraft can reach, including a dive, not at cruise. Get the surface throw from the servo's full mechanical travel; reducing throw in software throws away torque and resolution.

## Chapter 17 · Configuration aerodynamics
- **Keep the rotors carrying load until the wing is at 1.2 to 1.3 times its stall speed** *(conditions: Lift-plus-cruise and tilting VTOL)*
  Use the stall speed at the actual mass, flaps, and density of the day, not the brochure number. Size rotor thrust so the aircraft can still accelerate level at mid-corridor, where the wing carries about half the weight. On the way back, start the rotors before airspeed falls below the same margin.

## Chapter 18 · Propellers
- **Best efficiency near pitch speed. No thrust at about 1.3 times pitch speed.** *(conditions: Fixed pitch, constant RPM, typical sport and multirotor propellers)*
  Pitch speed in m/s is pitch in inches × 0.0254 × RPM / 60. Efficiency typically peaks at 80 to 100% of pitch speed, where thrust is already down to about half the static value at that RPM. Thrust reaches zero at roughly 120 to 140% of pitch speed. If the aircraft needs thrust for control at top speed, top speed must sit well below that.

## Chapter 19 · Electric motors
- **K_t ≈ 9.55 / K_v, and loaded RPM ≈ 0.8 × K_v × volts** *(conditions: Brushless outrunners, direct drive)*
  Current is torque divided by K_t, plus the no-load current. Full-throttle RPM with a well-matched propeller is typically 75 to 85% of the no-load value. For sizing, hobby-class outrunners take 3 to 5 W of electrical input per gram of motor in short bursts. Continuous is about half that unless cooling is very good. Size so hover or cruise sits at no more than about half the maximum current.

## Chapter 20 · ESCs and electrical power
- **ESC at 1.3 to 1.5 times measured maximum current. Wiring loss under 2% at maximum current.** *(conditions: Small electric aircraft)*
  Keep battery-to-ESC leads as short as the layout allows and put extra length in the phase wires. If total drop in wires and connectors is under about 2% of pack voltage at full current, the wiring is fine; the question left is whether it runs cool.

## Chapter 21 · Batteries
- **Plan on about 65 to 70% of nameplate energy** *(conditions: First energy budget)*
  Take 80% for cutoff and landing reserve, 90% for current and temperature, and 90% for a pack partway through its life. 0.8 × 0.9 × 0.9 = 0.65. A warm, new pack at a gentle rate does better, a cold one at a high rate worse. Measure your own pack at your own current and replace this number as soon as you can.

## Chapter 22 · Piston and rotary engines
- **A kilogram of fuel is worth ten kilograms of battery** *(conditions: Small engines, best-point BSFC)*
  At 300 to 500 g/kWh, fuel delivers 2,000 to 3,300 Wh/kg at the shaft against about 200 Wh/kg for a pack through a motor. The engine, mounts, tank, ignition, and generator cost a few kilograms before the first gram of fuel. Hybrid propulsion and fuel cells owns the crossover.

## Chapter 23 · Turbines and electric ducted fans
- **Thrust per kilowatt = 2,000 ÷ jet velocity** *(conditions: Static, sea level)*
  With thrust in N, jet power in kW, and jet velocity in m/s. Divide by overall fan and motor efficiency, typically 0.5 to 0.7, to get electrical power. Below about 60 m/s (115 kt) a propeller is the better choice. Between 60 and 100 m/s a propeller still wins on endurance and a fan wins on packaging. A jet is clearly right from about 100 m/s (195 kt) up.

## Chapter 24 · Hybrid propulsion and fuel cells
- **Under an hour, fly the battery** *(conditions: Small aircraft, current hardware)*
  Hybrid and fuel-cell hardware typically weighs 2 to 5 kg per kW of average power before it stores anything; a battery delivering that kW for an hour weighs 5 to 7 kg. The complexity starts to pay between one and two hours and is clearly ahead past three. Figure 24.1's idealized inputs put the crossover under an hour; the mounts, cooling, and fuel system of a real installation push it to one to two. Near the crossover, take the battery and work on drag and mass.

## Chapter 25 · Structural loads
- **Size the spar for flight. Size everything else for the ground.** *(conditions: Small airframes under about 25 kg)*
  A 3 m/s arrival is a free drop from about 0.46 m (18 in); if the airframe cannot take that drop at flight mass, onto the surface you plan to land on, it is not finished. Every doubling of stopping distance halves the load, so a little crush depth is worth more than a lot of laminate.

## Chapter 26 · Materials
- **If it softens below 80 °C, it needs white paint, shade, or a different material.** *(conditions: Anything stored in a vehicle or flown in summer sun)*
  That covers PLA, PETG, and any epoxy laminate never post-cured. A few hours at 60 to 80 °C in a plywood box with a heater and a thermostat raises the resin’s limit by tens of degrees; follow the resin maker’s schedule.

## Chapter 27 · Joining
- **Overlap 20 to 30 times the thinner adherend, then stop adding length.** *(conditions: Bonded laps in thin laminate or sheet)*
  Past that, add width, taper the ends, or add a fastener at the end where peel starts. For shop-made bonds without coupon data, design to an average shear stress around 3 to 5 MPa (450 to 700 psi), a small fraction of the datasheet value. That margin pays for imperfect prep, peel, heat, and moisture.

## Chapter 28 · Manufacturing by quantity
- **If your honest quantity is within a factor of three of the crossover, take the low-tooling path.** *(conditions: Deciding when to buy tooling)*
  Quantity forecasts run high and designs change. Tooling bought early gets recut or scrapped. Cut hard tooling after the second-unit lessons are in the design, and only for the parts that have stopped changing.

## Chapter 29 · Designing for repair
- **Every flight: no tools. Every ten flights: one tool. Any field repair: under fifteen minutes, or swap the module.** *(conditions: Access and repair time)*
  If a likely repair takes longer than that, it belongs on the bench, and the field kit needs the spare module instead.

## Chapter 30 · Flight controllers
- **Three to five between loops, and tune from the inside out.** *(conditions: Cascaded loops, small electric aircraft)*
  Keep each loop at least three times slower than the loop inside it. Get the rate loop clean before touching attitude, and attitude before position. If an outer loop oscillates slowly, look one loop inward before changing its gain.

## Chapter 31 · Navigation
- **Twist the pair, then buy distance.** *(conditions: Small electric aircraft, external compass)*
  Keep supply and return leads together, twisted where you can, then put the magnetometer at least 10 to 15 cm from any lead carrying tens of amps and farther from the motor: use a mast, wingtip, or boom. Give the GNSS antenna a clear upward hemisphere and a ground plane, opposite the video transmitter.

## Chapter 32 · Communications
- **Six dB per doubling. Keep 10 to 20 dB in hand.** *(conditions: Line of sight, free-space estimate)*
  Budget the link at maximum mission range and look for at least 10 dB of margin on a well-installed system, closer to 20 dB if the aircraft maneuvers hard, flies low, or works near other emitters. If the paper margin is under 10 dB, the link will drop in turns.

## Chapter 33 · Electrical integration
- **Separate the rails. Size for stall, not average.** *(conditions: Small electric aircraft, 5 V avionics)*
  Give the autopilot and receiver a regulator of their own, with the servos on another. Size the servo regulator for the sum of stall currents of the servos that can stall together. Keep main-bus drop under about 2% of pack voltage at maximum current, and keep servo-lead drop under about 0.3 V at stall.

## Chapter 34 · Payload integration
- **Payload on the CG, or plan the battery travel.** *(conditions: Small electric fixed-wing)*
  Typical payload fraction is 10 to 30% of takeoff mass. Put anything that changes mass, swaps, or drops as close to the CG as the view allows. If it must live in the nose, design in enough battery travel to rebalance for the lightest and heaviest payload, and mark the positions.

## Chapter 35 · Autonomy
- **Flight-critical on the autopilot. Everything clever on the companion.** *(conditions: Any aircraft with a companion computer)*
  If pulling the companion computer's power connector in flight would endanger the aircraft, the partition is in the wrong place. Pull it on purpose during flight test.

## Chapter 36 · Runways and conventional landing
- **Pavement to leave, grass to arrive.** *(conditions: Small unbraked aircraft)*
  Pavement to long grass changes takeoff roll by 30 to 60% at typical T/W and unbraked landing roll by a factor of three. If the strip is grass, size wheels to the grass first and check nose-over before anything else.

## Chapter 37 · Hand launch
- **Under 4 kg, stall under 10 m/s, T/W over 0.5.** *(conditions: No wind, average thrower)*
  Inside those three numbers (9 lb, 22 mph) hand launch is a reasonable baseline. Outside any one of them, plan for a launcher from the start and treat hand launch as a bonus.

## Chapter 38 · Catapults and rails
- **Two meters and ten g gets you twenty meters per second.** *(conditions: Constant acceleration)*
  20 m/s is 39 kt or 45 mph. Scale from there by the square: 30 m/s from the same 2 m takes 23 g, or the same 10 g takes 4.6 m of rail. Then multiply by 1.5 to 2 for a bungee peak before you size a single bracket.

## Chapter 39 · Tube launch
- **To claim 0.95 you need 45 clean cycles. To claim 0.99 you need 230.** *(conditions: Zero-failure demonstration)*
  With no failures allowed, the number of trials for reliability R at 90% confidence is ln(0.1) / ln(R). That is affordable per mechanism on a bench and not as full launches, which is why the bench rig matters more than the launcher.

## Chapter 40 · Parachute recovery
- **5 m/s descent needs 0.85 m² of canopy per kg and lands like a 1.3 m drop.** *(conditions: Sea level, round canopy)*
  That is about 4.2 ft² per lb. Descent rate rises about 5% per 1,000 m of density altitude (Operating environment).

## Chapter 41 · Nets, arrestment, and capture
- **Average g ≈ V_c² / (20 d). Double it for the peak.** *(conditions: Closing speed in m/s, stroke in m)*
  20 m/s (39 kt) into a 4 m (13 ft) stroke is 5 g average and about 10 g peak. Each extra meter of stroke is worth more than any reinforcement you can add to the nose. Energy per kilogram is V_c²/2: 200 J/kg at 20 m/s.

## Chapter 42 · VTOL as a launch and recovery system
- **Each minute of hover costs 4 to 8% of the battery, or 5 to 9 minutes of cruise.** *(conditions: Lift+cruise, battery about 30% of mass at 200 Wh/kg)*
  The low end is 10 kg/m² (2 lb/ft²), the high end 40 kg/m² (8 lb/ft²). Budget hover in seconds per phase: climb-out, transition, back-transition, descent, and one full go-around landing held in reserve. Lift-rotor thrust-to-weight is set in Power loading and thrust-to-weight.

## Chapter 43 · Operating environment
- **Keep wind under half of cruise speed, and add 5% per 1,000 m of density altitude.** *(conditions: Small UAS, planning level)*
  At half of cruise speed an out-and-back leg takes 33% longer and a pure crosswind needs 30° of crab. Each 1,000 m of density altitude adds about 5% to true stall speed and hover power, 10% to launch energy, and removes about 10% of maximum thrust. Density altitude rises roughly 35 m for each °C above standard.

## Chapter 44 · It has to get there first
- **One person, one case, twenty kilograms, one lift into a truck bed.** *(conditions: Small UAS, planning level)*
  Size the cases so the smallest crew that will ever deploy the system can move them in one trip from the vehicle. Set the longest piece from the case, not the case from the piece, and count each wing joint as a few percent of wing mass and a few minutes at the field. For commercial flights the limits are in the table.

## Chapter 45 · Start with the mission
- **One page, about five numbers, a test for each.** *(conditions: Concept stage)*
  If the mission cannot be stated on one page with roughly five driving numbers, each with a condition and a way to measure it, the team is not ready to choose a configuration. It is ready to go ask more questions.

## Chapter 46 · Requirements without ground truth
- **One or two requirements size the aircraft. Find them first, then price them.** *(conditions: Early concept work)*
  If you cannot say which requirement is driving the mass, you are not ready to argue about any of them.

## Chapter 47 · Concept generation
- **Three alternatives that differ in kind.** *(conditions: Concept stage)*
  If every concept on the wall has the same lift, launch, and energy architecture, you have one concept with several paint jobs. Force at least three that differ in one of those choices, and size all of them to the same level before choosing.

## Chapter 48 · The first sizing
- **Three passes, then look at the denominator.** *(conditions: First sizing)*
  A healthy concept settles to within about 2% in three passes from a reasonable guess. If the mass is still moving by more than 5% on the third pass, stop iterating and add up the fractions. When structure, propulsion, margin, and energy together approach 100% of gross mass, the concept is fragile even if it technically closes.

## Chapter 49 · Build something immediately
- **Something full scale, at true mass, in the first week.** *(conditions: Concept stage)*
  If the project is more than a week old and nothing physical exists, the schedule is already carrying risk that no analysis will find. The first object does not need to look like an aircraft. It needs the real components, the real case, and an honest scale.

## Chapter 50 · Retire the biggest risk first
- **The top unknown always has a test date.** *(conditions: Any stage)*
  At any moment, the team should be able to name the biggest remaining unknown, the experiment that addresses it, and the day that experiment runs. If the top risk has no date, the plan is organized around something other than learning.

## Chapter 51 · Simulation and hardware
- **No test without a prediction. No model without a measurement.** *(conditions: Any stage)*
  Write the expected number before every test, even if it is a guess. Anchor every model that drives a decision with at least one measurement on your own hardware, in the regime you care about. A result within 10% of prediction is a working model. A result off by 30% is the most valuable thing you learned that week.

## Chapter 52 · Technical debt
- **If it is not written down, it is not debt. It is a defect.** *(conditions: Prototype stages)*
  Borrow freely on finish, tooling, convenience, and automation while the concept is unproven. Do not borrow on interfaces, on architecture, or on safety. Those loans carry the highest interest, because everything else gets built on them.

## Chapter 53 · The house of cards
- **Add 10 percent to the mass. If a requirement breaks, you do not have a design yet.** *(conditions: Concept and preliminary design)*
  Do the same with 10 percent off L/D and 10 percent off usable battery energy, one at a time. A concept that closes survives each of them. Prototype mass growth of 5 to 15 percent between first sizing and first flight is typical, so this is a likely case, not a worst case.

## Chapter 54 · Schedule learning
- **If nothing has been built or tested in a month, the schedule is measuring activity.** *(conditions: Small UAS development)*
  For aircraft in the hand-launch to small-catapult class, a loop of two to six weeks from idea to flight result is achievable with in-house fabrication. Halving the loop time is worth more than almost any improvement to the analysis inside it.

## Chapter 55 · Prototype generations
- **One sentence before you build: this aircraft exists to find out ___.** *(conditions: Any generation)*
  If the blank holds more than one question, you are probably building two generations at once. Split it, or accept that it will be as slow as the later generation and as rough as the earlier one.

## Chapter 56 · Take the Gamble
- **If you can lose the stake three times in a row and keep going, the bet is small enough.** *(conditions: Early development)*
  And if either outcome would leave the plan unchanged, skip it. Put the days into a bet that can move a decision.

## Chapter 57 · Bench test
- **Run until the temperature climbs less than 1 °C per minute, or for three time constants, whichever is longer.** *(conditions: Thermal runs)*
  At three time constants the part has reached 95% of its final rise. Small motors and ESCs have time constants of a few minutes, so an honest thermal test is 10 to 20 minutes, not two.

## Chapter 58 · Ground test
- **Keep taxi airspeed below 70% of stall speed, or brief the run as a flight.** *(conditions: Wheeled aircraft, taxi tests)*
  Lift goes with speed squared, so at 0.7 V_s the wing carries at most half the weight, leaving margin for a gust and a bump. Airspeed counts, so a headwind uses up the margin before the wheels turn.

## Chapter 59 · Flight test
- **Step airspeed by about 10%. That is about 20% in dynamic pressure.** *(conditions: Expanding beyond speeds already flown)*
  Since q goes with V², a 10% speed step raises every air load by 21%. Use smaller steps near the predicted edge and larger ones mid-envelope, where margins are wide. Look at the data after each step before taking the next.

## Chapter 60 · Test the failure
- **Count the seconds, then multiply by speed.** *(conditions: Any automatic failsafe)*
  Add the detection timeout to the response time and multiply by airspeed or sink rate. If that is more than you have in the worst phase of the mission, shorten the timeout or change the response. Timeouts chosen to avoid nuisance trips at altitude are usually too long for takeoff and landing.

## Chapter 61 · Data into decisions
- **A difference smaller than twice its own uncertainty is not a result yet.** *(conditions: Comparing two configurations from repeated runs)*
  Find each mean’s uncertainty from the scatter, combine them as the root of the sum of squares, and compare with the difference. Above twice, act; below, fly more repeats or accept that the options are equivalent, which is also a decision.

## Chapter 62 · CG problems
- **Start forward. 10 to 15% static margin.** *(conditions: Conventional tail, first flights)*
  Typical small fixed-wing aircraft fly well with 5 to 15% of MAC. Begin at the forward end and work aft in small steps.

## Chapter 63 · Stalls and spins
- **Minimum airspeed is 1.3 × the measured stall speed** *(conditions: Autonomous fixed-wing)*
  Measured, not calculated, at the heaviest weight. Then check that margin again at the autopilot bank limit, because the turn spends most of it.

## Chapter 64 · Flutter
- **Light, stiff, tight, balanced. In that order of cost.** *(conditions: Small control surfaces)*
  Removing mass behind the hinge and removing free play cost almost nothing. Balance weights cost grams. Stiffer structure costs a redesign. Do the cheap ones on every aircraft.

## Chapter 65 · Structural failure
- **1.5 on the structure, 2 on the joints** *(conditions: Hand-built small aircraft)*
  A factor of safety of 1.5 on limit load is the aircraft standard. Joints, inserts, and printed parts vary more unit to unit, and many builders carry about 2 there; the grams are small because joints are small.

## Chapter 66 · Propulsion failure
- **Run the ESC at no more than about 80% of its continuous rating** *(conditions: Electric, continuous duty)*
  That assumes real cooling airflow over it. Buried in a fuselage with still air, use much less. Burst ratings describe seconds, not a climb.

## Chapter 67 · Battery and power failures
- **Land with 20% left. 3.3 V per cell under load is the floor.** *(conditions: LiPo packs, typical)*
  Cylindrical Li-ion cells run to lower voltages under load, so set their limits from the cell datasheet.

## Chapter 68 · Vibration
- **Mount frequency at one third of the lowest forcing frequency.** *(conditions: Lightly damped soft mount)*
  At a ratio of 3 the mount passes about one eighth of the input. Static sag gives the frequency, f_n ≈ 15.8 / √(sag in mm), so one millimeter of sag is about 16 Hz; elastomers are stiffer in motion than at rest, so the real number runs higher.

## Chapter 69 · EMI and navigation problems
- **Distance is the cheapest shield.** *(conditions: Paired leads, sensor far from them)*
  The field from a supply and return pair falls with the square of distance: triple the distance and one ninth remains. No shielding you can afford in mass does as well at DC.

## Chapter 70 · Control-system problems
- **Ten milliseconds costs 3.6° of phase per hertz.** *(conditions: Pure delay in an attitude loop)*
  Hold delay phase under about 45° at crossover; that caps usable crossover near 1 / (8τ), about 3 Hz for 40 ms of total delay.

## Chapter 71 · Launch failures
- **Release at 1.2 times stall speed or better, with thrust already on.** *(conditions: Typical small fixed-wing)*
  Headwind counts toward airspeed and tailwind counts against it. Stall speed is at today’s weight and today’s density, not the brochure’s.

## Chapter 72 · Transition failures
- **Pitch speed at least 1.5 times stall speed.** *(conditions: Fixed-pitch props meeting the airspeed head-on)*
  Pitch speed is prop rev/s × pitch. Thrust falls toward zero at about 120 to 140 percent of pitch speed (Propellers), leaving about a third of static thrust at 1.2 times stall speed. A first screen; confirm with thrust measured against airspeed.

## Chapter 73 · Human errors
- **If one missed step can lose the aircraft, it should not be a checklist line.** *(conditions: Single-point human steps)*
  Make it an interlock, an arming check, or a part that only fits one way. Keep the checklist for things a second barrier also covers.
