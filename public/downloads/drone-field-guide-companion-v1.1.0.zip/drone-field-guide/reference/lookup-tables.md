# Lookup tables

Computed from the same equations the chapters use. Each table names its formula and its assumptions in the note. Use `tools/dfg_calc.py` for values between the rows.

## Stall speed from wing loading *(ch 6)*

Formula: `V_s = √[ 2 (W/S) / (ρ C_L,max) ]`

Sea level, 1 g. Speeds in m/s with mph in brackets. C_L,max of 1.0 suits a flying wing or a rough small wing, 1.2 a clean unflapped wing, 1.5 a good section with flaps or slots. Multiply by the density factor in the altitude table for a high or hot site, and by √n in a turn.

| m/S, kg/m² | oz/ft² | W/S, N/m² | C_L,max 1.0 | C_L,max 1.2 | C_L,max 1.5 |
|---|---|---|---|---|---|
| 2 | 7 | 20 | 5.7 (13) | 5.2 (12) | 4.6 (10) |
| 3 | 10 | 29 | 6.9 (16) | 6.3 (14) | 5.7 (13) |
| 4 | 13 | 39 | 8.0 (18) | 7.3 (16) | 6.5 (15) |
| 5 | 16 | 49 | 8.9 (20) | 8.2 (18) | 7.3 (16) |
| 6 | 20 | 59 | 9.8 (22) | 8.9 (20) | 8.0 (18) |
| 8 | 26 | 78 | 11.3 (25) | 10.3 (23) | 9.2 (21) |
| 10 | 33 | 98 | 12.7 (28) | 11.6 (26) | 10.3 (23) |
| 12 | 39 | 118 | 13.9 (31) | 12.7 (28) | 11.3 (25) |
| 15 | 49 | 147 | 15.5 (35) | 14.1 (32) | 12.7 (28) |
| 20 | 66 | 196 | 17.9 (40) | 16.3 (37) | 14.6 (33) |
| 25 | 82 | 245 | 20.0 (45) | 18.3 (41) | 16.3 (37) |
| 30 | 98 | 294 | 21.9 (49) | 20.0 (45) | 17.9 (40) |
| 40 | 131 | 392 | 25.3 (57) | 23.1 (52) | 20.7 (46) |
| 50 | 10.2 lb/ft² | 490 | 28.3 (63) | 25.8 (58) | 23.1 (52) |
| 75 | 15.4 lb/ft² | 735 | 34.7 (78) | 31.6 (71) | 28.3 (63) |
| 100 | 20.5 lb/ft² | 981 | 40.0 (90) | 36.5 (82) | 32.7 (73) |

## Hover power from disk loading *(ch 7)*

Formula: `P/m = g √[ (m/A) g / (2ρ) ] ÷ (FM · η)`

Sea level. Disk loading counts the area of all rotors. Ideal is momentum theory with no losses. 0.65 is a good large rotor and drive. 0.5 is where most small electric multirotors land, battery to air. The last column is grams of thrust per electrical watt at 0.5.

| m/A, kg/m² | lb/ft² | N/m² | Ideal, W/kg | At 0.65, W/kg | At 0.5, W/kg | g per W at 0.5 |
|---|---|---|---|---|---|---|
| 2 | 0.4 | 20 | 28 | 43 | 55 | 18.0 |
| 3 | 0.6 | 29 | 34 | 52 | 68 | 14.7 |
| 5 | 1.0 | 49 | 44 | 67 | 88 | 11.4 |
| 7.5 | 1.5 | 74 | 54 | 83 | 107 | 9.3 |
| 10 | 2.0 | 98 | 62 | 95 | 124 | 8.1 |
| 15 | 3.1 | 147 | 76 | 117 | 152 | 6.6 |
| 20 | 4.1 | 196 | 88 | 135 | 175 | 5.7 |
| 30 | 6.1 | 294 | 107 | 165 | 215 | 4.7 |
| 50 | 10.2 | 490 | 139 | 213 | 277 | 3.6 |
| 75 | 15.4 | 735 | 170 | 261 | 340 | 2.9 |
| 100 | 20.5 | 981 | 196 | 302 | 392 | 2.5 |
| 150 | 30.7 | 1,471 | 240 | 370 | 481 | 2.1 |
| 200 | 41.0 | 1,961 | 277 | 427 | 555 | 1.8 |

## First-guess electric endurance *(ch 9)*

Formula: `t = (m_b/m) · e · k · η · (L/D) / (g V)`

Minutes, fixed wing, cruising at 18 m/s (35 kt). Pack at e = 180 Wh/kg, k = 0.65 usable, η = 0.5 from battery to thrust. Endurance scales with 1/V at the same L/D, so at 12 m/s multiply by 1.5 and at 25 m/s by 0.72. Rows are cruise L/D with everything hanging out, which for small aircraft is usually 8 to 12, not the 20 in the airfoil plot.

| Cruise L/D | Battery 15% of mass | Battery 20% of mass | Battery 25% of mass | Battery 30% of mass | Battery 35% of mass | Battery 40% of mass |
|---|---|---|---|---|---|---|
| 5 | 15 | 20 | 25 | 30 | 35 | 40 |
| 8 | 24 | 32 | 40 | 48 | 56 | 64 |
| 10 | 30 | 40 | 50 | 60 | 70 | 80 |
| 12 | 36 | 48 | 60 | 72 | 84 | 95 |
| 15 | 45 | 60 | 75 | 89 | 104 | 119 |
| 20 | 60 | 80 | 99 | 119 | 139 | 159 |

## The universal power curve *(ch 11)*

Formula: `P / P_min = (x³ + 3/x) / 4, x = V / V_min power`

Any aircraft with a parabolic drag polar, propeller efficiency held constant. Find your minimum-power speed once, from a flight log or from the polar, then read everything else as a ratio. Best range speed is 1.32 times best endurance speed and costs 14% more power. Twice the endurance speed costs 2.4 times the power. On small aircraft minimum-power speed sits close to stall, so loiter at 1.2 to 1.3 × stall even if the curve says slower.

| V / V_min power | Power ÷ minimum | Endurance ÷ best | Drag ÷ minimum | Range ÷ best |
|---|---|---|---|---|
| 0.8 | 1.07 | 0.94 | 1.54 | 0.65 |
| 0.9 | 1.02 | 0.98 | 1.30 | 0.77 |
| 1 best endurance | 1.00 | 1.00 | 1.15 | 0.87 |
| 1.1 | 1.01 | 0.99 | 1.07 | 0.94 |
| 1.2 | 1.06 | 0.95 | 1.02 | 0.98 |
| 1.316 best range | 1.14 | 0.88 | 1.00 | 1.00 |
| 1.5 | 1.34 | 0.74 | 1.03 | 0.97 |
| 1.75 | 1.77 | 0.57 | 1.17 | 0.86 |
| 2 | 2.38 | 0.42 | 1.37 | 0.73 |
| 2.5 | 4.21 | 0.24 | 1.94 | 0.51 |
| 3 | 7.00 | 0.14 | 2.69 | 0.37 |

## Static thrust from diameter and RPM *(ch 18)*

Formula: `T = C_T ρ n² D⁴, C_T = 0.10`

Newtons, sea level. Divide by 9.8 for kilograms of thrust. C_T of 0.10 is typical for a pitch-to-diameter ratio near 0.5. Real propellers run 0.08 to 0.13, so treat this as ±30% until you have a measured number. A dash means the tip is past Mach 0.75. Thrust falls with forward speed: see the pitch-speed table.

| RPM | 8 in | 10 in | 12 in | 14 in | 16 in | 18 in | 20 in | 24 in |
|---|---|---|---|---|---|---|---|---|
| 3,000 | 0.5 | 1.3 | 2.6 | 4.9 | 8.4 | 13.4 | 20.4 | 42.3 |
| 4,000 | 0.9 | 2.3 | 4.7 | 8.7 | 14.9 | 23.8 | 36.3 | 75.2 |
| 5,000 | 1.5 | 3.5 | 7.3 | 13.6 | 23.2 | 37.2 | 56.7 | 117 |
| 6,000 | 2.1 | 5.1 | 10.6 | 19.6 | 33.4 | 53.5 | 81.6 | 169 |
| 7,000 | 2.8 | 6.9 | 14.4 | 26.7 | 45.5 | 72.9 | 111 | 230 |
| 8,000 | 3.7 | 9.1 | 18.8 | 34.8 | 59.4 | 95.2 | 145 | — |
| 9,000 | 4.7 | 11.5 | 23.8 | 44.1 | 75.2 | 120 | 184 | — |
| 10,000 | 5.8 | 14.2 | 29.4 | 54.4 | 92.8 | 149 | — | — |
| 12,000 | 8.4 | 20.4 | 42.3 | 78.4 | — | — | — | — |
| 14,000 | 11.4 | 27.8 | 57.6 | — | — | — | — | — |

## Static shaft power from diameter and RPM *(ch 18)*

Formula: `P = C_P ρ n³ D⁵, C_P = 0.045`

Watts at the shaft, sea level. Divide by about 0.85 for electrical input. Same caveats as the thrust table: C_P runs 0.03 to 0.07 across real propellers, and more pitch means more power. Read this table with the thrust table beside it: thrust per watt is what the big slow propeller buys you.

| RPM | 8 in | 10 in | 12 in | 14 in | 16 in | 18 in | 20 in | 24 in |
|---|---|---|---|---|---|---|---|---|
| 3,000 | 2 | 7 | 18 | 39 | 76 | 138 | 233 | 580 |
| 4,000 | 6 | 17 | 43 | 93 | 181 | 326 | 553 | 1,375 |
| 5,000 | 11 | 34 | 84 | 181 | 354 | 637 | 1,079 | 2,686 |
| 6,000 | 19 | 58 | 145 | 313 | 611 | 1,101 | 1,865 | 4,641 |
| 7,000 | 30 | 93 | 230 | 498 | 970 | 1,749 | 2,961 | 7,369 |
| 8,000 | 45 | 138 | 344 | 743 | 1,449 | 2,610 | 4,421 | — |
| 9,000 | 64 | 197 | 489 | 1,058 | 2,062 | 3,717 | 6,294 | — |
| 10,000 | 88 | 270 | 671 | 1,451 | 2,829 | 5,098 | — | — |
| 12,000 | 153 | 466 | 1,160 | 2,508 | — | — | — | — |
| 14,000 | 243 | 740 | 1,842 | — | — | — | — | — |

## Maximum RPM for a propeller tip speed *(ch 18)*

Formula: `RPM = 60 · M_tip · a / (π D)`

Static, speed of sound 340 m/s. Forward speed adds to the tip speed, so leave room. Below Mach 0.5 is quiet. Above about 0.7, noise climbs fast and efficiency starts to fall.

| Diameter, in | mm | RPM at Mach 0.5 | Mach 0.6 | Mach 0.7 |
|---|---|---|---|---|
| 5 | 127 | 25,588 | 30,705 | 35,823 |
| 7 | 178 | 18,277 | 21,932 | 25,588 |
| 9 | 229 | 14,215 | 17,058 | 19,901 |
| 10 | 254 | 12,794 | 15,353 | 17,911 |
| 12 | 305 | 10,662 | 12,794 | 14,926 |
| 14 | 356 | 9,138 | 10,966 | 12,794 |
| 16 | 406 | 7,996 | 9,595 | 11,195 |
| 18 | 457 | 7,108 | 8,529 | 9,951 |
| 20 | 508 | 6,397 | 7,676 | 8,956 |
| 22 | 559 | 5,815 | 6,978 | 8,142 |
| 24 | 610 | 5,331 | 6,397 | 7,463 |
| 28 | 711 | 4,569 | 5,483 | 6,397 |
| 32 | 813 | 3,998 | 4,798 | 5,597 |

## Pitch speed *(ch 18)*

Formula: `V_pitch = pitch × RPM / 60`

m/s with mph in brackets. A fixed-pitch propeller is most efficient at 80 to 100% of pitch speed and makes no useful thrust near 130%. Put cruise in the first band and check that top speed stays below the second.

| Pitch, in | 4,000 RPM | 6,000 RPM | 8,000 RPM | 10,000 RPM | 12,000 RPM | 15,000 RPM |
|---|---|---|---|---|---|---|
| 3 | 5 (11) | 8 (17) | 10 (23) | 13 (28) | 15 (34) | 19 (43) |
| 4 | 7 (15) | 10 (23) | 14 (30) | 17 (38) | 20 (45) | 25 (57) |
| 4.5 | 8 (17) | 11 (26) | 15 (34) | 19 (43) | 23 (51) | 29 (64) |
| 5 | 8 (19) | 13 (28) | 17 (38) | 21 (47) | 25 (57) | 32 (71) |
| 6 | 10 (23) | 15 (34) | 20 (45) | 25 (57) | 30 (68) | 38 (85) |
| 7 | 12 (27) | 18 (40) | 24 (53) | 30 (66) | 36 (80) | 44 (99) |
| 8 | 14 (30) | 20 (45) | 27 (61) | 34 (76) | 41 (91) | 51 (114) |
| 10 | 17 (38) | 25 (57) | 34 (76) | 42 (95) | 51 (114) | 64 (142) |
| 12 | 20 (45) | 30 (68) | 41 (91) | 51 (114) | 61 (136) | 76 (170) |

## Loaded RPM from Kv and cell count *(ch 19)*

Formula: `RPM ≈ 0.8 · K_v · (3.7 V × cells), K_t = 60 / (2π K_v)`

Nominal voltage, well-matched propeller. A full pack is 13% higher, a nearly empty one 10% lower. K_t in N·m per amp: torque is K_t times current above the no-load current. Cross-check the RPM against the tip-speed table.

| K_v, RPM/V | K_t, N·m/A | 3S | 4S | 6S | 8S | 12S | 14S |
|---|---|---|---|---|---|---|---|
| 100 | 0.095 | 888 | 1,184 | 1,776 | 2,368 | 3,552 | 4,144 |
| 150 | 0.064 | 1,332 | 1,776 | 2,664 | 3,552 | 5,328 | 6,216 |
| 200 | 0.048 | 1,776 | 2,368 | 3,552 | 4,736 | 7,104 | 8,288 |
| 300 | 0.032 | 2,664 | 3,552 | 5,328 | 7,104 | 10,656 | 12,432 |
| 400 | 0.024 | 3,552 | 4,736 | 7,104 | 9,472 | 14,208 | 16,576 |
| 500 | 0.019 | 4,440 | 5,920 | 8,880 | 11,840 | 17,760 | 20,720 |
| 700 | 0.014 | 6,216 | 8,288 | 12,432 | 16,576 | 24,864 | 29,008 |
| 900 | 0.011 | 7,992 | 10,656 | 15,984 | 21,312 | 31,968 | 37,296 |
| 1,200 | 0.008 | 10,656 | 14,208 | 21,312 | 28,416 | 42,624 | 49,728 |
| 1,500 | 0.006 | 13,320 | 17,760 | 26,640 | 35,520 | 53,280 | 62,160 |
| 2,000 | 0.005 | 17,760 | 23,680 | 35,520 | 47,360 | 71,040 | 82,880 |
| 2,500 | 0.004 | 22,200 | 29,600 | 44,400 | 59,200 | 88,800 | 103,600 |

## Pack voltage by cell count *(ch 21)*

Formula: `V_pack = cells × V_cell`

Lithium polymer and most lithium-ion cells. “Land soon” is a resting or light-load reading. “Floor under load” is where failsafes belong. Below 3.0 V per cell the pack is being damaged. High-energy cylindrical cells run lower under load: check the datasheet.

| Cells | Full, 4.2 | Storage, 3.8 | Nominal, 3.7 | Land soon, 3.5 | Floor under load, 3.3 | Damage, 3.0 |
|---|---|---|---|---|---|---|
| 1S | 4.2 | 3.8 | 3.7 | 3.5 | 3.3 | 3.0 |
| 2S | 8.4 | 7.6 | 7.4 | 7.0 | 6.6 | 6.0 |
| 3S | 12.6 | 11.4 | 11.1 | 10.5 | 9.9 | 9.0 |
| 4S | 16.8 | 15.2 | 14.8 | 14.0 | 13.2 | 12.0 |
| 5S | 21.0 | 19.0 | 18.5 | 17.5 | 16.5 | 15.0 |
| 6S | 25.2 | 22.8 | 22.2 | 21.0 | 19.8 | 18.0 |
| 8S | 33.6 | 30.4 | 29.6 | 28.0 | 26.4 | 24.0 |
| 10S | 42.0 | 38.0 | 37.0 | 35.0 | 33.0 | 30.0 |
| 12S | 50.4 | 45.6 | 44.4 | 42.0 | 39.6 | 36.0 |
| 14S | 58.8 | 53.2 | 51.8 | 49.0 | 46.2 | 42.0 |

## Wire gauge for a propulsion current *(ch 33)*

Formula: `area ≥ I ÷ 10 A/mm² in free air, ≥ I ÷ 5 A/mm² in a bundle`

Read across from the current the propulsion draws continuously, then check the drop over the real lead length against 2% of pack voltage; a long run to a wingtip motor is sized by drop, not heat. Bundled means two or more current-carrying leads inside a boom or a wrap with no airflow. Peak current of a few seconds can run one gauge smaller. Silicone-insulated stranded wire is the usual choice because it survives heat and vibration; the ratings here are for copper, and copper-clad aluminium needs two gauges larger.

| Continuous current, A | Min AWG, free air | Min AWG, bundled or in a boom | Area of the free-air gauge, mm² | Drop per meter of run, lead and return, mV | Copper per meter of run, g |
|---|---|---|---|---|---|
| 5 | 20 | 16 | 0.52 | 332 | 9 |
| 10 | 16 | 14 | 1.31 | 263 | 23 |
| 15 | 14 | 12 | 2.08 | 248 | 37 |
| 20 | 14 | 10 | 2.08 | 331 | 37 |
| 30 | 12 | 8 | 3.31 | 312 | 59 |
| 40 | 10 | 8 | 5.26 | 262 | 94 |
| 60 | 8 | 6 | 8.37 | 247 | 150 |
| 80 | 8 | 4 | 8.37 | 329 | 150 |
| 100 | 6 | 4 | 13.30 | 259 | 238 |
| 150 | 4 | 4 | 21.15 | 244 | 379 |

## Voltage drop in copper wire *(ch 76)*

Formula: `ΔV = I · R, R = 17.2 mΩ·mm²/m ÷ area`

Millivolts lost per meter of wire at each current, copper at 20 °C. Count both the lead and the return. A dash means the wire is too small for that current even briefly. The continuous column is 10 A/mm² in free air: halve it in a bundle. Hold total drop under 2% of pack voltage at peak current.

| AWG | Area, mm² | mΩ per m | Continuous, A | mV/m at 5 A | mV/m at 10 A | mV/m at 20 A | mV/m at 40 A | mV/m at 60 A | mV/m at 100 A |
|---|---|---|---|---|---|---|---|---|---|
| 8 | 8.37 | 2.1 | 84 | 10 | 21 | 41 | 82 | 123 | 206 |
| 10 | 5.26 | 3.3 | 53 | 16 | 33 | 65 | 131 | 196 | 327 |
| 12 | 3.31 | 5.2 | 33 | 26 | 52 | 104 | 208 | 312 | — |
| 14 | 2.08 | 8.3 | 21 | 41 | 83 | 165 | 331 | — | — |
| 16 | 1.31 | 13.1 | 13 | 66 | 131 | 263 | — | — | — |
| 18 | 0.82 | 20.9 | 8 | 104 | 209 | 418 | — | — | — |
| 20 | 0.52 | 33.2 | 5 | 166 | 332 | — | — | — | — |
| 22 | 0.33 | 52.8 | 3 | 264 | — | — | — | — | — |
| 24 | 0.20 | 84.0 | 2 | 420 | — | — | — | — | — |
| 26 | 0.13 | 133.6 | 1 | — | — | — | — | — | — |

## Battery energy, mass, and capacity *(ch 21)*

Formula: `m = E / e, Ah = Wh / (cells × 3.7 V)`

Nameplate watt-hours on the left. The second column is what to plan on using: 65% of nameplate after reserve, rate, temperature, and age. Mass in kilograms at three pack-level specific energies: 150 Wh/kg is a high-rate lithium polymer pack, 200 a good one, 250 a cylindrical lithium-ion pack built for energy. Capacity is in amp-hours at the cell count shown.

| Nameplate, Wh | Usable, Wh | kg at 150 Wh/kg | at 200 | at 250 | Ah at 3S | 4S | 6S | 12S |
|---|---|---|---|---|---|---|---|---|
| 10 | 6 | 0.07 | 0.05 | 0.04 | 0.9 | 0.7 | 0.5 | 0.2 |
| 25 | 16 | 0.17 | 0.12 | 0.10 | 2.3 | 1.7 | 1.1 | 0.6 |
| 50 | 32 | 0.33 | 0.25 | 0.20 | 4.5 | 3.4 | 2.3 | 1.1 |
| 100 | 65 | 0.67 | 0.50 | 0.40 | 9.0 | 6.8 | 4.5 | 2.3 |
| 150 | 98 | 1.00 | 0.75 | 0.60 | 13.5 | 10.1 | 6.8 | 3.4 |
| 200 | 130 | 1.33 | 1.00 | 0.80 | 18.0 | 13.5 | 9.0 | 4.5 |
| 300 | 195 | 2.00 | 1.50 | 1.20 | 27.0 | 20.3 | 13.5 | 6.8 |
| 500 | 325 | 3.33 | 2.50 | 2.00 | 45.0 | 33.8 | 22.5 | 11.3 |
| 1,000 | 650 | 6.67 | 5.00 | 4.00 | 90.1 | 67.6 | 45.0 | 22.5 |
| 2,000 | 1,300 | 13.3 | 10.0 | 8.00 | 180.2 | 135.1 | 90.1 | 45.0 |

## Chord Reynolds number *(ch 12)*

Formula: `Re = ρ V c / μ ≈ 68,500 · V[m/s] · c[m]`

Sea level, 15 °C, in thousands. Below about 100k expect laminar separation bubbles, lower maximum lift, and more drag than the full-scale data says. Tail surfaces and wing tips sit a row or two above the wing. Propeller blades: use the local blade speed and chord.

| Chord, mm | in | 5 m/s | 10 m/s | 15 m/s | 20 m/s | 30 m/s | 50 m/s |
|---|---|---|---|---|---|---|---|
| 30 | 1.2 | 10k | 21k | 31k | 41k | 62k | 103k |
| 50 | 2.0 | 17k | 34k | 51k | 68k | 103k | 171k |
| 75 | 3.0 | 26k | 51k | 77k | 103k | 154k | 257k |
| 100 | 3.9 | 34k | 68k | 103k | 137k | 205k | 342k |
| 150 | 5.9 | 51k | 103k | 154k | 205k | 308k | 513k |
| 200 | 7.9 | 68k | 137k | 205k | 274k | 411k | 685k |
| 300 | 11.8 | 103k | 205k | 308k | 411k | 616k | 1,027k |
| 500 | 19.7 | 171k | 342k | 513k | 685k | 1,027k | 1,711k |

## Servo torque for a control surface *(ch 16)*

Formula: `M_hinge = ½ρV² · S_c · c_c · C_h, C_h ≈ 0.012 per degree`

Kilogram-centimeters at the hinge, the unit servos are sold in, for a plain flap deflected 20° at the fastest speed the aircraft will see. Columns are surface chord × span in millimeters. This is an estimate, not physics you can trust to 10%: hinge-moment coefficients vary two to one with hinge position, gap seals, and balance area. Multiply by the horn-to-arm ratio of your linkage, then double it, and check the servo’s torque at your actual rail voltage. Speed squared: a dive is what strips gears.

| Airspeed, m/s | kt | 30 × 300 | 40 × 400 | 50 × 500 | 60 × 800 | 80 × 1000 | 100 × 1200 |
|---|---|---|---|---|---|---|---|
| 10 | 19 | 0.04 | 0.10 | 0.19 | 0.43 | 0.96 | 1.80 |
| 15 | 29 | 0.09 | 0.22 | 0.42 | 0.97 | 2.16 | 4.05 |
| 20 | 39 | 0.16 | 0.38 | 0.75 | 1.73 | 3.84 | 7.20 |
| 25 | 49 | 0.25 | 0.60 | 1.17 | 2.70 | 6.00 | 11 |
| 30 | 58 | 0.36 | 0.86 | 1.69 | 3.89 | 8.63 | 16 |
| 40 | 78 | 0.65 | 1.53 | 3.00 | 6.91 | 15 | 29 |
| 60 | 117 | 1.46 | 3.45 | 6.75 | 16 | 35 | 65 |

## Wing root bending moment at 1 g *(ch 25)*

Formula: `M_root = n · m g · b · (1/3π) ≈ 0.106 n m g b`

Newton-meters on one wing panel, elliptical lift, which puts each half-wing’s lift at 42% of the semi-span. Multiply by your limit load factor n, typically 3 to 6, then by a factor of safety of 1.5 or more. Wing weight and anything else carried outboard relieves the moment, so this is the conservative end. Then go to the tube table.

| Mass, kg | lb | 1 m span | 1.5 m span | 2 m span | 3 m span | 4 m span | 6 m span |
|---|---|---|---|---|---|---|---|
| 1 | 2 | 1.0 | 1.6 | 2.1 | 3.1 | 4.2 | 6.2 |
| 2 | 4 | 2.1 | 3.1 | 4.2 | 6.2 | 8.3 | 12.5 |
| 3 | 7 | 3.1 | 4.7 | 6.2 | 9.4 | 12.5 | 18.7 |
| 5 | 11 | 5.2 | 7.8 | 10.4 | 15.6 | 20.8 | 31.2 |
| 7.5 | 17 | 7.8 | 11.7 | 15.6 | 23.4 | 31.2 | 46.8 |
| 10 | 22 | 10.4 | 15.6 | 20.8 | 31.2 | 41.6 | 62.4 |
| 15 | 33 | 15.6 | 23.4 | 31.2 | 46.8 | 62.4 | 93.6 |
| 25 | 55 | 26.0 | 39.0 | 52.0 | 78.0 | 104 | 156 |
| 50 | 110 | 52.0 | 78.0 | 104 | 156 | 208 | 312 |
| 100 | 220 | 104 | 156 | 208 | 312 | 416 | 624 |

## Round tube sections *(ch 25)*

Formula: `I = π (D⁴ − d⁴) / 64, Z = I / (D/2), M = σ Z`

Geometry is exact. Mass per meter assumes pultruded carbon at 1.55 g/cm³: for aluminum multiply by 1.75. The moment column is what the tube carries at a working stress of 300 MPa, a cautious figure for pultruded carbon in bending that leaves room for the hole you will drill in it: scale it to your own allowable. EI uses 110 GPa. Thin walls buckle and crush at the joiner before they reach this: sleeve the root.

| OD × ID, mm | Wall, mm | Area, mm² | g per m | I, mm⁴ | Z, mm³ | M at 300 MPa, N·m | EI, N·m² |
|---|---|---|---|---|---|---|---|
| 4 × 3 | 0.5 | 5.5 | 8.5 | 9 | 4.3 | 1.3 | 0.9 |
| 5 × 3 | 1 | 12.6 | 19.5 | 27 | 10.7 | 3.2 | 2.9 |
| 6 × 4 | 1 | 15.7 | 24.3 | 51 | 17.0 | 5.1 | 5.6 |
| 8 × 6 | 1 | 22.0 | 34.1 | 137 | 34.4 | 10.3 | 15.1 |
| 10 × 8 | 1 | 28.3 | 43.8 | 290 | 58.0 | 17.4 | 31.9 |
| 12 × 10 | 1 | 34.6 | 53.6 | 527 | 87.8 | 26.4 | 58.0 |
| 14 × 12 | 1 | 40.8 | 63.3 | 868 | 124 | 37.2 | 95.5 |
| 16 × 14 | 1 | 47.1 | 73.0 | 1,331 | 166 | 49.9 | 146 |
| 20 × 18 | 1 | 59.7 | 92.5 | 2,701 | 270 | 81.0 | 297 |
| 25 × 23 | 1 | 75.4 | 117 | 5,438 | 435 | 131 | 598 |
| 30 × 27 | 1.5 | 134 | 208 | 13,674 | 912 | 273 | 1,504 |
| 40 × 37 | 1.5 | 181 | 281 | 33,666 | 1,683 | 505 | 3,703 |

## Launcher acceleration *(ch 38)*

Formula: `a = V² / (2 s)`

Average acceleration in g to reach the exit speed over the powered length of the rail. A bungee peaks at two or more times its average. Everything on the aircraft that is not bolted down sees this load, aft.

| Exit speed, m/s | kt | 1 m rail | 2 m rail | 3 m rail | 4 m rail | 6 m rail |
|---|---|---|---|---|---|---|
| 8 | 16 | 3.3 | 1.6 | 1.1 | 0.8 | 0.5 |
| 10 | 19 | 5.1 | 2.5 | 1.7 | 1.3 | 0.8 |
| 12 | 23 | 7.3 | 3.7 | 2.4 | 1.8 | 1.2 |
| 15 | 29 | 11.5 | 5.7 | 3.8 | 2.9 | 1.9 |
| 20 | 39 | 20.4 | 10.2 | 6.8 | 5.1 | 3.4 |
| 25 | 49 | 31.9 | 15.9 | 10.6 | 8.0 | 5.3 |
| 30 | 58 | 45.9 | 22.9 | 15.3 | 11.5 | 7.6 |

## Parachute size and landing energy *(ch 40)*

Formula: `S/m = 2g / (ρ C_D V²), h = V² / (2g)`

Canopy area per kilogram of aircraft for a steady descent rate, with C_D = 0.75 on projected area. Drop height is the fall that hits the ground at the same speed: a quick way to decide what the airframe must survive. Drift is wind speed times descent time.

| Descent, m/s | ft/s | m² per kg, sea level | m² per kg, 2,000 m | Canopy dia. for 5 kg, m | Equivalent drop, m |
|---|---|---|---|---|---|
| 3 | 10 | 2.37 | 2.89 | 3.9 | 0.5 |
| 4 | 13 | 1.33 | 1.62 | 2.9 | 0.8 |
| 5 | 16 | 0.85 | 1.04 | 2.3 | 1.3 |
| 6 | 20 | 0.59 | 0.72 | 1.9 | 1.8 |
| 7 | 23 | 0.44 | 0.53 | 1.7 | 2.5 |
| 8 | 26 | 0.33 | 0.41 | 1.5 | 3.3 |

## Ground sample distance *(ch 34)*

Formula: `GSD = H · (pixel pitch / focal length), μm ÷ mm = mrad`

Centimetres on the ground per pixel, looking straight down. The column heading is pixel pitch in micrometres divided by focal length in millimeters: a 2.4 μm sensor behind an 8.8 mm lens is 0.27 mrad, a 3.8 μm sensor behind a 35 mm lens is 0.11. To recognize an object you want roughly ten pixels across it, so divide its size by ten and find the altitude. Slant range stretches everything: use the distance to the target, not the height.

| Height or range, m | ft | 0.05 mrad | 0.1 mrad | 0.2 mrad | 0.3 mrad | 0.5 mrad | 1 mrad |
|---|---|---|---|---|---|---|---|
| 30 | 98 | 0.1 | 0.3 | 0.6 | 0.9 | 1.5 | 3.0 |
| 60 | 197 | 0.3 | 0.6 | 1.2 | 1.8 | 3.0 | 6.0 |
| 120 | 394 | 0.6 | 1.2 | 2.4 | 3.6 | 6.0 | 12.0 |
| 200 | 656 | 1.0 | 2.0 | 4.0 | 6.0 | 10.0 | 20.0 |
| 400 | 1,312 | 2.0 | 4.0 | 8.0 | 12.0 | 20.0 | 40.0 |
| 800 | 2,625 | 4.0 | 8.0 | 16.0 | 24.0 | 40.0 | 80.0 |
| 1,500 | 4,921 | 7.5 | 15.0 | 30.0 | 45.0 | 75.0 | 150 |
| 3,000 | 9,843 | 15.0 | 30.0 | 60.0 | 90.0 | 150 | 300 |

## Compass error from a current-carrying lead *(ch 31)*

Formula: `B = 0.2 · I / r [µT, A, m], error = atan(B / 20 µT)`

Heading error in degrees at each distance from a single lead, worst orientation, against a 20 µT horizontal field. The last column is a twisted supply-and-return pair 5 mm apart at 40 A, which falls with the square of distance. Use the climb current on a multirotor, because the lift current is what moves the heading. The 10 to 15 cm rule assumes the pair is twisted; a single lead needs the compass on a mast.

| Distance, cm | 5 A lead | 10 A lead | 20 A lead | 40 A lead | 60 A lead | 100 A lead | 40 A twisted pair |
|---|---|---|---|---|---|---|---|
| 2 | over 45° | over 45° | over 45° | over 45° | over 45° | over 45° | 78.7° |
| 3 | over 45° | over 45° | over 45° | over 45° | over 45° | over 45° | 65.8° |
| 5 | over 45° | over 45° | over 45° | over 45° | over 45° | over 45° | 38.7° |
| 8 | 32° | over 45° | over 45° | over 45° | over 45° | over 45° | 17.4° |
| 10 | 27° | over 45° | over 45° | over 45° | over 45° | over 45° | 11.3° |
| 15 | 18° | 34° | over 45° | over 45° | over 45° | over 45° | 5.1° |
| 20 | 14° | 27° | over 45° | over 45° | over 45° | over 45° | 2.9° |
| 30 | 9° | 18° | 34° | over 45° | over 45° | over 45° | 1.3° |

## RPM from the tone you hear *(ch 59)*

Formula: `RPM = 60 · f / blades`

Find the lowest strong line on a phone spectrum app. That is blade-pass frequency. A line below it at RPM ÷ 60 means one blade is different from the others. Two propellers beating: pulses per second = blades × RPM difference ÷ 60.

| Tone, Hz | 2 blades | 3 blades | 4 blades | 5 blades |
|---|---|---|---|---|
| 40 | 1,200 | 800 | 600 | 480 |
| 50 | 1,500 | 1,000 | 750 | 600 |
| 60 | 1,800 | 1,200 | 900 | 720 |
| 80 | 2,400 | 1,600 | 1,200 | 960 |
| 100 | 3,000 | 2,000 | 1,500 | 1,200 |
| 120 | 3,600 | 2,400 | 1,800 | 1,440 |
| 150 | 4,500 | 3,000 | 2,250 | 1,800 |
| 200 | 6,000 | 4,000 | 3,000 | 2,400 |
| 250 | 7,500 | 5,000 | 3,750 | 3,000 |
| 300 | 9,000 | 6,000 | 4,500 | 3,600 |
| 400 | 12,000 | 8,000 | 6,000 | 4,800 |
| 500 | 15,000 | 10,000 | 7,500 | 6,000 |
| 600 | 18,000 | 12,000 | 9,000 | 7,200 |
| 800 | 24,000 | 16,000 | 12,000 | 9,600 |

## Site factor: what height and heat do to you *(ch 43)*

Formula: `factor = 1 / √σ, σ = ρ / ρ₀`

Multiply sea-level stall speed, launch speed, and hover power by this factor. Rows are site elevation, columns are the air temperature on the day. Maximum thrust from a given propeller and RPM falls by σ, which is 1 ÷ factor². At 1.10, you need 10% more speed off the launcher and 10% more hover power, with about 17% less thrust available.

| Elevation, m | ft | -10 °C | 0 °C | 15 °C | 30 °C | 40 °C |
|---|---|---|---|---|---|---|
| 0 | 0 | 0.96 | 0.97 | 1.00 | 1.03 | 1.04 |
| 500 | 1,640 | 0.98 | 1.00 | 1.03 | 1.06 | 1.07 |
| 1,000 | 3,281 | 1.01 | 1.03 | 1.06 | 1.09 | 1.11 |
| 1,500 | 4,921 | 1.05 | 1.07 | 1.09 | 1.12 | 1.14 |
| 2,000 | 6,562 | 1.08 | 1.10 | 1.13 | 1.16 | 1.18 |
| 2,500 | 8,202 | 1.11 | 1.13 | 1.16 | 1.19 | 1.21 |
| 3,000 | 9,843 | 1.15 | 1.17 | 1.20 | 1.23 | 1.25 |
| 4,000 | 13,123 | 1.23 | 1.25 | 1.28 | 1.32 | 1.34 |

## Turn radius, load factor, and stall margin *(ch 11)*

Formula: `R = V² / (g tan φ), n = 1 / cos φ, V_s,turn = V_s √n`

Level coordinated turn, radius in meters at each true airspeed. The third column is what the turn does to stall speed. An autopilot loitering at 1.2 × stall has no margin left at 45° of bank. Wind stretches the ground track downwind and tightens it upwind: the bank angle the autopilot needs on the downwind side is the one to check.

| Bank | Load factor n | Stall speed × | R at 10 m/s | R at 15 m/s | R at 20 m/s | R at 30 m/s | R at 40 m/s |
|---|---|---|---|---|---|---|---|
| 10° | 1.02 | 1.01 | 58 | 130 | 231 | 520 | 925 |
| 20° | 1.06 | 1.03 | 28 | 63 | 112 | 252 | 448 |
| 30° | 1.15 | 1.07 | 18 | 40 | 71 | 159 | 283 |
| 40° | 1.31 | 1.14 | 12 | 27 | 49 | 109 | 194 |
| 45° | 1.41 | 1.19 | 10 | 23 | 41 | 92 | 163 |
| 50° | 1.56 | 1.25 | 9 | 19 | 34 | 77 | 137 |
| 60° | 2.00 | 1.41 | 6 | 13 | 24 | 53 | 94 |
| 70° | 2.92 | 1.71 | 4 | 8 | 15 | 33 | 59 |

## What wind does to a mission *(ch 43)*

Formula: `out-and-back range factor = 1 − (w/V)², crab = asin(w/V)`

w/V is wind speed divided by true airspeed. Groundspeed columns are fractions of airspeed flying straight into and straight with the wind. The range factor is for a there-and-back leg along the wind: the time lost upwind is never won back downwind. Crab angle and along-track speed are for a pure crosswind. Above 0.5 the aircraft spends most of the flight going upwind, and a lost-link return from downwind may not make it home.

| w / V | Groundspeed upwind | Downwind | Out-and-back range | Crab in crosswind | Along-track speed |
|---|---|---|---|---|---|
| 0.1 | 0.90 | 1.10 | 0.99 | 6° | 0.99 |
| 0.2 | 0.80 | 1.20 | 0.96 | 12° | 0.98 |
| 0.3 | 0.70 | 1.30 | 0.91 | 17° | 0.95 |
| 0.4 | 0.60 | 1.40 | 0.84 | 24° | 0.92 |
| 0.5 | 0.50 | 1.50 | 0.75 | 30° | 0.87 |
| 0.6 | 0.40 | 1.60 | 0.64 | 37° | 0.80 |
| 0.7 | 0.30 | 1.70 | 0.51 | 44° | 0.71 |
| 0.8 | 0.20 | 1.80 | 0.36 | 53° | 0.60 |

## Free-space path loss *(ch 32)*

Formula: `L = 20 log d_km + 20 log f_MHz + 32.4 dB`

Decibels lost between two antennas in clear line of sight. Link margin = transmit power + both antenna gains − this loss − cable and installation losses − receiver sensitivity, all in dB and dBm. Keep 10 to 20 dB in hand for airframe shadowing, polarization, and multipath. Every 6 dB of margin doubles the range. Every doubling of frequency costs 6 dB.

| Distance, km | miles | 433 MHz | 915 MHz | 1,300 MHz | 2,400 MHz | 5,800 MHz |
|---|---|---|---|---|---|---|
| 0.1 | 0.062 | 65 | 72 | 75 | 80 | 88 |
| 0.2 | 0.12 | 71 | 78 | 81 | 86 | 94 |
| 0.5 | 0.31 | 79 | 86 | 89 | 94 | 102 |
| 1 | 0.62 | 85 | 92 | 95 | 100 | 108 |
| 2 | 1.2 | 91 | 98 | 101 | 106 | 114 |
| 5 | 3.1 | 99 | 106 | 109 | 114 | 122 |
| 10 | 6.2 | 105 | 112 | 115 | 120 | 128 |
| 20 | 12 | 111 | 118 | 121 | 126 | 134 |
| 50 | 31 | 119 | 126 | 129 | 134 | 142 |
| 100 | 62 | 125 | 132 | 135 | 140 | 148 |

## Range from a link budget *(ch 32)*

Formula: `budget = P_tx + G_tx + G_rx − losses − sensitivity − margin (dB)`

Kilometres of clear line of sight at which the budget is used up. Build the budget in the left column from the datasheets: transmit power in dBm, plus both antenna gains in dBi, minus cable and installation losses, minus receiver sensitivity in dBm (a negative number, so it adds), minus the fade margin you want to keep, usually 10 to 20 dB. Example: 27 dBm + 2 + 5 − 3 − (−105) − 15 = 121 dB. Then check the radio horizon table: whichever is shorter wins.

| Budget, dB | 433 MHz | 915 MHz | 1,300 MHz | 2,400 MHz | 5,800 MHz |
|---|---|---|---|---|---|
| 90 | 1.7 | 0.83 | 0.58 | 0.31 | 0.13 |
| 95 | 3.1 | 1.5 | 1.0 | 0.56 | 0.23 |
| 100 | 5.5 | 2.6 | 1.8 | 0.99 | 0.41 |
| 105 | 9.8 | 4.6 | 3.3 | 1.8 | 0.73 |
| 110 | 17.4 | 8.3 | 5.8 | 3.1 | 1.3 |
| 115 | 31.0 | 14.7 | 10.3 | 5.6 | 2.3 |
| 120 | 55.1 | 26.1 | 18.4 | 9.9 | 4.1 |
| 125 | 98.1 | 46.4 | 32.7 | 17.7 | 7.3 |
| 130 | 174 | 82.5 | 58.1 | 31.5 | 13.0 |
| 140 | 551 | 261 | 184 | 99.5 | 41.2 |

## Radio line of sight *(ch 32)*

Formula: `d_km ≈ 4.12 ( √h_aircraft + √h_antenna ), heights in m`

Kilometres to the radio horizon over flat ground or water with standard refraction. Terrain, trees, and buildings cut this hard: at low altitude the ridge between you and the aircraft is the limit, not the curve of the earth. Raising the ground antenna from 2 m to 10 m is the cheapest range you will ever buy.

| Aircraft height, m | ft | Antenna at 2 m | Antenna at 5 m | Antenna at 10 m | Antenna at 30 m |
|---|---|---|---|---|---|
| 30 | 98 | 28 | 32 | 36 | 45 |
| 60 | 197 | 38 | 41 | 45 | 54 |
| 120 | 394 | 51 | 54 | 58 | 68 |
| 200 | 656 | 64 | 67 | 71 | 81 |
| 400 | 1,312 | 88 | 92 | 95 | 105 |
| 600 | 1,969 | 107 | 110 | 114 | 123 |
| 1,000 | 3,281 | 136 | 139 | 143 | 153 |
| 2,000 | 6,562 | 190 | 193 | 197 | 207 |
| 3,000 | 9,843 | 231 | 235 | 239 | 248 |
