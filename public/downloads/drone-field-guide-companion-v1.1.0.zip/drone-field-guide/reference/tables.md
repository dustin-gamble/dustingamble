# Tables from the chapters

Typical values, class ranges, and comparisons. "Typical" means round numbers from practice, not measured data.

## Chapter 1 · A field guide to drone configurations
*Configuration families at a glance. Judgments are typical for small UAS, 0.25 to 150 kg.*

| Family | Good at | What it pays | How to recognize it |
|---|---|---|---|
| Conventional fixed wing | Endurance and range per dollar. Wide CG range, forgiving handling, easy to modify. | Needs a launch and a recovery. The tail boom makes it long to pack. | Wing, tail on a boom or fuselage, one prop on the nose or behind a pod. |
| Flying wing | Few parts, compact, tough in a belly landing, clear nose. | Narrow CG range. Lower maximum lift, so more area or a faster launch. Thin pitch damping. | Swept planform, no horizontal tail, winglets or tip fins, elevons, pusher prop. |
| Multirotor | Hover, precise positioning, simple mechanics, launch from anywhere. | Short endurance, slow, no glide, struggles in wind for its size. | Four to eight open props on arms, no wing. High, busy sound. |
| Single-rotor helicopter | Best hover efficiency. Better forward flight than a multirotor. | Swashplate, tail rotor, vibration, maintenance, one large dangerous rotor. | One big disk, tail boom with a small rotor. |
| Coaxial rotorcraft | Compact for its disk area. No tail rotor. Packs into a tube or a backpack. | Complex rotor head, or weak yaw authority without one. Tall mast. | Two stacked counter-rotating rotors on one axis, short body. |
| Tailsitter | VTOL with one propulsion system and few moving parts. | The wing is a sail in a windy hover. Transition is a control problem. Props are a compromise between hover and cruise. | Sits on its tail. Props on the wing leading edge, landing legs on fins or tips. |
| Tiltrotor, tiltwing | VTOL with efficient cruise. All the thrust works in both modes. | Tilt mechanisms, actuators, and a control law for every angle in between. | Nacelles or the whole wing pivot. Props point up on the ground. |
| Lift + cruise | VTOL added to a known airplane. Simple control, fast to develop. | The lift system is dead mass and drag for the whole cruise. | A normal airplane with booms under the wing carrying four or more fixed upward props, plus a pusher. |
| Ducted fan | Protected blades, compact, high static thrust for its diameter. | Heavy duct, poor cruise efficiency, touchy in gusts and crosswind, loud. | Shrouded rotor, control vanes in the exit flow. |
| Tube-launched | Stores and ships as a round. Launches from a vehicle, an aircraft, or a shoulder. | Folding wings and tails, small wing area, high wing loading, hard packaging limits on everything. | Slender cylindrical body, narrow wings that pivot or unfold, often tandem, folding pusher prop. |
| Lighter-than-air | Endurance of hours to days on almost no power. Quiet. | Huge volume, slow, weak against wind, gas logistics. Helium lifts about 1 kg per m³ at sea level. | Envelope far bigger than the payload. Small props or none. |


## Chapter 2 · Read the airframe
*Visible features and what they suggest. None of these is proof on its own.*

| What you see | What it suggests | What it cannot tell you |
|---|---|---|
| Tractor prop on the nose | Propulsion efficiency and simple CG came first. Sensor looks down or sideways, not forward. | Motor power or prop pitch. |
| Pusher behind a pod or on the tail | Forward-looking payload. Prop clear of a hand launch or a net. Noisier, because the prop works in the wake. | Whether the wake costs much thrust. |
| Folding prop | Belly landing, tube launch, or long power-off glides. | RPM or duty cycle. |
| Large prop relative to span | Slow-turning, efficient, quiet. Often a long-endurance aircraft. | Gearing or motor Kv. |
| No landing gear, skid or belly pan | Hand, bungee, or catapult launch. Belly, net, deep-stall, or parachute recovery. | Which recovery, unless you find a hatch or a hook. |
| Hook on a wingtip or nose | Line or rope capture. Structure sized for a hard snatch load. | Capture speed. |
| Tall gear, large wheels | Rough strips, prop clearance, heavier class. | Takeoff distance. |
| Bulge or dome on top | Satellite link, so beyond-line-of-sight operation. | Data rate or band. |
| Blade or whip antennas underneath | Line-of-sight link to a ground station. Count them to count radios. | Range. |
| Gimbal ball | Surveillance payload. Ball diameter sets the payload class and much of the drag. | Sensor quality. |
| Pitot probe out on a wing | Designer kept it out of the prop wash. Airspeed matters to this autopilot. | Whether it is calibrated. |


## Chapter 3 · Mission drives configuration
*Mission drivers and where they push. “First number” is the estimate to make before sketching.*

| Driver | Question to ask | Pushes toward | First number |
|---|---|---|---|
| Endurance, range, speed | How far, how long, and how soon must it arrive? In what wind? | High aspect ratio fixed wing. Large energy fraction. Fuel or hybrid power beyond a few hours. Cruise at least twice the wind you must work in. | Equation 3.1 with a pessimistic L/D. |
| Hover and payload | Must it truly stop in the air, or will an orbit do? How heavy is the payload and where must it look? | Rotors if hover dominates. Hybrid VTOL if hover is only the launch and recovery. Payload gets the nose or the belly. | Hover minutes from Equation 3.2. |
| Launch and recovery | From what: a hand, a vehicle, a ship, a tube, a clearing? How many people and how much kit? | Low wing loading for hand launch. Structure sized for catapult and capture loads. Folding surfaces for tubes. VTOL when there is no room. | Stall speed against launch speed. |
| Signature and environment | Who should not hear or see it? Heat, altitude, rain, salt, dust? | Large slow props, electric power, small size, altitude. Sealed bays and margin on hot, high days. | Tip speed. Density on the worst day. |
| Cost, loss tolerance, quantity | What does one loss cost you? How many will be built? | Simple structure and bought parts. No recovery system at all if it flies one way. Molded parts when the quantity pays for tooling. | Cost per mission, not cost per aircraft. |


## Chapter 4 · Units, scaling, and quick estimates
*What a 10% increase does, other things held fixed*

| Change +10% | Effect | Why |
|---|---|---|
| Mass | Stall speed +5% | V_s ∝ √(W/S) |
| Mass | Hover power, and cruise power at the same C_L, +15% | P ∝ W^1.5 |
| Rotor diameter | Ideal hover power −9% | P ∝ 1/D |
| Airspeed | Drag +21% (fixed C_D) | D ∝ V² |
| Airspeed | Power to overcome that drag +33% | P ∝ V³ |
| Chord or airspeed | Reynolds number +10% | Re ∝ V c |


*Conversions worth memorizing*

| Quantity | SI | US customary |
|---|---|---|
| Mass | 1 kg | 2.205 lb |
| Force | 1 kg weighs 9.81 N | 1 lbf = 4.448 N |
| Speed | 1 m/s | 2.237 mph = 1.944 kt |
| Wing or disk loading (mass basis) | 1 kg/m² | 3.28 oz/ft² = 0.205 lb/ft² |
| Pressure or loading (force basis) | 1 N/m² | 0.0209 lb/ft² |
| Power | 746 W | 1 hp |
| Battery energy | Wh = Ah × V | same |


## Chapter 5 · Weight and mass properties
*Typical mass fractions of gross mass. Round values for first sizing.*

| Class | Empty | Battery or fuel | Payload |
|---|---|---|---|
| Small electric fixed-wing, long endurance | 0.45–0.60 | 0.25–0.40 | 0.10–0.20 |
| Camera or survey multirotor | 0.45–0.60 | 0.25–0.40 | 0.10–0.25 |
| Heavy-lift multirotor | 0.35–0.50 | 0.20–0.30 | 0.30–0.45 |
| Electric VTOL fixed-wing with separate lift motors | 0.55–0.65 | 0.25–0.35 | 0.05–0.15 |
| Small piston-engine fixed-wing | 0.50–0.65 | 0.15–0.30 | 0.10–0.25 |


## Chapter 6 · Wing loading
*One change at a time from the 5.0 kg baseline*

| Change | V_s | Difference |
|---|---|---|
| Baseline | 9.13 m/s (20.4 mph) |  |
| Mass to 6.0 kg | 10.00 m/s (22.4 mph) | +9.5% |
| Area to 1.00 m² | 8.17 m/s (18.3 mph) | −10.6% |
| Density to 1.00 kg/m³, about 2,000 m (6,600 ft) | 10.11 m/s (22.6 mph) | +10.7% |
| C_L,max to 1.00 | 10.00 m/s (22.4 mph) | +9.5% |


*Wing loading across scales. Approximate, from published mass and wing area unless noted.*

| Aircraft | kg/m² | US units | How it gets airborne |
|---|---|---|---|
| Discus-launch glider, 1.5 m class (typical) | 1.2–1.5 | 4–5 oz/ft² | Thrown by a wingtip |
| RQ-11 Raven (estimate from published mass and span) | about 6 | about 19 oz/ft² | Hand launch |
| RQ-20 Puma (estimate from published mass and span) | about 8 | about 26 oz/ft² | Hand launch, a firm one |
| Standard-class sailplane | 30–50 | 6–10 lb/ft² | Tow or winch |
| Cessna 172 | about 70 | about 14 lb/ft² | Runway |
| MQ-1 Predator | about 90 | about 18 lb/ft² | Runway |
| Boeing 747-400 | about 730 | about 150 lb/ft² | Long runway, large flaps |


## Chapter 7 · Disk loading
*Hovering options by disk loading. Typical, order-of-magnitude values at sea level.*

| Type | Disk loading, N/m² (lb/ft²) | Ideal W/kg | Wake, m/s | What you buy |
|---|---|---|---|---|
| Multirotor | 50–250 (1–5) | 45–100 | 9–20 | Simple, cheap, fixed pitch |
| Helicopter | 150–700 (3–15) | 75–165 | 16–34 | Most disk per footprint, mechanical complexity |
| Tiltrotor | 700–1,300 (15–27) | 165–225 | 34–46 | Rotor sized as a compromise with cruise |
| Ducted fan, EDF lift | 2,000–10,000 (40–210) | 280–630 | 57–130 | Compact and enclosed, short hover only |
| Jet lift | 30,000 and up (600+) | 1,000+ | 200+ | Packaging and speed, hover measured in seconds or minutes |


## Chapter 8 · Power loading and thrust-to-weight
*Typical static thrust-to-weight and installed electrical power. Round values.*

| Class | Static T/W | Installed W/kg (W/lb) | What sets it |
|---|---|---|---|
| Efficient fixed-wing, catapult or runway | 0.3–0.5 | 80–150 (35–70) | Climb rate after launch |
| Hand-launched fixed-wing | 0.5–0.8 | 120–200 (55–90) | The first three seconds |
| Heavy-lift multirotor | 1.8–2.0 | 250–400 (115–180) | Yaw authority at maximum weight |
| Camera or survey multirotor | 2.0–2.5 | 300–500 (135–225) | Control margin and gusts |
| VTOL fixed-wing in hover (4+1) | 1.3–1.8 | 250–450 (115–205) | Short hovers, yaw from the tail; 1.3 is enough in calm air |
| Racing or acrobatic multirotor | 5–10 and up | 1,000 and up (450+) | Acceleration |


*Hover margins: multirotor against 4+1 VTOL*

|  | Multirotor | 4+1 VTOL |
|---|---|---|
| T/W at the worst moment | 2 | 1.3 in calm air, 1.5 with crosswind |
| Hover point, fraction of maximum thrust | 50% | 77% at T/W 1.3 |
| Where yaw comes from | Torque difference between the rotor sets | Rudder and cruise propeller |


## Chapter 9 · Energy and endurance
*Energy sources for small aircraft. Round, typical values at pack or system level.*

| Source | Specific energy, Wh/kg | What comes with it |
|---|---|---|
| LiPo pouch pack | 130–200 | High power, simple, the default for multirotors and short flights |
| Li-ion cylindrical pack (18650, 21700) | 200–260 | More energy, less power. Size the pack so cruise and climb stay within the cell rating |
| Gasoline, chemical | about 12,000 | Before the engine takes its share |
| Gasoline at the shaft, small engine | 1,500–3,000 | Add engine mass, vibration, and maintenance. Fuel burns off in flight |
| Hydrogen fuel-cell system, tank included | 400–800 | Low specific power, needs a buffer battery, fuel logistics |


## Chapter 10 · Stability and center of gravity
*Typical ranges for small fixed-wing aircraft. Round values for a first layout.*

| Quantity | Typical range | Notes |
|---|---|---|
| Static margin, conventional tail | 5–15% MAC | Start first flights near 10%, then move aft in small steps if needed |
| Static margin, flying wing | 5–12% MAC | Little pitch damping and limited trim power, so the usable band is narrow |
| Horizontal tail volume, V_H | 0.40–0.70 | Higher for flaps, a wide CG range, or a short tail arm |
| Vertical tail volume, V_V | 0.02–0.05 | Higher for a large fuselage or pod ahead of the CG |
| V-tail | Same coefficients | Apply them to the projected horizontal and vertical areas |


## Chapter 11 · Speed and maneuvering
*Level turns. Load factor and stall speed factor depend only on bank angle. Radius is shown for two airspeeds.*

| Bank angle | Load factor n | Stall speed factor √n | Radius at 15 m/s (34 mph) | Radius at 25 m/s (56 mph) |
|---|---|---|---|---|
| 15° | 1.04 | 1.02 | 86 m | 238 m |
| 30° | 1.15 | 1.07 | 40 m | 110 m |
| 45° | 1.41 | 1.19 | 23 m | 64 m |
| 60° | 2.00 | 1.41 | 13 m | 37 m |
| 70° | 2.92 | 1.71 | 8 m | 23 m |


## Chapter 12 · Lift
*What changes across the small-UAS Reynolds number range. Typical values for plain, unflapped sections.*

| Chord Re | What the flow does | Section c_l,max | Minimum section c_d | What to do about it |
|---|---|---|---|---|
| Below 70,000 | Laminar separation, often no reattachment. Hysteresis at stall. | 0.7 to 1.0 | 0.02 to 0.04 | Thin, cambered sections. Turbulators. Test, do not compute. |
| 70,000 to 300,000 | Separation bubble that reattaches. Sensitive to surface and turbulence. | 1.0 to 1.3 | 0.012 to 0.020 | Use airfoils designed and tunnel-tested in this range. |
| 300,000 to 1,000,000 | Short bubbles. Behavior approaches full scale. | 1.2 to 1.5 | 0.008 to 0.012 | Conventional sections start to work. Check the tip and tail Re. |
| Above 1,000,000 | Transition occurs without a significant bubble. | 1.4 to 1.6 | 0.006 to 0.009 | Classic NACA data applies. |


## Chapter 13 · Drag
*Bluff-body drag coefficients on frontal area at small-UAS Reynolds numbers. Typical values.*

| Item | C_D on frontal area | Note |
|---|---|---|
| Round tube, wire, whip antenna | 1.0 to 1.2 | Handbooks quote about 0.3 for round struts, but that is above critical Re. |
| Streamlined strut or fairing, thickness 25 to 35% of chord | 0.1 to 0.2 | Five to ten times better than the tube it covers. |
| Ball turret or dome, fully exposed | 0.4 to 0.5 | Half-buried is roughly half. |
| Flat face, box, bracket, servo horn with clevis | 1.0 to 1.3 | Treat any small bracket as a flat plate of its frontal area. |
| Unfaired wheel | 0.25 to 0.5 | The leg and axle hardware usually cost more than the wheel. |


*Illustrative parasite drag build-up, 5 kg fixed-wing UAS. Typical values, not measured data.*

| Component | Basis | Drag area, cm² | Share |
|---|---|---|---|
| Wing | Section c_d 0.011 × 0.80 m² | 88 | 37% |
| Tail surfaces | c_d 0.013 × 0.14 m² | 18 | 8% |
| Fuselage pod and boom | 0.30 m² wetted × C_f 0.0065 × form factor 1.35 | 26 | 11% |
| Gimbal ball, 100 mm | C_D 0.47 × 78.5 cm² frontal | 37 | 15% |
| Two whip antennas, 5 mm × 120 mm | C_D 1.2 × 6 cm² each | 14 | 6% |
| Four servo horns with pushrods | C_D 1.0 × 2 cm² each | 8 | 3% |
| Pitot mast, hatch edges, gaps, fasteners | Allowance | 12 | 5% |
| Cooling flow | Allowance | 12 | 5% |
| Interference and the things you forgot | About 10% of total | 25 | 10% |
| Total | C_D0 = 0.030 on 0.80 m² | 240 | 100% |


## Chapter 14 · Airfoils
*Airfoil data sources, in order of trust for small UAS*

| Source | Good for | Limits |
|---|---|---|
| Low-turbulence wind tunnel tests at your Re (UIUC low-speed airfoil tests and similar) | Absolute drag, c_l,max, stall character | Tested on accurate models. Yours will be worse. |
| XFOIL at your Re | Ranking candidates, finding the bubble, moment coefficient | Tends to be optimistic on c_l,max. Unreliable below about Re 100,000. Results move with assumed turbulence. |
| Classic NACA section data | Aircraft above Re 1,000,000 | Taken at Re 3 to 9 million. Do not use it at hand-launch scale. |


*Starting points by use. Thickness values approximate, published.*

| Use | Look for | Well-known examples |
|---|---|---|
| General wing, Re 150,000 to 500,000 | 9 to 12% thick, 2.5 to 4% camber, tested at low Re | SD7037 (about 9%), E387 (about 9%), Clark Y (about 12%, flat-bottomed, easy to build) |
| Thicker wing for spar depth or payload-heavy aircraft | 12 to 14%, low-Re design | SD7062 (about 14%) |
| Maximum lift at low speed, speed range unimportant | High camber, aft loading | S1223 (about 12%). Strong nose-down moment. Thin, cusped trailing edge is hard to build. |
| Flying wing | Reflexed, near-zero moment | MH 45 and related MH sections (about 10%) |
| Above Re 500,000 | Conventional sections work | NACA 2412, 4412, 4415 |
| Tails | Symmetric, 8 to 10%. Flat plate is acceptable on very small aircraft. | NACA 0009, NACA 0010 |


## Chapter 15 · Wings
*Planform choices for small UAS wings. Typical effects.*

| Choice | What it buys | What it costs |
|---|---|---|
| No taper (taper ratio 1.0) | One rib or one mold section. Root stalls first. Highest tip Reynolds number. | A few percent more induced drag. More root bending moment and wing mass. |
| Moderate taper, 0.5 to 0.7 | Near-elliptical loading. Less bending moment. Deep root for the spar. | Stall moves outboard. Needs washout or a gentler tip section. |
| Strong taper, below 0.4 | Little further gain. | Peak local lift coefficient moves to roughly (1 − taper ratio) of the semi-span, where chord and Reynolds number are lowest. Tip stall. |
| Sweep | Moves the aerodynamic center aft for layout. Gives a flying wing its pitch control arm. Adds effective dihedral. | Lowers lift-curve slope and maximum lift. Spanwise flow loads the tips. Pitch-up at stall. |
| Washout, 2 to 3 degrees | Tips stall last. Ailerons stay effective. | A little induced drag at high speed, where the tips carry almost nothing. |
| Winglets | Roughly the induced drag benefit of extending span by half the winglet height, with less added root bending. Fins for a flying wing. | Wetted area and junction drag at all speeds. Flat span is better if you are not span-limited. |


## Chapter 16 · Tails and control surfaces
*Tail and control arrangements for small UAS*

| Arrangement | Why you would | What it costs |
|---|---|---|
| Conventional | Decoupled pitch and yaw. Easy to size. | Low tail sits in the wing wake and in the grass at landing. |
| T-tail | Tailplane clear of wake, prop wash, and ground. | Fin carries tailplane loads: heavier, less stiff, flutter-prone. Wing can blanket it at deep stall. |
| V-tail | Two surfaces, two servos, one less junction. Tips up and out of the weeds. | No wetted area saved. Control mixing. Rudder input produces adverse roll. Higher load per servo. |
| Inverted V on twin booms | Natural on a pusher. Stiff structure. Rudder input rolls the right way. | Ground clearance. The apex is the first thing to hit. |
| Elevons, tailless | Fewest parts. Compact and rugged. | Short control arm. Up-elevon trim reduces maximum lift. Pitch and roll share throw. |
| Canard | Both surfaces lift upward in trim. Clear aft fuselage for a pusher. | The canard must stall first, so the wing never reaches its own maximum lift. Narrow CG range. |


## Chapter 17 · Configuration aerodynamics
*Configuration choices. What each one buys, what it charges, and what to check early.*

| Choice | What you gain | What you pay | Check early |
|---|---|---|---|
| Tractor | Clean inflow, tail authority from propwash | Nose taken, scrubbing drag, exposed propeller | Sensor view, trim change with throttle |
| Pusher | Clear nose, clean body flow, stabilizing | Wake ingestion noise, aft CG, cooling, launch safety | Balance, propeller clearance at rotation or launch |
| Distributed propulsion, blown wing | High lift at low speed, smaller cruise wing, redundancy | Motor count, wiring mass, lift that needs power | Power-off stall speed, idle propeller drag |
| Lift-plus-cruise VTOL | Simple transition, separate systems, no runway | Dead rotor mass and drag in cruise | Transition margin, cruise drag with rotors stopped |
| Tiltrotor, tailsitter | One propulsion system does both jobs | Propeller compromised between hover and cruise, harder control problem | Authority through the corridor, in wind |


## Chapter 18 · Propellers
*Propeller arrangements and the static versus cruise compromise. Penalties are typical round numbers.*

| Option | What you get | What you pay |
|---|---|---|
| One fixed-pitch propeller, compromise pitch | Simple, light, cheap | Weak at one end of the speed range. Decide which end. |
| Separate lift and cruise propellers | Each works near its best J | Dead mass and drag from the set not in use |
| Folding propeller | Low drag when stopped, survives belly landings, fits tubes and cases | Needs an ESC brake to fold, hinge wear, uneven opening in a dirty wake |
| Variable pitch | Good C_T and η across the whole J range, fast thrust response at constant RPM, reverse thrust | Hub mechanism, servo, mass, and a new failure mode. Rarely worth it on small electric aircraft. |
| Coaxial pair | Two propellers in one footprint, redundancy | Lower propeller works in the upper wake. Expect 10 to 20% less total thrust for the same electrical power than the same two side by side. |


*What each choice pushes on.*

| Raise this | You get | You pay |
|---|---|---|
| Diameter | More thrust per watt at low speed. Thrust goes as D⁴ at fixed RPM. | Power goes as D⁵, so motor torque and current climb fast. Ground clearance, tip speed, rotor inertia. |
| Pitch | Thrust held to higher airspeed, higher efficiency at cruise | Stalled blades and poor thrust per watt when static. More torque at every RPM. |
| Blade count | More thrust in a diameter you cannot increase | A few percent of efficiency per added blade, more torque |
| RPM | Thrust as n², the cheapest knob to turn in flight | Power as n³, noise, tip Mach number, and the manufacturer's structural RPM limit |


## Chapter 19 · Electric motors
*Typical K_v and voltage by application. Round values.*

| Application | Propeller | K_v, RPM/V | Battery |
|---|---|---|---|
| Small fast quadrotor | 5 in | 1,700–2,700 | 4S–6S |
| Camera or survey multirotor | 10–18 in | 300–900 | 4S–6S |
| Heavy-lift multirotor | 22–32 in | 80–200 | 12S–14S |
| Fixed wing, 2–5 kg (4–11 lb) | 10–14 in | 500–1,200 | 3S–6S |
| Fixed wing, 10–25 kg (22–55 lb) | 16–24 in | 150–400 | 6S–12S |


## Chapter 20 · ESCs and electrical power
*Copper wire at 20 °C, only the two rows the Try This uses. Current figures are typical practice for short silicone-insulated runs with some airflow, not code ratings. Full table: Materials, electrical, and hardware tables.*

| AWG | Area, mm² | mΩ per m | Copper, g per m | Typical continuous, A |
|---|---|---|---|---|
| 10 | 5.3 | 3.3 | 47 | 60–100 |
| 12 | 3.3 | 5.2 | 30 | 40–60 |


## Chapter 21 · Batteries
*LiPo pouch versus cylindrical lithium-ion. Typical round values.*

|  | LiPo pouch | Li-ion cylindrical, energy cell | Li-ion cylindrical, power cell |
|---|---|---|---|
| Specific energy, pack level | 130–200 Wh/kg | 200–250 Wh/kg | 150–200 Wh/kg |
| Useful continuous rate | 10–30C | 1–3C | 5–10C |
| Cell resistance | 2–5 mΩ (5 Ah cell) | 20–35 mΩ (21700) | 10–20 mΩ (21700) |
| Voltage per cell: full / nominal / empty | 4.2 / 3.7 / 3.0–3.3 | 4.2 / 3.6 / 2.5–2.8 | 4.2 / 3.6 / 2.5–2.8 |
| Cycle life to 80% capacity | 150–300, fewer if pushed hard | 300–500 or more | 300–500 or more |
| Best suited to | Multirotors, VTOL hover, short hard flights | Fixed-wing endurance at 0.3–1C | Mixed hover and cruise |


*Battery protection by layer. Confirm each one. Do not assume.*

| Layer | What it can do | What to confirm |
|---|---|---|
| Cell and pack | Cylindrical cells usually have an internal vent and current interrupt. Pouch cells have nothing. | Whether the pack has a BMS, a fuse, or a thermistor at all |
| BMS, if fitted | Over and undervoltage, overcurrent, temperature, balancing, state of charge | Its current limit against your peak. Whether it disconnects or only reports. Whether it accepts reverse current from braking. |
| Charger | Balancing and charge termination for packs without a BMS | Balance lead connected every charge, correct chemistry and cell count selected |
| ESC low-voltage cutoff | Reduces or cuts motor power at a set voltage | Set to soft or off in an aircraft. A hard cutoff in a climb is a propulsion failure. |
| Autopilot failsafe | Warns, returns, or lands on voltage and on energy consumed | Thresholds set from voltage under load, sensor calibrated, action tested |


## Chapter 22 · Piston and rotary engines
*Small aircraft engines compared. Round, typical values for the 1 to 40 kW class. Verify every row against the engine maker's data.*

| Type | Power class, kW (hp) | BSFC, g/kWh (lb/hp·h) | Shaft Wh per kg of fuel | Power to mass, kW/kg | Vibration | Complexity | Where it fits |
|---|---|---|---|---|---|---|---|
| Two-stroke gasoline, carbureted | 1–15 (1.5–20) | 500–900 (0.8–1.5) | 1,100–2,000 | 1–2 | High as a single, moderate as a boxer twin | Low | Low-cost aircraft, 2 to 8 hour flights |
| Two-stroke gasoline, fuel injected | 2–20 (3–27) | 350–500 (0.6–0.8) | 2,000–2,900 | 1–2 | Same as above | Moderate: ECU, pump, sensors | Long endurance, altitude changes, cold starts |
| Four-stroke gasoline | 1–20 (1.5–27) | 300–400 (0.5–0.65) | 2,500–3,300 | 0.5–1 | Moderate, at half the firing frequency | Moderate: valvetrain, oil system | Endurance first, mass second |
| Rotary (Wankel) | 3–40 (4–55) | 300–400 (0.5–0.65) | 2,500–3,300 | 1–2 | Low | Moderate to high: seals, rotor cooling, oil metering | Imaging, tight cowls, pushers |
| Heavy fuel, spark or compression ignition | 2–40 (3–55) | 250–400 (0.4–0.65) | 2,500–4,000 | 0.4–1 | High with compression ignition | High: injection, heaters, starting aids | Single-fuel logistics, shipboard use |
| Battery and motor, for comparison | 0.05–50 | n/a | 150–220 per kg of pack | 3–8 (motor only) | Very low | Low | Flights under one to two hours |


## Chapter 23 · Turbines and electric ducted fans
*Propellers, ducted fans, and small turbojets compared. Round, typical values. Verify against manufacturer data.*

| Type | Thrust class, N (lbf) | Jet velocity, m/s | Static thrust per input | Energy advantage | Vibration and noise | Complexity | Where it fits |
|---|---|---|---|---|---|---|---|
| Electric propeller | 1–500 (0.2–110) | 15–40 | 40–80 N per electrical kW | Baseline. Battery at 150–220 Wh/kg. | Low | Low | Cruise below about 60 m/s (115 kt) |
| Electric ducted fan, 50–120 mm | 5–100 (1–22) | 60–100 | 15–25 N per electrical kW | None. Two to four times the power of a propeller for the same thrust. | Low vibration, loud and high pitched | Low, but high current | Jet-shaped airframes, enclosed rotors, tube launch, 3 to 10 minute flights |
| Small turbojet | 20–1,000 (5–225) | 300–500 | TSFC 0.12–0.18 kg/(N·h), which is 1.2–1.8 lb/(lbf·h) | Kerosene at about 12,000 Wh/kg, used at 3 to 12% overall efficiency | Low vibration, very loud, hot exhaust | High: ECU, fuel pump, start sequence, short service interval | Targets, high-speed dash, 100 m/s (195 kt) and up |


## Chapter 24 · Hybrid propulsion and fuel cells
*Energy system options compared. Round, typical values for small unmanned aircraft. Verify against supplier data.*

| System | Power class, kW | Delivered energy, kg per kWh | Fixed mass, kg per kW | Vibration and noise | Complexity | Where it fits |
|---|---|---|---|---|---|---|
| Battery only | Any | 5–7 (150–220 Wh/kg pack) | 0 | Lowest | Low | Under about one hour, or where simplicity matters |
| Series hybrid, gasoline | 1–20 | 0.5–0.8 as fuel | 2–5 | Engine noise and vibration | High: engine, generator, bus control | Multirotors and VTOL needing 2 to 6 hours |
| Parallel hybrid, gasoline | 1–30 | 0.35–0.6 as fuel, shaft basis | 1.5–3 | Engine noise, quiet with engine off | High: coupling, torque blending, restart | Fixed wing with a hard takeoff or quiet loiter |
| PEM fuel cell, hydrogen at 300–350 bar | 0.2–3 | 1–2 including tank | 2–4 | Very low, fan noise only | High: tank, regulator, cooling, purge, buffer battery | Quiet flights of 2 to 4 hours |


## Chapter 25 · Structural loads
*Typical load cases for small fixed-wing and multirotor airframes. Round values, typical, for first sizing only.*

| Case | Typical magnitude | Direction | Usually sizes |
|---|---|---|---|
| Maneuver limit | 3 to 6 g | Normal to wing | Spar, wing joint |
| Gust at cruise | +1 to +4 g on top of 1 g | Normal to wing | Spar on lightly loaded wings |
| Hand launch | 2 to 5 g | Along fuselage, at the grip | Grip area, local skin |
| Catapult or rail | 5 to 15 g average, peaks higher | Along fuselage, at the hook | Hook, fuselage, battery and payload mounts |
| Belly or skid landing | 5 to 20 g | Up and aft | Belly, nose, motor mount, boom root |
| Parachute opening and touchdown | 3 to 8 g opening, 10 to 30 g touchdown | Riser line, then whatever hits first | Riser attach, tail, wingtips |
| Multirotor arm | About 2 × hover thrust per motor, plus landing | Bending and torsion at the arm root | Arm, arm clamp, center plates |


## Chapter 26 · Materials
*Typical room-temperature properties, rounded, for first choices. Composites are in-plane values for shop-made laminates at about 50% fiber by volume. Check the datasheet.*

| Material | Density, g/cm³ | E, GPa | Index: tie E/ρ / panel E^1/3/ρ | Practical temperature limit |
|---|---|---|---|---|
| EPP, EPS, XPS foam | 0.02 to 0.06 | 0.005 to 0.03 | 0.2 / 5 | 70 to 100 °C |
| Balsa, along grain | 0.08 to 0.25 | 1.5 to 6 | 20 / 10 | Moisture matters more than heat |
| Birch plywood | 0.7 | 10 | 15 / 3 | Moisture matters more than heat |
| Aluminum 6061-T6 | 2.7 | 69 | 26 / 1.5 | About 150 °C |
| Steel 4130 | 7.85 | 205 | 26 / 0.75 | Not a limit here |
| E-glass/epoxy, woven | 1.8 to 1.9 | 15 to 28 | 12 / 1.5 | 50 to 60 °C room-temperature cure; 80 to 120 °C post-cured |
| Carbon/epoxy, woven 0/90 | 1.5 to 1.6 | 50 to 70 | 39 / 2.5 | Same as the resin above |
| Carbon/epoxy, unidirectional | 1.5 to 1.6 | 120 to 140 along fiber | 84 / 3.3 | Same as the resin above |
| PLA, printed | 1.24 | 3 to 3.5 | 2.7 / 1.2 | 50 to 60 °C |
| PETG, ABS, ASA, printed | 1.05 to 1.27 | 1.8 to 2.3 | 2 / 1.0 to 1.2 | 70 to 80 °C (PETG); 90 to 100 °C (ABS, ASA) |
| Nylon 12, printed or sintered | 1.0 | 1.5 to 1.9 | 1.7 / 1.2 | 95 to 170 °C by load; softens when damp |
| Carbon-filled nylon, printed | 1.1 to 1.2 | 5 to 8 | 5 / 1.6 | 100 to 150 °C |
| 30% glass-filled nylon, injection molded | 1.36 | 7 to 9 dry | 6 / 1.5 | 150 °C and up |


## Chapter 27 · Joining
*Joining methods for small airframes. Comparison for first choices.*

| Method | Good at | Weak at | Removable | How you know it is good |
|---|---|---|---|---|
| Structural epoxy bond | Large-area shear, thin skins, sealing | Peel, dirty surfaces, heat | No | Process control, witness coupon, proof load |
| CA and 5-minute epoxy | Tacking, foam and wood, field repair | Peel, shock, moisture, gap filling | No | Not reliably |
| Machine screws into inserts or nutplates | Hatches, wings, payloads, anything serviced | Thin laminates, soft cores, vibration loosening | Yes | Torque value, witness mark |
| Rivets | Sheet metal, thin laminate to metal | Composites without backing, repair access | Drill out | Visual |
| Bond plus fasteners | Primary joints you cannot inspect later | Mass, part count | No | Fasteners hold if the bond does not |
| Snap fits, latches, pins, magnets, bands | Field assembly, breakaway parts | Rattle, wear, tolerance stack | Yes, no tools | Fit and feel, go/no-go gauge |
| Thermoplastic welding | Molded and thermoformed shells | Dissimilar materials | No | Process settings, sample teardown |


## Chapter 28 · Manufacturing by quantity
*Process comparison for small airframes. Typical, relative, for first choices.*

| Process | Tooling | Recurring | Labor per unit | Part consolidation | Rate | Repair | Makes sense from |
|---|---|---|---|---|---|---|---|
| Printing (FDM, SLS) | None | Medium | Low touch, long machine time | Good | Hours per part per machine | Reprint | 1 to about 50 |
| Cut foam with film, tape, or thin skins | Very low | Low | Medium | Poor | A few per day | Easy | 1 to about 50 |
| Hand layup in simple molds | Low | High | High | Medium | One per mold per day | Good, scarf patch | 1 to about 50 |
| Prepreg or infusion in machined molds | Medium to high | Medium | Medium | Good | One or two per mold per day | Good | 20 to 1,000 |
| Laser-cut and folded sheet metal, routed plate | Very low | Low | Low to medium | Poor, many fasteners | High | Replace the piece | 1 to 1,000 and up |
| CNC machining | Low, fixtures | Medium to high | Low | Poor | Medium | Replace | Fittings at any quantity |
| Thermoforming | Low to medium | Low | Low, plus trimming | Shells only | Minutes per part | Replace | 50 to 5,000 |
| Compression molding | High | Low to medium | Low | Good | Minutes per part | Limited | 500 and up |
| Molded bead foam (EPP, EPO) | High | Very low | Very low | Excellent | Minutes per part | Glue or replace | 1,000 and up |
| Injection molding | High to very high | Very low | Very low | Excellent | A minute or less | Replace | 1,000 and up |


## Chapter 29 · Designing for repair
*Common sacrificial parts on small aircraft. Typical practice.*

| Fuse | What it protects | Replace time | Note |
|---|---|---|---|
| Nylon wing bolts, rubber bands, magnets | Wing root, fuselage saddle, spar | Minutes | Size the fuse to hold flight limit load with margin and let go below the load that damages the root |
| Folding or breakaway propeller | Motor shaft, mount, nose | Minutes | Carry several. Rebalance is not optional |
| Replaceable skid or belly plate | Fuselage skin, payload window | Minutes | Make it the first thing that touches |
| Bent-wire or printed landing gear | Gear mount and floor | Minutes | A leg that bends is doing its job |
| Printed or molded motor mount | Firewall, boom, motor | Under an hour | Design the fracture plane. Keep wires out of it |
| Foam or printed nose cap | Pitot, camera, forward bulkhead | Minutes | Crush depth is cheap deceleration |
| Breakaway tail or wingtips | Boom, wing panel | Minutes | Tether the wiring with a connector that pulls free |


## Chapter 30 · Flight controllers
*Mounting options for the inertial sensors*

| Approach | Good for | Cost |
|---|---|---|
| Hard mount to stiff structure, filter in software | Multirotors with rpm telemetry, stiff frames, electric fixed-wing | Needs notch filters set from a logged spectrum. A flexible mounting plate ruins it. |
| Controller with internally isolated IMU | Most builds. Small suspended mass, damping chosen by the maker. | You cannot see or service the isolator. Temperature changes its stiffness. |
| Whole controller on soft mounts | Piston engines and other strong low-frequency sources | Wiring stiffness becomes part of the spring. Resonance can land in the rate loop. |


## Chapter 31 · Navigation
*Navigation sensors on small aircraft, typical behavior*

| Sensor | Typical performance | Fails quietly when |
|---|---|---|
| GNSS, standalone | About 1.5 to 3 m horizontal, vertical roughly twice as loose, 5 to 10 Hz | Antenna under carbon, beside a video transmitter, or next to a noisy camera cable: signals arrive near −130 dBm, and the receiver reports a worse fix and a wandering position, not interference. |
| GNSS with RTK or PPK | Centimeters, with a base station and a correction link or post-processing | The correction link drops and the solution falls back unnoticed. |
| Magnetometer | A few degrees when calibrated and remote from current | Error scales with throttle. Steel fasteners, speaker magnets, and servo motors add fixed offsets that change with payload. |
| Barometer | Resolves well under 1 m. Near sea level 12 Pa is about 1 m, and 1 hPa of weather is about 8 m. | The static source sees prop wash or speed-dependent cabin pressure: 5% of the 245 Pa dynamic pressure at 20 m/s is 12 Pa, a 1 m error that comes and goes with airspeed. Sunlight on the bare sensor also shifts it. |
| Airspeed, pitot-static | Differential pressure; the velocity reference for fixed-wing dead reckoning | Pitot blockage: airspeed reads low or stuck while GPS ground speed is normal. |
| Optical flow with rangefinder | Useful ground velocity at low height over textured surfaces | Water, snow, dusk, or height beyond the rangefinder. |
| Visual-inertial odometry | Drift around 1% of distance traveled, typical of a good installation | Low light, motion blur, poor camera-to-IMU time sync, or a featureless scene. |


## Chapter 32 · Communications
*What each link carries and what losing it means*

| Link | Typical rate | Latency that matters | When it drops |
|---|---|---|---|
| Command | Bytes to a few kbit/s | Tens of ms for manual flying. Seconds are fine for waypoint changes. | The aircraft executes its lost-link plan. This is the link to protect. |
| Telemetry | A few to tens of kbit/s | About a second | The operator is blind. An autonomous aircraft is unaffected. |
| Video and payload data | 2 to 20 Mbit/s | Under about 100 ms glass to glass if anyone pilots by it | The mission stops. The aircraft is fine, unless video was the only way to fly it. |


## Chapter 34 · Payload integration
*What each payload type leans on hardest*

| Payload | Dominant demands | Integration detail that gets missed |
|---|---|---|
| Stabilized imaging turret | Look angles, vibration, video link | Gear, skids, and the propeller arc inside the field of regard; the turret touches the ground first in a belly landing. |
| Mapping camera | Nadir view, steady height and speed, position tagging | Trigger-to-shutter timing against GNSS time. |
| Communications relay | Power, heat, antenna placement | The payload's transmitter desensitizing the aircraft's own command receiver and GNSS. |
| Cargo or dropped stores | Mass, CG, release reliability | Trim and CG limits loaded, empty, and with a store that failed to release. |


## Chapter 35 · Autonomy
*Architecture consequences of adding perception and onboard decision-making*

| Resource | What autonomy asks for | What to build in |
|---|---|---|
| Compute | A companion computer, typically 5 to 60 W for embedded modules | Keep it off the flight-critical path. It sends setpoints to the autopilot and never drives actuators. |
| Power | A clean, separate supply that rides through bus transients | Its own regulator and a controlled shutdown, so a brownout does not corrupt storage. |
| Cooling | Continuous heat removal, including on the ground | Heat sink in an airflow path, temperature logged, throttling visible to the operator. |
| Sensors | Field of view, range, rigid mounting, time stamps | Cameras fixed rigidly to the IMU reference, with a shared clock. Calibration that survives a hard landing. |
| Links | Less bandwidth to fly, more to supervise | Low-rate status and intent to the operator. Bulk data stored onboard. |


## Chapter 36 · Runways and conventional landing
*Typical rolling friction, unbraked wheels (after Raymer; round values)*

| Surface | μ | What it does to a small aircraft |
|---|---|---|
| Dry pavement | 0.03–0.05 | Short takeoff, long landing roll |
| Hard turf, mown grass | 0.05–0.08 | Small wheels start to matter |
| Long or wet grass | 0.10–0.15 | Takeoff roll grows fast at low T/W; nose-over risk |
| Soft ground, sand | 0.1–0.3 | Small wheels sink; not a runway |


*Launch methods compared (typical practice, small UAS)*

| Method | Infrastructure | Load on airframe | Practical mass | Crew skill | Site needs |
|---|---|---|---|---|---|
| Runway | Gear on the aircraft | About 1 g | Any | Moderate | Smooth strip, 50–300 m |
| Hand launch | None | 3–5 g at the grip | 3–4 kg; 6–7 kg with training | High | Clear ground ahead |
| Bungee rail | Rail, bungee, stakes | 5–15 g axial | 2–30 kg | Low to moderate | Anchoring, clear departure |
| Pneumatic catapult | Launcher, compressor, trailer | 4–12 g axial | 10–200 kg | Moderate | Vehicle access |
| Tube | Tube and gas; the tube is the case | 20–100 g axial | 1–25 kg | Low | Almost none |
| Vehicle roof | Cradle, vehicle, driver | About 1 g | 5–50 kg | Moderate | Long straight road |
| VTOL | Lift system on the aircraft | About 1 g | Any, at 15–30% mass penalty | Low | A clearing a few spans wide |


*Recovery methods compared (typical practice, small UAS)*

| Method | Infrastructure | Load on airframe | Practical mass | Crew skill | Site needs |
|---|---|---|---|---|---|
| Runway landing | Gear on the aircraft | 3–6 g at the gear | Any | Moderate to high | Smooth strip, long if unbraked |
| Belly or skid | None | 3–10 g, abrasion, snagging | To 10–15 kg | Moderate | Flat grass or soft ground |
| Deep stall | None | 5–15 g on an airframe built to shed parts | To 6–7 kg, low wing loading | Low | A spot tens of meters across |
| Parachute | Canopy on the aircraft, 3–8% of mass | 3–8 g opening, then a 1–2 m drop | 2–150 kg and up | Low to fly, high to repack | Open area sized by wind drift |
| Net | Net, poles, energy absorber | 5–15 g, distributed but snaggy | To about 50 kg | Moderate | Clear approach and go-around |
| Rope or wire capture | Mast or boom, rope, precision nav | 5–12 g at a hook, off-axis | To about 100 kg | Moderate | Deck or small pad, clear airspace |
| VTOL | None carried | 1–3 g touchdown | Any, at a mass and energy penalty | Low | Small clearing, wind limited |


## Chapter 37 · Hand launch
*Hand launch in practice (typical, sea level, no wind)*

| Aircraft mass | Release speed at 100 J | What it takes |
|---|---|---|
| Under 1 kg (2 lb) | 10–12 m/s, arm-speed limited | Almost anything flies. Wing loading to 60 N/m² (20 oz/ft²) |
| 1–2 kg (2–4.5 lb) | 10–11 m/s | Stall under 9 m/s. One hand, standing throw |
| 2–4 kg (4.5–9 lb) | 7–10 m/s | T/W over 0.5, launch mode, a practiced thrower |
| 4–7 kg (9–15 lb) | 5–7 m/s | Low wing loading, strong motor, trained crew, preferably wind |
| Over 7 kg | Under 5.5 m/s | Use a bungee or rail |


## Chapter 38 · Catapults and rails
*Launcher types (typical, small UAS)*

| Type | Aircraft mass | Exit speed | Peak ÷ average | Character |
|---|---|---|---|---|
| Ground bungee, ramp or hand release | 1–5 kg | 10–15 m/s | About 2 | Cheapest. Direction control is poor |
| Bungee rail | 2–30 kg | 12–25 m/s | 1.5–2 | Simple. Output drifts with temperature and age |
| Pneumatic catapult | 10–200 kg | 15–40 m/s | 1.2–1.5 | Repeatable, adjustable by pressure, heavy |
| Rocket assist, zero length | 50 kg and up | Any | Near 1 | Energetics handling. Outside most small programs |


## Chapter 39 · Tube launch
*What the tube constrains*

| Tube property | Limits | Consequence |
|---|---|---|
| Inner diameter | Fuselage section, wing chord, folded prop, payload aperture | Area comes from span and wing count. Small props, high disk loading |
| Length | Fuselage, wing panel length, powered stroke | Span of roughly one to two tube lengths. Stroke sets g |
| Carried mass of the full round | Aircraft plus tube plus gas source | One-person carry is about 20 kg (45 lb) all up |
| Seal and sabot friction | Exit speed scatter | Calibrate over temperature. Cold seals are slow seals |


## Chapter 40 · Parachute recovery
*Canopy sizing at sea level, C_D = 0.75*

| Descent rate | Equivalent drop | Area per kg | Canopy diameter for 10 kg |
|---|---|---|---|
| 4 m/s (13 ft/s) | 0.8 m | 1.33 m²/kg | 4.1 m |
| 5 m/s (16 ft/s) | 1.3 m | 0.85 m²/kg | 3.3 m |
| 6 m/s (20 ft/s) | 1.8 m | 0.59 m²/kg | 2.7 m |
| 8 m/s (26 ft/s) | 3.3 m | 0.33 m²/kg | 2.1 m |


## Chapter 41 · Nets, arrestment, and capture
*Capture devices compared (typical practice, small UAS). The full launch and recovery comparison is in Runways and conventional landing.*

| Device | What takes the load | Precision needed | Where the energy goes | Equipment burden |
|---|---|---|---|---|
| Vertical net | Frontal area; props, pitot, antennas, and gimbals snag | Half of (net width − span) each side; tight in height | Net stretch, brakes on the corner lines | Poles, guys, stakes, net, absorbers; heaviest kit |
| Vertical rope, wingtip hook | One wingtip, then a swing around the rope | Half a span laterally; any height | Rope stretch, end bungees, the swing | Mast or boom 10–15 m, on a trailer or deck |
| Ground wire, tailhook | Hook fitting and aft fuselage, axial | A normal landing short of the wire | Braked reels or dragged weights | Lightest kit, but it needs a strip |


## Chapter 42 · VTOL as a launch and recovery system
*VTOL layouts as launch and recovery systems (typical practice, small UAS)*

| Layout | Added hardware | Hover | Transition | Wind on the pad | Cruise penalty |
|---|---|---|---|---|---|
| Lift+cruise (quadplane) | Four or more lift motors and booms; dead mass in cruise | High disk loading, simple multirotor control | Benign; lift motors hold height while the cruise motor accelerates | Weathervanes; point the nose into wind | Boom and stopped-prop drag, 10–20% mass |
| Tailsitter | Little; cruise propulsion does both jobs; wide landing base | Compromised props; control by vectoring or slipstream surfaces | Pitches through high angle of attack; payload and antennas rotate 90° | Worst; the wing is broadside and the aircraft can tip after landing | Lowest mass, props oversized for cruise |
| Tiltrotor | Tilt actuators, bearings, wiring through a joint | All installed thrust is used | A conversion corridor of speed against tilt angle | Better; tilt gives forward force without pitching | No dead motors. Mechanism mass and failure modes instead |


## Chapter 43 · Operating environment
*Density effects, computed from the standard atmosphere and the ideal gas law*

| Site | Density altitude | σ | Stall speed and hover power | Launch and capture energy | Maximum thrust |
|---|---|---|---|---|---|
| Sea level, 15 °C | 0 m | 1.00 | baseline | baseline | baseline |
| Sea level, 40 °C | 860 m (2,800 ft) | 0.92 | +4% | +9% | −8% |
| 1,500 m, standard day | 1,500 m (4,900 ft) | 0.86 | +8% | +16% | −14% |
| 1,500 m, 35 °C | 2,500 m (8,200 ft) | 0.78 | +13% | +28% | −22% |
| 3,000 m, 25 °C | 4,000 m (13,100 ft) | 0.67 | +22% | +50% | −33% |


## Chapter 44 · It has to get there first
*Envelopes the world hands you. Typical values, mid-2020s; check the current rule before a trip.*

| Envelope | Limit | What it means for the aircraft |
|---|---|---|
| Airline carry-on, typical | 56 × 36 × 23 cm (22 × 14 × 9 in); mass often unlimited, sometimes 7 to 10 kg | A sub-meter span in pieces, or the ground station, plus the batteries. |
| Airline checked bag, standard | 158 cm total of L + W + H (62 in); 23 kg (50 lb), full case | A 70 to 90 cm longest piece in a hard case with foam. Over 158 cm or 23 kg: fees; over about 203 cm (80 in): cargo. |
| Lithium battery, carry-on | Under 100 Wh per pack: no approval. 100 to 160 Wh: airline approval, usually two spares. Over 160 Wh: cargo only, as dangerous goods. | The largest pack you can fly commercial with. A 6S 5,000 mAh pack is about 111 Wh. |
| One person, repeated lifting | About 23 kg (50 lb) under good conditions, less with awkward shape, distance, or a chest-high truck bed | A full case over about 20 kg is a two-person lift or a wheeled case. |
| Pickup truck bed | Short 1.7 m, standard 2.0 m, long 2.4 m (5.5, 6.5, 8 ft); about 1.2 m between the wheel wells | The usual ceiling for a one-piece wing on a domestic program. |
| SUV or van cargo floor | 1.0 to 1.2 m between the wheel wells, 1.8 to 2.4 m with the seats down | Cases stack; long cases go on the diagonal or on the seats. |
| Standard doorway | 0.81 to 0.91 m clear (32 to 36 in) | The widest case that goes into a hotel room or office without turning on edge. |


*What the diagonal buys: longest flat piece of a given width on the floor diagonal, interior L × W in cm. “Straight” means the diagonal buys nothing. From Equation 44.2; subtract 2 to 3 cm for foam.*

| Case | Interior L × W | Floor diagonal | Piece 2 cm wide | Piece 5 cm wide | Piece 10 cm wide | Piece 20 cm wide |
|---|---|---|---|---|---|---|
| Carry-on hard case | 50 × 28 | 57 | 54 cm | straight, 50 cm | straight, 50 cm | straight, 50 cm |
| Airline checked, mid-size | 55 × 42 | 69 | 67 cm | 63 cm | 56 cm | straight, 55 cm |
| Large transport case | 72 × 44 | 84 | 81 cm | 76 cm | straight, 72 cm | straight, 72 cm |
| Squarish crate, 90 × 90 | 90 × 90 | 127 | 125 cm | 122 cm | 117 cm | 107 cm |


## Chapter 45 · Start with the mission
*Turning a wish into a requirement you can design and test to (illustrative values)*

| As first stated | As a useful requirement | Acceptance test |
|---|---|---|
| Long endurance | 45 min on station, 10 km from launch, payload powered; threshold 45, objective 75 | Fly the profile at stated temperature and wind; land with the stated reserve |
| Easy to launch | One person launches in 8 m/s (16 kt) wind with nothing that is not in the case | Ten launches by a trained operator who is not the designer; ten successes |
| Portable | Packed length under 1.0 m; carried mass under 10 kg (22 lb) with ground station | Pack it, weigh it, measure it |
| Rugged | 50 recoveries on unprepared ground using only field-replaceable parts | Count recoveries and log every repair and its time |
| Affordable | Unit cost target at a stated quantity, payload included or excluded, stated | Costed bill of materials and measured build hours |


## Chapter 46 · Requirements without ground truth
*Three kinds of requirement*

| Kind | Examples | What you do with it |
|---|---|---|
| Fixed | Physics, safety, law, the interface to something that already exists | Meet it. Do not spend time arguing. |
| Mission threshold | Below this the aircraft is not useful: the sensor cannot see the target, the link does not reach | Find the real threshold. It is usually lower than the written number and sharper than anyone said. |
| Proxy or preference | Numbers inherited from the last system, round numbers, “objective” values, anything nobody can trace to a person | Price it. Trade it. Offer something better. |


## Chapter 47 · Concept generation
*Architecture-level decisions and what usually settles them*

| Decision | Typical options | Usually settled by |
|---|---|---|
| How it makes lift | Wing, rotors, or both | Endurance and range against the need to hover or land in a small space |
| Launch and recovery | Hand, catapult, tube, runway, VTOL, parachute, net | Site, crew, wing loading, and how many times it must be reused |
| Energy | Battery, liquid fuel, hybrid | Endurance, logistics, noise, and who refuels it |
| Payload position | Nose, belly, at the center of gravity, swappable bay | Field of view, center-of-gravity travel, and landing damage |
| Propulsor position | Tractor, pusher, wing-mounted, distributed | Payload view, recovery method, hand safety, and noise |
| Packaging | One piece, plug-in panels, folding | Case size, setup time, and joint mass |


## Chapter 48 · The first sizing
*Three passes of the illustrative example. Values rounded for display.*

| Pass | Mass in, kg | Wing area, m² | Electrical power, W | Pack energy, Wh | Battery, kg | Mass out, kg | Change |
|---|---|---|---|---|---|---|---|
| 1 | 3.00 | 0.494 | 98.3 | 122.9 | 0.683 | 2.77 | −7.8% |
| 2 | 2.77 | 0.456 | 91.4 | 114.2 | 0.635 | 2.67 | −3.5% |
| 3 | 2.67 | 0.440 | 88.6 | 110.7 | 0.615 | 2.63 | −1.5% |


*Typical first-pass inputs for small electric fixed-wing aircraft. Round values; replace with your own data as soon as you have it.*

| Input | Typical range |
|---|---|
| Structure fraction | 25% to 35% of gross |
| Propulsion fraction (motor, controller, propeller) | 8% to 15% of gross |
| Growth margin at concept stage | 10% to 15% of gross |
| Cruise L/D, complete small aircraft | 8 to 15 |
| Total efficiency, battery to thrust power | 0.4 to 0.6 |
| Pack-level specific energy, lithium-ion or LiPo | 150 to 220 Wh/kg |
| Usable share of pack energy | about 80% new, 65% over pack life |


## Chapter 49 · Build something immediately
*Quick physical builds and what each one can tell you*

| Build | Typical time | Answers | Cannot answer |
|---|---|---|---|
| Cardboard or foam-board mockup, full scale | Hours | Fit, packed size, access, assembly steps | Anything about strength or flight |
| Foam shape with components or ballast at true mass | A day | Center of gravity, grip, carry, launch posture | Stiffness, flutter, real drag |
| Printed integration mockup | Days | Connector mating, cable runs, fastener access, cooling paths | Flight loads, production process |
| Flying foam model of the configuration | One to two weeks | Basic stability, control power, launch and recovery behavior | Performance at the real mass and finish |


## Chapter 50 · Retire the biggest risk first
*Unknowns turned into experiments. Thresholds are illustrative.*

| Unknown | Fastest experiment | Minimum test article | Decision threshold |
|---|---|---|---|
| Hand launch at full mass | Throw it | Foam wing at true wing loading, ballast at true mass and balance, no electronics | Ten clean launches in ten by an average thrower, or move to a catapult |
| Transition is controllable | Simulation, then a small flying model with the same control layout | Cheap foam airframe, production autopilot and mixing | Completes transition inside the allowed altitude loss at both ends of the balance range |
| Link holds with buried antenna | Ground range test | Radio and antenna installed in the mockup fuselage | Stated margin at required range, or the antenna moves outside |
| Folding joint carries limit load | Static bench test | The joint and a stub of spar on each side | No slip or damage at limit load times the chosen factor |
| Battery stays cool in a sealed bay | Bench discharge at mission current | Real pack in the mockup bay with a thermocouple | Stays under the cell maker's limit with margin on a hot day, or add airflow |


## Chapter 51 · Simulation and hardware
*Which tool for which question*

| Tool | Time to an answer | Good at | Blind to |
|---|---|---|---|
| Hand calculation | Minutes | Whether the idea is in the right range; which term dominates | Interactions, anything nonlinear |
| Desktop aerodynamic and performance codes | Hours | Trends, sweeps, sensitivities, comparing shapes | Separated flow, low Reynolds number effects, installation |
| Software-in-the-loop | Hours to days | Flight code logic, modes, failsafes, mission scripts | Real timing, real sensors, a wrong plant model |
| Hardware-in-the-loop | Days | Interfaces, timing, actuator limits, operator procedures | A wrong plant model, vibration, EMI |
| Bench and ground test | Days | Real thrust, current, temperature, stiffness, strength, link margin | Flight loads and flight dynamics |
| Flight test | Days to weeks | Everything, together, including what nobody modeled | Causes. It shows what happened, not always why |


## Chapter 52 · Technical debt
*Two kinds of debt*

|  | Intentional | Accidental |
|---|---|---|
| How it started | Someone chose it to reach a test sooner | Nobody chose it. It was the quickest thing on the day |
| Record | One line in the debt list | None. It lives in one person's memory |
| How it ends | Repaid at its trigger, or written off when the concept is dropped | Discovered by the next team, usually during a failure |


## Chapter 53 · The house of cards
*What a requirement is standing on (illustrative)*

| Requirement | Holds only if | Based on |
|---|---|---|
| Endurance | Predicted L/D, predicted mass, rated battery energy, propulsion efficiency at cruise | Analysis and datasheets, until something flies |
| Hand launch | Predicted mass, predicted C_L,max, an average thrower on a calm day | Estimates and one good arm |
| Structure | Predicted loads, handbook material properties, the joints built as drawn | Analysis, until something is broken on purpose |
| Payload fit | Vendor drawing is current, harness and connectors fit the space left over | A drawing of a part nobody has held |


*Signs the design is standing on its assumptions*

| What you see | What it means |
|---|---|
| A few percent of mass growth costs far more than a few percent of endurance, and breaks launch as well | You are on the steep part of Figure 53.1 |
| Margin lines in the budget have been reassigned to real parts | Every margin is already spent. The next surprise has nowhere to go |
| Each fix creates the next problem: more battery breaks the launch, a bigger wing breaks the tube fit, a lighter spar breaks the load case | The requirements conflict through the physics. No amount of tuning removes that |
| The sizing loop converges slowly, or only with the best-case inputs | The denominator of 53.1 is near zero |
| The plan depends on a component that does not exist yet performing as advertised | One card is holding up the rest |


## Chapter 54 · Schedule learning
*The same program, scheduled two ways*

| Scheduled around deliveries | Scheduled around learning |
|---|---|
| Structural analysis report complete | Wing panel loaded to failure on the bench. Decide the spar layup |
| Propulsion trade study delivered | Three props run on the thrust stand. Pick one, order spares |
| Avionics drawings released | Full avionics stack powered on a board, link checked at range. Freeze the connector set |
| First article assembled | First article flown. List what to change on the second |
| Progress measured by percent complete | Progress measured by questions answered with evidence |


## Chapter 55 · Prototype generations
*What each generation must and must not be*

| Generation | Must be | Must not be | Configuration discipline |
|---|---|---|---|
| Prototype zero | Fast. Aimed at one question. Cheap enough to destroy | Pretty, complete, or kept. Not a demonstration | A dated photo and a page of notes |
| Development aircraft | Representative in aerodynamics, mass, and controls. Easy to open, change, and repair. Instrumented. More than one | Precious. Frozen. Loaded with mission features that have nothing to do with the open questions | A tail number and a build log for each. As-flown mass, CG, and parameter file saved with every flight |
| Mission prototype | Complete enough to fly the real mission with the real payload. Operable by someone who did not build it | A test bed for new ideas. Dependent on a developer at the controls | A baseline in CAD and software. Every change recorded against it. Interfaces frozen |
| Production representative | Built from the package alone, with production processes and suppliers, by the production team | Hand-fitted by the designers. Different from what will ship | The package is the authority. A change goes into the package first and the aircraft second |


## Chapter 56 · Take the Gamble
*Example bets, stated in advance (illustrative)*

| Bet and stake | Expect | Would change your mind | Next |
|---|---|---|---|
| Hand-launch a ballasted foam airframe at the worry mass. Two days | Climbs away from an average throw | Sinks below release height on two of five throws | Pass: keep hand launch. Fail: start the bungee rail |
| Bench-run the smaller motor at cruise power for 30 minutes. One day, one motor | Case temperature settles below the rated limit | Still rising at 30 minutes, or over the limit | Pass: save the mass. Fail: keep the larger motor and close the question |
| Fly the antenna in the tail and in the wing tip on the same day. Two days | Tail location holds link through the turn | Dropouts in the turn at half the required range | Pick the better one. Freeze the harness route |


## Chapter 57 · Bench test
*Bench tests worth running, and the decision each one feeds.*

| Test | Measure | Decision it can change |
|---|---|---|
| Static thrust sweep | Thrust, V, I, RPM, temperature | Propeller and motor choice, thrust margin, battery C rating |
| Same sweep on a part-discharged flight pack | Sag, maximum thrust late in the flight | Reserve policy, pack size, go-around capability |
| Mission-duration thermal run | Temperatures against time | Cooling inlets, ESC size, cowl design |
| Servo torque, speed, centering, stall current | N·m or kg·cm, s/60°, degrees, A | Servo choice, linkage ratio, regulator size |
| All servos stalled at once | Rail voltage dip | Regulator and wiring, separate avionics power |
| Radio noise floor, item by item | dB change in noise and signal | Antenna placement, shielding, which device moves |
| Link loss on the bench | Receiver and autopilot outputs | Failsafe configuration |


## Chapter 58 · Ground test
*Ground tests worth running before first flight, and what should stop the flight.*

| Test | Watch | Do not fly if |
|---|---|---|
| Sign checks, sticks and stabilized mode | Every surface or motor, both directions | Anything moves the wrong way or not at all |
| Full-power restrained run, flight battery | Sag, rail voltages, temperatures, logged vibration and clipping | A rail dips toward reset, clipping appears, anything loosens |
| Compass and GPS against throttle | Heading shift idle to full, satellite count, position noise | Heading moves more than a few degrees, or GPS quality falls |
| Range check, systems off then on | Distance to first link degradation | Everything on is much shorter than everything off |
| Link loss, aircraft restrained | What the autopilot commands | The response is not the one you chose |
| Taxi or tether | Tracking, brakes, first hover response | Will not track straight, or hover response diverges |


## Chapter 59 · Flight test
*What each surrogate proves, and what it cannot*

| Surrogate | Costs | Proves | Cannot prove |
|---|---|---|---|
| Toy of the same class, same modes | Tens of dollars, an afternoon | The pilot’s reflexes, the launch and landing habits, the transmitter layout | Anything about the real aircraft |
| Cheap airframe carrying the real autopilot and ground station | A few hundred dollars, a week | Modes, failsafes, mission logic, geofence, telemetry, the operator’s procedures | Gains, loads, vibration, the real sensors in the real airframe |
| Simulator with the real flight code and transmitter | A day of setup, then free | The card, the calls, the crew, what the code does in each failure | The plant model, timing, sensors, EMI, weather |
| The real aircraft on a tether or gantry (Ground test) | An afternoon | Control sign and direction, first hover response, that it does not shake itself apart | Free-flight dynamics, ground effect removed, anything above a few meters |


*A typical build-up order for a new small fixed-wing aircraft. Adapt the order, keep the one-variable discipline.*

| Block | Question | The one variable |
|---|---|---|
| First flight | Does it trim, and do the controls and sensors make sense? | None. Fly, trim, land. |
| Handling | How does it respond in each axis, manual and stabilized? | Small sharp inputs, one axis at a time |
| Slow side | Where and how does it stall? | Airspeed, stepping down |
| Fast side | Is anything changing as q rises? | Airspeed, stepping up |
| Loading | Does it still behave at mission weight and CG? | Weight first, then CG |
| Automation | Does each mode do what it should, and can you get out of it? | One mode per flight |
| Performance | Power, climb, and endurance against prediction | Speed or weight, points held steady |


## Chapter 60 · Test the failure
*Common failures, the response to decide on, and where to prove it.*

| Failure | Decide | Prove it cheaply | Then in flight |
|---|---|---|---|
| Lost command link | Timeout, then loiter, return, or land. Which link counts. | Simulation; transmitter off, aircraft restrained. | Transmitter off, close in, with a second way to command |
| Navigation loss | Fallback mode without position. How long dead reckoning is trusted. | Simulation; GPS disabled by parameter. | GPS disabled at height, within manual reach |
| Motor out | Fixed wing: glide where. Multirotor: land, fight, or parachute. | Simulation; one motor disabled, propellers off. | Power-off glide. Multirotors only if designed to survive it. |
| Servo failure | Whether remaining surfaces can trim a stuck one | Simulation, surface frozen neutral and hard over | Limited-travel flight with one surface held by a mix |
| Brownout or reboot | State after reboot. Whether flight power and avionics power are separate. | Interrupt avionics power on the bench; time the recovery. | Not injected. The hands-off glide test covers the gap. |


## Chapter 61 · Data into decisions
*Typical logging rates for small UAS flight test; round numbers. Check what your autopilot and storage can sustain.*

| Signal | Typical rate | Used for |
|---|---|---|
| Attitude, body rates, stick inputs, servo and motor outputs | 25 to 50 Hz | Handling, tuning, sign and lag checks |
| Airspeed, altitude, GPS position and velocity | 5 to 10 Hz | Performance, airspeed calibration, wind |
| Battery voltage and current | 10 Hz or more | Power, sag, energy used |
| Raw IMU for vibration | 1 kHz or more, in short bursts if needed | Spectra, finding the source by frequency |
| Temperatures | 1 Hz | Thermal margin |
| Video and spoken or written notes | Time-stamped | Context for everything above |


## Chapter 62 · CG problems
*What else looks like a CG problem*

| Cause | What you would see | Quick check |
|---|---|---|
| CG aft or forward of the intended location | The symptoms above, consistent from flight to flight | Balance exactly as flown: battery, payload, props, hatches, tape |
| Measurement error | Paper says 25% MAC, the aircraft flies like something else | Recompute the MAC and where its leading edge sits (the usual mistake on a swept or tapered wing); confirm the datum |
| Neutral point estimate wrong | CG is where you intended, aircraft is still twitchy | Check tail volume; a tractor prop, a fat forward fuselage, or a tail in the wing wake moves the neutral point forward |
| Trim or incidence error | Constant stick offset, often changing with throttle; disturbances damp normally | Compare power-on and power-off trim; measure wing and tail incidence and the thrust line |
| Control system | Oscillation in the commanded elevator, or gone in manual mode | Reduce gains; check for slop and servo lag (Control-system problems) |
| Lateral CG offset (multirotor) | Constant roll trim; one motor pair always hotter | Compare motor currents in hover |


## Chapter 63 · Stalls and spins
*Why a small aircraft departs at low speed*

| Cause | What you would see | Quick check |
|---|---|---|
| Tip stall from planform | Abrupt roll-off, either direction, ailerons go soft first | Taper ratio, washout, tip chord and its Reynolds number |
| Build asymmetry | Always drops the same wing | Incidence at root and tip, both sides; warps, aileron rigging, one heavy wing |
| Load factor in the turn | Stalls in turns only; log shows steep bank at departure | n = 1/cos φ from logged bank angle |
| Airspeed estimate wrong | Logged airspeed looks healthy at the moment of departure | Pitot leak check; reciprocal headings against GPS; confirm it was zeroed with the probe covered |
| Mass growth or aft CG | Real stall speed above book; break deeper, recovery slower | Weigh and balance as flown (CG problems) |
| Power and yaw effects | Rolls against prop rotation at launch; departs when aileron holds a wing up | Launch at lower power; check sideslip and adverse yaw in the log |


## Chapter 64 · Flutter
*Vibration that may or may not be flutter*

| Cause | What you would see | Quick check |
|---|---|---|
| Control-surface flutter | Sharp onset with airspeed at any throttle; damage at servo, horn, hinge | Servo powered, wiggle the trailing edge for free play; balance the bare surface on its hinge line |
| Wing bending-torsion flutter | Tips blurred on video; long, thin, or open-section wings | Twist the tip by hand against a wing you trust; tap test for the torsion frequency |
| Propulsion vibration | Follows RPM, present on the ground | Static run-up (Vibration) |
| Control-loop oscillation | A few hertz, visible in the commanded output, gone in manual mode | Log review (Control-system problems) |
| Buffet, loose hatch, tape | Broadband, tied to angle of attack or one panel | Inspect; fly slow at high angle of attack and compare |


## Chapter 65 · Structural failure
*Failure modes and how they present*

| Cause | What you would see | Quick check |
|---|---|---|
| Static overload | Break at the peak bending moment, usually the root or the joiner end; fibers broomed on the tension side; log shows high g or high speed | Logged load factor and airspeed against the design loads |
| Buckling | Compression side, often mid-panel: a sharp kink line in carbon, a skin wrinkle, crushed core | How far the skin or cap spans without support from core, ribs, or webs |
| Fatigue | Ordinary load, many flights; starts at a hole, thread, or sharp corner. In metal, a smooth zone with curved bands, then a rough final break | Count hours; find the vibration source and the stress raiser |
| Joint or bond failure | Clean separation; glossy surface where adhesive let go; fastener pulled through; insert pulled from a printed part | Adhesive on both faces or one? One face means surface preparation |
| Prior damage | Break in an odd place; part of the fracture dirty, discolored, or rubbed | Transport, hard landings, and repairs since the last inspection |
| Flutter | Surface or panel departed at high speed; servo and hinge damage | See Flutter |


## Chapter 66 · Propulsion failure
*Propulsion faults and how they present*

| Cause | What you would see | Quick check |
|---|---|---|
| Thermal cutback or overheated windings | Thrust fades after sustained high power, recovers when cool; worse on hot days | ESC temperature in telemetry; feel motor and ESC after landing; trace the cooling air path |
| ESC loss of sync | Screech or stutter on rapid throttle; likelier with large props and high pole counts | Bench throttle steps with the flight prop; adjust timing and acceleration |
| Connector, solder joint, phase wire | Sudden stop, or intermittent cutting with vibration; motor twitches at start | Pull-test every bullet; phase-to-phase resistance should match on all three pairs |
| Mechanical | Vibration, noise, current up with RPM down | Spin by hand for roughness and end play; inspect prop hub, blades, magnets, and mount |
| Installation | Bench data was fine, the aircraft is not | Static run installed, cowls on; compare current, RPM, and temperature with the bench run |
| Command or supply | Throttle command dropped, or voltage fell first | Log review; for supply, Battery and power failures |
| Engine fuel and air | Quits nose-up or at low fuel; sags when hot; mixture drifts with temperature or altitude | Fuel-flow test at flight attitudes; check vent, clunk, and line routing near heat |


## Chapter 67 · Battery and power failures
*Power faults and how they present*

| Cause | What you would see | Quick check |
|---|---|---|
| Pack sag: aged, cold, low charge, or too small for the current | Dips follow current and recover when load drops; worse late in the flight and in the cold | R = ΔV/ΔI from the log; per-cell resistance against a new pack |
| Connection resistance | Sag signature plus one hot spot; intermittent with vibration | Voltage drop across each connector under load; feel for heat after a run |
| Avionics rail brownout | Controller reboots or servos glitch while pack voltage is still healthy | Log the 5 V rail at a high rate; sum servo stall currents against the regulator rating |
| Protection acted | Instant total loss; pack reads normal after a reset (BMS, ESC cutoff, fuse) | Datasheet trip current, voltage, and delay against logged peaks; or confirm the protection you assumed exists (Batteries) |
| One weak cell | Pack voltage acceptable, one cell far below the rest under load | Per-cell logging, or the balance lead right after landing |
| Sensor calibration | Logged mAh does not match what the charger puts back | Compare the two over several flights; recalibrate the current sensor |
| Storage-charged or wrong pack flown | Flight short; resting voltage low before takeoff | Log the resting voltage at arm |


## Chapter 68 · Vibration
*Vibration: competing causes*

| Cause | What you would see | Quick check |
|---|---|---|
| Imbalance, bent shaft, chipped blade | Peak at 1/rev tracking RPM; started after a hard landing or a prop change | Swap or balance the prop; run each motor alone and feel the arm |
| Blade pass: prop close to a wing, boom, or arm | Peak at blade count × 1/rev, even with balanced props | Match the peak to blade count; measure tip clearance |
| Structural resonance | Severe in a narrow RPM band, mild either side | Tap the part and listen; sweep throttle slowly, tied down |
| Isolator wrong: too stiff, bottomed out, or bridged by a tight harness | The isolated IMU reads more vibration than the frame | Press the controller: it should move freely and return; check cable slack |
| Bearings, loose motor mount, loose payload | Broadband noise and rattles that grow flight by flight | Spin by hand; wiggle everything; check every screw |
| Aliasing in the sensor chain | Slow drift with no visible slow motion | Log raw IMU at the highest rate; look for energy above half the sample rate |


## Chapter 69 · EMI and navigation problems
*EMI and navigation: competing causes*

| Cause | What you would see | Quick check |
|---|---|---|
| Power-lead current near the magnetometer | Heading error and field magnitude scale with current; clean at idle | Tied down, props on, step the throttle; field magnitude against current |
| Steel or magnets nearby: fasteners, servos, payload parts | Constant offset, no change with throttle; after a repair or payload swap | Raw field while moving the suspect part; calibration offsets against the last good set |
| Wrong compass orientation, stale calibration | Error depends on which way the nose points | Four known headings on the ground |
| Broadband noise into GNSS | C/N_0 falls 5 to 10 dB-Hz when one device is on | Open sky; devices on one at a time, logging C/N_0 |
| Transmitter desensing a receiver; 1.2 to 1.3 GHz video beside a GNSS antenna is the classic case | Loss follows transmit state or power, not throttle | Key the transmitter on and off; change its power |
| External: multipath, local interference, jamming | Follows place and time, not aircraft state | Move 100 m; compare with a second receiver |


## Chapter 70 · Control-system problems
*Control-system problems: competing causes*

| Cause | What you would see | Quick check |
|---|---|---|
| Sign, mapping, or orientation error | Immediate divergence; output grows in the direction that makes the error worse | Tilt the aircraft in a stabilized mode: surfaces oppose the tilt, low-side motors speed up. Check IMU orientation, motor order, prop direction |
| Saturation | Logged output flat at its limit while the error stays open; one corner of the envelope | Overlay actuator outputs on attitude error; look for time on the stops |
| Delay | Oscillation at a fixed frequency; cutting gain stops it and the response goes mushy | Add up filter, loop, and actuator delays; compare with the last setup that flew well |
| Slop, stiction, flex | Small limit cycle; amplitude set by free play, not gain | Servos powered, hold the horn, wiggle the surface; watch the pushrod under load |
| Gains, or missing gain scheduling | Fixed-wing: oscillates fast, mushy slow. Multirotor: fine light, loose heavy | Response changes smoothly with gain; confirm airspeed scaling is on and the airspeed believable |
| Sensor noise | Hairy rate trace, hot motors | Vibration |


## Chapter 71 · Launch failures
*Launch failures: competing causes*

| Cause | What you would see | Quick check |
|---|---|---|
| Low airspeed at release: heavy, tailwind, tired bungee or weak throw | Sinks wings level with full up elevator; airspeed at or below stall | Stall speed at today’s weight and density against release airspeed |
| Thrust late or low: detection delay, throttle ramp, battery sag | Motor current rises after the sink has begun | Accelerometer spike at release against motor current |
| Attitude wrong at release: nose-high throw, bank, rail too steep | Pitch or roll out of limits at time zero; stall and wing drop | Side-on video; logged pitch and roll at release |
| Control authority: low dynamic pressure, surfaces held neutral by launch logic, integrator wound up | Surfaces at full deflection while attitude still departs, or not moving at all | Surface command against attitude in the first second |
| Trim or CG | The same pitch departure, same direction, every launch | Weigh and balance; unpowered hand glide |
| Ground equipment: carriage hang-up, release timing, rail friction | Low end speed or scatter between shots; witness marks on the airframe | Dummy-mass shots with end speed measured |


## Chapter 72 · Transition failures
*Transition failures: competing causes*

| Cause | What you would see | Quick check |
|---|---|---|
| Lift deficit: rotors reduced or tilted ahead of the wing | Altitude loss mid-corridor, airspeed below stall, rotors commanded down | Altitude, airspeed, and rotor thrust share on one plot |
| Thrust collapse at high advance ratio | Full throttle, high RPM, falling current, acceleration fading below stall speed | Pitch speed against stall speed; measured thrust against airspeed if available |
| Control moment saturation | One axis, often pitch: outputs pinned, error open | Actuator outputs against limits, axis by axis |
| Control allocation handover | A bump or oscillation at one speed or tilt angle; rotors and surfaces both weak, or fighting | Log the blend schedule; overlay rotor and surface commands |
| Airspeed uncertainty: pitot at high angle of attack, low dynamic pressure, tailwind | Transition logic switching at the wrong time, or hunting | Airspeed against GNSS speed and the wind estimate |
| Electrical power limit | Bus voltage dips and all motors lose thrust together | Voltage and current at the transition peak |


## Chapter 73 · Human errors
*Human errors: competing causes*

| Cause | What you would see | Quick check |
|---|---|---|
| Interface | Mode, units, or state ambiguous or hidden; identical connectors; unlabeled switches | Hand the ground station to someone new; ask what state the aircraft is in |
| Checklist | Item skipped, list run from memory or interrupted, or out of date for this configuration | Watch a preflight without helping; time it; count the interruptions |
| Workload | One person flying, monitoring, and talking; time pressure | Write down who was doing what in the minute before the error |
| Handoff | State assumed across a shift, builder to crew, or pilot to pilot | Ask each person separately what they believed the state was |
| Configuration | Parameters, firmware, props, battery, payload, or CG changed with no record | Diff everything against the last good flight |


## Chapter 74 · Units, atmosphere, and quick equations
*Exact definitions rounded to four figures. Multiply the left unit by the factor to get the right unit.*

| Quantity | From | Factor | To | And back |
|---|---|---|---|---|
| Mass | lb | 0.4536 | kg | 1 kg = 2.205 lb |
| Mass | oz | 28.35 | g | 100 g = 3.527 oz |
| Length | in | 25.4 | mm | 1 m = 39.37 in = 3.281 ft |
| Distance | statute mile | 1.609 | km | 1 nautical mile = 1.852 km |
| Area | ft² | 0.0929 | m² | 1 m² = 10.76 ft²; 1 in² = 645.2 mm² |
| Speed | m/s | 2.237 | mph | 1 mph = 0.4470 m/s |
| Speed | m/s | 1.944 | kt | 1 kt = 0.5144 m/s |
| Speed | m/s | 3.281 | ft/s | 1 m/s = 3.6 km/h |
| Force | lbf | 4.448 | N | 1 N = 0.2248 lbf; 1 kgf = 9.807 N |
| Wing or disk loading | lb/ft² | 47.88 | N/m² | 100 N/m² = 2.089 lb/ft² |
| Wing loading | oz/ft² | 2.993 | N/m² | 100 N/m² = 33.4 oz/ft² |
| Mass per area | kg/m² | 9.807 | N/m² | 1 kg/m² = 3.277 oz/ft² = 0.2048 lb/ft² = 10 g/dm² |
| Power | hp | 745.7 | W | 1 kW = 1.341 hp |
| Power per mass | W/lb | 2.205 | W/kg | 100 W/kg = 45.4 W/lb |
| Energy | Wh | 3,600 | J | Wh = Ah × V; 1 Wh/kg = 0.4536 Wh/lb |
| Torque | N·m | 141.6 | oz·in | 1 N·m = 8.851 lb·in = 10.20 kgf·cm |
| Torque | kgf·cm | 0.09807 | N·m | 1 kgf·cm = 13.89 oz·in |
| Pressure, stress | psi | 6.895 | kPa | 1 MPa = 145.0 psi; 1 GPa = 145.0 ksi |
| Density | g/cm³ | 0.03613 | lb/in³ | 1 g/cm³ = 1,000 kg/m³ |
| Rotation | RPM | 0.1047 | rad/s | Motor K_t [N·m/A] = 9.549 / K_v [RPM/V] |
| Temperature | °C | × 9/5 + 32 | °F | K = °C + 273.15 |


*ISA from sea level to 5,000 m, computed from Equation 74.1. σ = ρ/ρ₀. The last column is the factor on true airspeed for the same lift, and on ideal hover power for the same thrust.*

| Altitude, m | Altitude, ft | T, °C | p, hPa | ρ, kg/m³ | σ | 1/√σ |
|---|---|---|---|---|---|---|
| 0 | 0 | 15.0 | 1013 | 1.225 | 1.000 | 1.000 |
| 500 | 1,640 | 11.8 | 955 | 1.167 | 0.953 | 1.024 |
| 1,000 | 3,280 | 8.5 | 899 | 1.112 | 0.907 | 1.050 |
| 1,500 | 4,920 | 5.2 | 846 | 1.058 | 0.864 | 1.076 |
| 2,000 | 6,560 | 2.0 | 795 | 1.006 | 0.822 | 1.103 |
| 2,500 | 8,200 | −1.2 | 747 | 0.957 | 0.781 | 1.131 |
| 3,000 | 9,840 | −4.5 | 701 | 0.909 | 0.742 | 1.161 |
| 3,500 | 11,480 | −7.8 | 658 | 0.863 | 0.705 | 1.191 |
| 4,000 | 13,120 | −11.0 | 616 | 0.819 | 0.669 | 1.223 |
| 4,500 | 14,760 | −14.2 | 577 | 0.777 | 0.634 | 1.256 |
| 5,000 | 16,400 | −17.5 | 540 | 0.736 | 0.601 | 1.290 |


*The one-line relationships used in this book and the chapter that explains each.*

| Relationship | Use | Chapter |
|---|---|---|
| q = ½ρV² | Dynamic pressure | 12 Lift |
| L = q S C_L | Lift | 12 Lift |
| V_s = √[2(W/S) / (ρ C_L,max)] | Stall speed from wing loading | 06 Wing loading |
| C_D = C_D0 + C_L² / (π e AR) | Drag polar | 13 Drag |
| AR = b²/S | Aspect ratio | 15 Wings |
| V_H = S_H l_H / (S c̄) | Tail volume | 16 Tails and control surfaces |
| P_hover = (W/FM) √[(W/A) / 2ρ] | Hover power from disk loading | 07 Disk loading |
| P_cruise = W V / [η (L/D)] | Cruise power | 08 Power loading and thrust-to-weight |
| R = (e_b/g) η (L/D) (m_b/m) | Electric range | 09 Energy and endurance |
| n = 1 / cos φ, r = V² / (g tan φ) | Load factor and radius in a level turn | 11 Speed and maneuvering |
| T = C_T ρ n² D⁴, P = C_P ρ n³ D⁵, J = V / (nD) | Propeller coefficients, n in rev/s | 18 Propellers |
| f_BP = N · RPM / 60 | Blade-passage frequency | 59 Flight test |
| RPM ≈ K_v (V − I R_m), Q = K_t (I − I_0) | Brushless motor model | 19 Electric motors |
| ΔV = I R, P_loss = I² R | Wiring drop and heating | 20 ESCs and electrical power |
| I_max = C rating × capacity [Ah] | Battery current limit | 21 Batteries |
| a = V² / (2s) | Average launch acceleration over stroke s | 38 Catapults and rails |
| V_d = √[2W / (ρ C_D S_0)] | Parachute descent rate | 40 Parachute recovery |


## Chapter 75 · Sizing charts and practical ranges
*Typical wing loading by launch method. Sea level. Boundaries are soft.*

| Class | W/S, N/m² | oz/ft² (lb/ft²) | kg/m² | Note |
|---|---|---|---|---|
| Thermal gliders, park flyers | 15 to 40 | 5 to 13 | 1.5 to 4 | Gust sensitive. Poor wind penetration. |
| Hand-launched UAS | 30 to 100 | 10 to 33 (0.6 to 2.1) | 3 to 10 | Upper end needs a strong motor and a committed throw. |
| Bungee, catapult, or rail launch | 100 to 300 | 33 to 100 (2.1 to 6.3) | 10 to 30 | Launcher energy and recovery loads set the limit. |
| Runway, VTOL lift, or tube boost | 150 to 500 | 50 to 170 (3.1 to 10.4) | 15 to 50 | Folding wings push tube-launched aircraft to the top. |


*Typical hover disk loading, all rotors counted. Battery power per kg assumes FM 0.65 and 85 percent motor and ESC efficiency at sea level.*

| Class | W/A, N/m² | lb/ft² | Hover power, W/kg | Thrust per watt, g/W |
|---|---|---|---|---|
| Small helicopters, large efficient multirotors | 30 to 80 | 0.6 to 1.7 | 60 to 100 | 10 to 16 |
| Camera and heavy-lift multirotors | 50 to 120 | 1.0 to 2.5 | 80 to 125 | 8 to 12 |
| Racing and compact quads | 100 to 200 | 2.1 to 4.2 | 115 to 160 | 6 to 9 |
| Lift + cruise, tailsitter, tiltrotor | 150 to 400 | 3 to 8 | 140 to 230 | 4.5 to 7 |
| Ducted fans, EDF lift | 1,000 and up | 20 and up | 350 and up | Under 3 |


*Typical installed power and static thrust-to-weight. Electrical input power per kg of takeoff mass.*

| Aircraft | Installed power, W/kg (W/lb) | Cruise power, W/kg | Static T/W |
|---|---|---|---|
| Hand-launched electric fixed wing | 120 to 200 (55 to 90) | 15 to 50 | 0.5 to 0.8 |
| Catapult or runway fixed wing, endurance | 80 to 150 (35 to 70) | 15 to 40 | 0.3 to 0.5 |
| Heavy-lift multirotor | 250 to 400 (115 to 180) | Near hover power | 1.8 to 2.0 |
| Camera or survey multirotor | 300 to 500 (135 to 225) | Near hover power | 2.0 to 2.5 |
| Racing multirotor | 1,000 and up (450 and up) | Not the point | 5 to 10 and up |
| Hybrid VTOL lift system (4+1) | 250 to 450 (115 to 205) | 20 to 50 on the wing | 1.3 to 1.8 on lift motors |


*Typical fractions of takeoff mass and typical component values.*

| Quantity | Typical range | Conditions |
|---|---|---|
| Battery mass fraction | 0.25 to 0.40 | Electric fixed wing and multirotor. Endurance designs reach 0.5. |
| Fuel mass fraction | 0.15 to 0.35 | Small piston fixed wing. |
| Payload fraction | 0.10 to 0.25 | Higher on short-endurance lifters. |
| Airframe structure fraction | 0.25 to 0.40 | Rises with launch and recovery loads and with folding. |
| Propulsion fraction, less battery | 0.05 to 0.15 fixed wing; 0.15 to 0.30 multirotor and VTOL | Motors, ESCs, props, mounts. |
| LiPo pack specific energy | 130 to 200 Wh/kg | Pack level, with leads. Plan on 80 percent usable from a new, warm pack, 65 percent over its life. |
| Li-ion cylindrical pack | 180 to 260 Wh/kg | Pack level. Lower current capability. |
| Gasoline | About 12,000 Wh/kg chemical | Small engines deliver 10 to 25 percent of it at the shaft. |
| Cruise L/D, small fixed wing | 8 to 15 | With payload bumps and antennas. Clean sailplane-like layouts reach 20. |
| C_L,max, no flaps | 1.0 to 1.3 | Whole aircraft, Re of 100,000 to 500,000. |
| C_D0 | 0.02 to 0.05 | Small UAS with fixed payload and exposed hardware. |
| Oswald efficiency e | 0.7 to 0.85 | Conventional layouts. |
| Rotor figure of merit | 0.5 to 0.7 | Small fixed-pitch props in hover. |
| Propeller efficiency in cruise | 0.5 to 0.8 | Prop matched to the cruise point. Often worse when it is not. |
| Motor and ESC efficiency | 0.75 to 0.90 | Near the design point. Falls off at light load. |


## Chapter 76 · Materials, electrical, and hardware tables
*Typical room-temperature properties. Strength is tensile ultimate unless noted. Composite values are along the fibers at about 50 to 60% fiber volume. 1 GPa = 145 ksi, 1 g/cm³ = 0.0361 lb/in³.*

| Material | Density, g/cm³ | Modulus, GPa | Strength, MPa | Softens or limit, °C | Check |
|---|---|---|---|---|---|
| Aluminum 6061-T6 | 2.70 | 69 | 310 (yield 275) | About 150 | Handbook |
| Aluminum 7075-T6 | 2.81 | 72 | 570 (yield 500) | About 120 | Handbook |
| Steel 4130, normalized | 7.85 | 205 | 670 (yield 435) | Not a concern | Handbook; varies with heat treatment |
| Titanium Ti-6Al-4V | 4.43 | 114 | 950 (yield 880) | Not a concern | Handbook |
| Carbon/epoxy, unidirectional | 1.5–1.6 | 110–140 | 1,500–2,500 tension, about half in compression | 50–80 room cure, 100–180 post-cured | Verify: coupons |
| Carbon/epoxy, woven 0/90, wet layup | 1.4–1.5 | 40–60 | 400–700 | Same as above | Verify: coupons |
| E-glass/epoxy, woven | 1.7–1.95 | 15–28 | 250–450 | Same as above | Verify: coupons |
| Aramid/epoxy, woven | 1.3–1.4 | 25–35 | 400–550 tension, weak in compression | Same as above | Verify: supplier |
| Spruce, along grain | 0.40–0.45 | 9–11 | 60–80 bending | Moisture matters more | Verify: varies by board |
| Birch aircraft plywood | 0.65–0.72 | 8–13 | 60–100 | Moisture matters more | Verify: grade and ply count |
| Balsa, along grain | 0.08–0.25 | 1.5–6 | 8–30 | Moisture matters more | Verify: weigh every sheet |
| Bead and extruded foams (EPP, EPO, XPS) | 0.02–0.06 | 0.005–0.03 | 0.1–0.5 compression | 70–100 | Verify: supplier |
| Structural core foam (PVC, PMI) | 0.05–0.11 | 0.05–0.13 | 0.8–3 compression | 70–180 by type | Verify: datasheet |
| Printed PLA | 1.24 | 2.5–3.5 | 40–60 in plane | 50–60 | Verify: coupons |
| Printed PETG | 1.27 | 1.8–2.2 | 40–50 in plane | 70–80 | Verify: coupons |
| Printed ABS or ASA | 1.04–1.07 | 1.8–2.3 | 30–45 in plane | 90–100 | Verify: coupons |
| Nylon PA12, powder-bed printed | 0.95–1.02 | 1.5–1.9 | 40–50 | 95–170 by load | Verify: datasheet |
| Polycarbonate | 1.20 | 2.2–2.4 | 55–65 | 120–140 | Verify: grade |


*Adhesive selection. Lap-shear values are typical for prepared surfaces at room temperature. Verify every row against the product datasheet, and test on your own substrates.*

| Adhesive | Lap shear, MPa | Softens, °C | Use it for | Avoid |
|---|---|---|---|---|
| Structural epoxy paste, room cure | 15–30 | 50–80, higher if post-cured | Composite and metal joints, gap filling to about 0.5 mm | Unprepared surfaces, polyethylene, polypropylene, EPP |
| Methacrylate (MMA) | 15–25 | 80–100 | Plastics and metals with little preparation, tougher in peel than epoxy | Foams, which the monomer attacks |
| Cyanoacrylate (CA) | 10–20 | About 80 | Wood, small tight-fitting parts, field repairs | Peel and impact loads, gaps, styrene foams unless foam-safe |
| Foaming polyurethane | 3–10 | About 80 | Foam to foam and foam to wood, fills poor fits | Joints needing precise alignment without clamping |
| Hot melt | 1–4 | 60–80 | EPP and EPO airframes, wiring tie-down | Anything that sits in a hot car or near a motor |
| Silicone RTV | 1–3 | About 200 | Sealing, potting, vibration-tolerant mounting | Structural joints, surfaces to be painted or bonded later |
| Anaerobic threadlocker, medium | n/a | About 150 | Metal screws into metal | Polycarbonate and many plastics, which it cracks |


*Annealed copper at 20 °C, computed from the AWG diameter formula and ρ = 1.72 × 10⁻⁸ Ω·m; stranded wire runs a few percent higher. The current column is 10 A/mm², a starting point for short silicone-insulated leads in moving air, not a rating: verify every current against the wire maker's rating for your insulation, bundle, and ambient, and measure wire temperature on the bench.*

| AWG | Diameter, mm | Area, mm² | Resistance, mΩ/m | Current at 10 A/mm², A | Heat at that current, W/m |
|---|---|---|---|---|---|
| 8 | 3.26 | 8.37 | 2.06 | 84 | 14.4 |
| 10 | 2.59 | 5.26 | 3.27 | 53 | 9.1 |
| 12 | 2.05 | 3.31 | 5.20 | 33 | 5.7 |
| 14 | 1.63 | 2.08 | 8.27 | 21 | 3.6 |
| 16 | 1.29 | 1.31 | 13.1 | 13 | 2.3 |
| 18 | 1.02 | 0.823 | 20.9 | 8.2 | 1.4 |
| 20 | 0.812 | 0.518 | 33.2 | 5.2 | 0.89 |
| 22 | 0.644 | 0.326 | 52.8 | 3.3 | 0.56 |
| 24 | 0.511 | 0.205 | 84.0 | 2.0 | 0.35 |
| 26 | 0.405 | 0.129 | 134 | 1.3 | 0.22 |
| 28 | 0.321 | 0.081 | 212 | 0.8 | 0.14 |


*Common connector families and nominal ratings as generally published. Verify every row against the manufacturer's datasheet. Clone parts are often worse.*

| Family | Typical use | Nominal continuous current, A | Notes |
|---|---|---|---|
| XT30 | Small packs, payload power | 15 (30 peak) | Name reflects the peak figure. |
| XT60 | Main battery to about 1 kW | 30 (60 peak) |  |
| XT90 | Main battery, larger vehicles | 45 (90 peak) | Anti-spark version for high-voltage packs. |
| Bullet, 3.5 to 8 mm | Motor phase leads, large packs | About 40 to 150 by size | Varies widely with spring design. |
| JST-XH, 2.5 mm pitch | Balance leads | About 3 per pin | Not for power. |
| JST-GH, 1.25 mm pitch | Autopilot signal ports | About 1 per pin | Latching. Do not power servos through it. |
| 0.1 in (2.54 mm) servo header | Servos, receivers | About 1 to 3 per pin | No latch. Several digital servos can exceed it. |


*ISO coarse thread. Tensile stress area A_s = (π/4)(d − 0.9382 p)². Breaking load = A_s × minimum tensile strength of the property class: 800 MPa for 8.8, 1,220 MPa for 12.9, 700 MPa for A2-70 stainless. 1 kN = 225 lbf.*

| Size | Pitch, mm | Tap drill, mm | Clearance hole, mm | Stress area, mm² | Breaking load 8.8, kN | 12.9, kN | A2-70, kN |
|---|---|---|---|---|---|---|---|
| M2 | 0.40 | 1.6 | 2.4 | 2.07 | 1.7 | 2.5 | 1.4 |
| M2.5 | 0.45 | 2.05 | 2.9 | 3.39 | 2.7 | 4.1 | 2.4 |
| M3 | 0.50 | 2.5 | 3.4 | 5.03 | 4.0 | 6.1 | 3.5 |
| M4 | 0.70 | 3.3 | 4.5 | 8.78 | 7.0 | 10.7 | 6.1 |
| M5 | 0.80 | 4.2 | 5.5 | 14.2 | 11.3 | 17.3 | 9.9 |
| M6 | 1.00 | 5.0 | 6.6 | 20.1 | 16.1 | 24.5 | 14.1 |


*What changes when the part is hot, cold, enclosed, or high. Limits are typical. Verify against the datasheet for the part in hand.*

| Item | Typical limit or effect | What to do |
|---|---|---|
| Wire in a bundle or closed bay | Less cooling than a single wire in free air | Halve the free-air current, or measure. |
| Wire insulation | PVC 80–105 °C, silicone 150–200 °C, PTFE 200–260 °C | Keep PVC away from motors, controllers, and exhausts. |
| Copper resistance | +0.39% per °C | Add 20 to 30% to cold-wire losses for hot running. |
| Motor magnets, NdFeB grade suffix | None 80 °C, M 100, H 120, SH 150, UH 180, EH 200 | Check which grade the motor uses; loss of magnetization is permanent. |
| Motor winding insulation class | B 130 °C, F 155 °C, H 180 °C | Case temperature reads well below winding temperature. |
| Speed controllers and regulators | Ratings assume airflow | In a closed fuselage plan on half to two-thirds of rated current, or add a duct; log temperature. |
| Lithium polymer battery | Discharge about −20 to 60 °C, charge about 0 to 45 °C | Never charge below freezing; warm cold packs before flight. |
| Room-cure epoxy and printed PLA | Soften at 50 to 60 °C and up | A dark airframe in the sun or a closed car reaches 60 to 90 °C: paint it light, post-cure, or change material. |
| Altitude | Air cooling falls roughly with density, to 74% at 3,000 m ISA | Derate anything air-cooled, including motors, controllers, and fuel-cell stacks. |
| Servos | Continuous torque is a quarter to a third of stall | Size the servo supply for all servos stalled at once, or fuse it. |


## Chapter 77 · Checklists and troubleshooting maps
*Concept review. Ten questions.*

| Check | What good looks like | Chapter |
|---|---|---|
| Mission as numbers | Payload mass and power, range or endurance, speeds, launch and recovery, wind, temperature, altitude. Each with a source. | 45 |
| Mass budget | Itemized, with a growth allowance (typically 10 to 20% at this stage) and a located CG. | 05 |
| Wing or disk loading | Stall speed or hover power fits the launch and recovery method at maximum mass on a hot day. | 06, 07 |
| Power and energy | Cruise, climb, and hover power estimated. Endurance includes a stated reserve. | 09 |
| Stability and control | Static margin and tail volumes in the family that flies well. CG range achievable with the real payload. | 10 |
| Structure and breakdown | Design load factor chosen. Load paths drawn through every joint. It fits its case. | 25 |
| Failure behavior | Loss of link, GPS, propulsion, and battery each have a defined response. | 60 |
| Count of new things | New airframe, new propulsion, new autopilot, new payload, new team: know how many are new at once. | 53 |
| Biggest risk | Named, with the cheapest test that would retire it and a date. | 50 |
| Build plan | Process matches quantity. Long-lead parts identified. Something gets built this week. | 28, 49 |


*Test readiness review, before any flight that is new in some way.*

| Check | What good looks like |
|---|---|
| Objective | One card per flight. Written test points, success criteria, and the decision the data will feed. |
| Predictions | Expected stall speed, trim, hover throttle, cruise current, and climb rate written down beforehand. |
| Configuration | As-flown mass and CG measured. Firmware and parameter file versions recorded. Propeller, battery, and payload identified. |
| Changes | Everything changed since the last flight is listed. Ideally it is one thing. |
| Ground tests | Control directions and throws, failsafes, range check, and a logged full-power run complete. Vibration acceptable. |
| Limits | Wind, visibility, and temperature limits set. Knock-it-off criteria and the action for each are briefed. |
| Roles | Pilot, ground station, observer, and test director named. Everyone knows who can call a stop. |
| Site | Airspace permission, hazards, recovery area, and a plan for a battery fire. |
| Data | Logging on at the right rates, storage free, sensors calibrated, video running. |
| Spares and tools | Enough to repair the likely damage and fly again the same day. |


*Preflight, every flight. Tailor the order to a walk around the vehicle.*

| Check | What good looks like |
|---|---|
| Airframe | Wing and tail attachments secure. No new cracks, creases, or soft spots. Hatches latched. |
| Controls | Hinges and linkages tight. Surfaces move the right way in manual and correct the right way in stabilized mode. |
| Propulsion | Propeller undamaged, tight, and turning the right way. Motor mount secure. Fuel quantity and vent checked if fueled. |
| Battery | Cell voltages checked and balanced. Pack strapped. Connector fully seated. |
| Mass and CG | Payload secured. CG checked at the marks in the as-flown configuration. |
| Sensors | Pitot cover off, airspeed responds. Horizon level. Heading agrees with a known direction. GPS fix, good satellite count. |
| Link and failsafe | Control and telemetry signal healthy. Failsafe actions, home position, and geofence confirmed. |
| Plan and modes | Flight plan uploaded and read back. Mode switch positions verified. |
| Run-up | A few seconds at full power. Voltage sag, current, vibration, and sound are normal. |
| Land-by criterion | Stated aloud as a time, a voltage, or a capacity used. |
| Launch area | Wind checked, people clear, launch called. |


*Postflight, every flight. Most of the learning is here.*

| Check | What good looks like |
|---|---|
| Make safe | Disarmed, propeller clear, battery disconnected. |
| Battery | Warm, not hot. No swelling. Resting voltage and capacity used recorded against the prediction. |
| Motor and controller | Temperature checked by hand or sensor soon after landing. |
| Airframe | Inspected for landing damage, loose fasteners, hinge and linkage wear, and cracks at joints. |
| Log | Downloaded, named, and stored with the configuration record. Anomalies written down while fresh. |
| Compare | Measured current, airspeed, trim, and vibration against the predictions. Differences explained or listed. |
| Squawks | Every defect written down with an owner. The one change for the next flight decided. |
| Storage | Batteries at storage voltage. Aircraft supported so that nothing warps. |


*Symptom, first three checks, and the Part X chapter to open. For the flutter row the right first action is to slow down and land, and diagnose on the ground.*

| Symptom | First three checks | Go to |
|---|---|---|
| Porpoises, won’t trim | As-flown CG · static margin · trim offset | CG problems |
| Wing drop, departs | Airspeed cal · weight growth · tip stall | Stalls and spins |
| Buzz grows with speed | Hinge slop · mass balance · linkage flex | Flutter |
| Crack, crease, bent part | Load path · bond prep · logged g and gusts | Structural failure |
| Power loss, surge, quit | Fuel or desync · temperature · prop, mount | Propulsion failure |
| Brownout, reboot, sag | Sag under load · hot connector · BEC load | Battery and power failures |
| Shake that tracks RPM | Prop balance · mount bolts · IMU isolation | Vibration |
| GPS, compass, link drop | Compass vs. throttle · GPS SNR · routing | EMI and navigation problems |
| Wobble follows command | Gains vs. airspeed · servo slop · latency | Control system problems |
| Launch sink or roll-off | Launch speed margin · trim, CG · thrust | Launch failures |
| Sinks in transition | Wing-borne speed · power margin · logic | Transition failures |
| Worked yesterday | Config diff · skipped steps · last change | Human errors |
